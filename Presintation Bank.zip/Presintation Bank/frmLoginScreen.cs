﻿using BankBusinessLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;

namespace Bank
{
    public partial class frmLoginScreen : Form
    {
        int CounterFaildAccess = 0;
        public frmLoginScreen()
        {
            InitializeComponent();
        }


        //#FD9B63
        //#E7D37F
        //#81A263

        private clsUsersBusinessLayer _CheckUserName(string userName)
        {
            clsUsersBusinessLayer User = clsUsersBusinessLayer.Find(userName);
            if (User == null)
                return null;
            else
                return User;
        }
        private bool _CheckPassword(clsUsersBusinessLayer User,string password)
        {
            return User.Password == password;
        }
        private void _CustomInterface()
        {
           
            txtUserName.Focus();
            panel1.BackColor = System.Drawing.ColorTranslator.FromHtml("#81A263");


            string UserName = string.Empty;
            string Password = string.Empty;
           

            if (_AreUserNameAndPasswordExistsInWindowsRegistry(ref UserName, ref Password))
            {
                if (UserName != null && Password != null)
                {
                    txtPassword.Text = Password;
                    txtUserName.Text = UserName;
                    chkRememberMe.Checked = true;
                }
            }

        }
        private void frmLoginScreen_Load(object sender, EventArgs e)
        {
            _CustomInterface();
        }
        private bool _AreUserNameAndPasswordExistsInWindowsRegistry(ref string UserNameVN,ref string PasswordVN)
        {
            //True : UserName and password Exists
            //Fales : UserName and password Not Exists
            bool IsExists = false;
            string Path = @"HKEY_CURRENT_USER\Software\Bank_Project";

            try
            {
                 UserNameVN = Registry.GetValue(Path, "UserName", null) as string;
                 PasswordVN = Registry.GetValue(Path, "Password", null) as string;

                IsExists = (UserNameVN != null && PasswordVN != null);
            }
            catch(Exception e) { }

            return IsExists;
        }
        private void _DeleteUserNameAndPasswordFromWindowsRegistry()
        {
            string path = @"Software\Bank_Project";
            string userNameVN = "UserName";
            string passwordVN = "Password";

            try
            {
                using (RegistryKey baseKey = RegistryKey.OpenBaseKey(RegistryHive.CurrentUser, RegistryView.Registry64))
                {
                    using (RegistryKey key = baseKey.OpenSubKey(path, true))
                    {
                        if (key != null)
                        {
                            // Delete the specified values
                            key.DeleteValue(userNameVN);
                            key.DeleteValue(passwordVN);
                        }
                        else
                        {
                            
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }
        private void _WriteUserNameAndPasswordInWindowsRegistry()
        {
            //This function will write userName and password in Windows Registry



            string Path = @"HKEY_CURRENT_USER\Software\Bank_Project";
            string UserNameVN = "UserName"; //Value Name
            string PasswordVN = "Password";//Value Name

            string UserNameVD = txtUserName.Text;//Value Data
            string PasswordVD = clsUtility.ComputeHash(txtPassword.Text);//Value Data
            if (!_AreUserNameAndPasswordExistsInWindowsRegistry(ref UserNameVD, ref PasswordVD))
            {
                UserNameVD = txtUserName.Text;//Value Data
                PasswordVD = clsUtility.ComputeHash(txtPassword.Text);//Value Data

                try
                {
                    Registry.SetValue(Path, UserNameVN, UserNameVD, RegistryValueKind.String);
                    Registry.SetValue(Path, PasswordVN, PasswordVD, RegistryValueKind.String);
                }
                catch (Exception e) { }
            }
            else
                return;
        }
        private void button1_Click(object sender, EventArgs e)
        {
           

            if(CounterFaildAccess>=3)
            {
            
                clsUtility.LogMessageInEventLogSystem($"Someone Try to login with {CounterFaildAccess} Trail(s) Faild", System.Diagnostics.EventLogEntryType.Warning);
            }

            clsUsersBusinessLayer User = _CheckUserName(txtUserName.Text);
            if (User == null) 
            {
                CounterFaildAccess++;
                MessageBox.Show("Username not available", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
         
                return;
            }
            else
            {
                string PasswordToCheck = (txtPassword.Text.Length > 10) ? txtPassword.Text : clsUtility.ComputeHash(txtPassword.Text);
                if (_CheckPassword(User, PasswordToCheck))
                {
                    if (chkRememberMe.Checked)
                        _WriteUserNameAndPasswordInWindowsRegistry();
                    else
                        _DeleteUserNameAndPasswordFromWindowsRegistry();

                    clsGloablUser.CurrentUser = User;

                    //Log Login Proccess
                    //----------------------------------------------
                    clsUtility.LogMessageInEventLogSystem($"Login User : {clsGloablUser.CurrentUser.UserName} , With Permissions : {clsGloablUser.CurrentUser.Permissions}" +
                        $" , At {DateTime.Now.ToLongDateString()}", System.Diagnostics.EventLogEntryType.Information);
                    //----------------------------------------------
                    this.Hide();
                    Form frmMain = new MainScreen();
                    frmMain.ShowDialog();
                    this.Show();
                }
                else
                {
                    MessageBox.Show("The password is incorrect", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }    
            }
        }
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
