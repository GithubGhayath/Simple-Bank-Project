﻿using BankBusinessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bank
{
    static public class clsGloablUser
    {
       static public clsUsersBusinessLayer CurrentUser { get; set; }
    }
}
