﻿using BankBusinessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bank.Generals
{
    public static class clsGloablClient
    {
        static public clsClientsBusinessLayer CurrentClient { get; set; }
    }
}
