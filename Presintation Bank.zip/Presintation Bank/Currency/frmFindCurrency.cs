﻿using BankBusinessLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bank.Currency
{
    public partial class frmFindCurrency : Form
    {
        public frmFindCurrency()
        {
            InitializeComponent();
        }
        private void _FillComboBox()
        {
            DataTable CurrencyCodes = clsCurrenciesBusinessLayer.GetCurrencies();

            foreach (DataRow Code in CurrencyCodes.Rows)
                cbCurrencyCodes.Items.Add(Code["CurrencyCode"].ToString());
        }
        private void gbtnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmFindCurrency_Load(object sender, EventArgs e)
        {
            _FillComboBox();
        }

        private void cbCurrencyCodes_SelectedIndexChanged(object sender, EventArgs e)
        {
            gbtnFind.Enabled = true;
        }

        private void gbtnFind_Click(object sender, EventArgs e)
        {
            clsCurrenciesBusinessLayer CurrentCurrency=new clsCurrenciesBusinessLayer();

            if (cbCurrencyCodes.SelectedItem != null)
                CurrentCurrency = clsCurrenciesBusinessLayer.Find(cbCurrencyCodes.SelectedItem.ToString());
            else
                MessageBox.Show($"Currency Not found!", "Wrong", MessageBoxButtons.OK, MessageBoxIcon.Error);

            if (CurrentCurrency != null)
            {
                lblCurrencyRate.Text = CurrentCurrency.Value.ToString();
            }
        }
    }
}
