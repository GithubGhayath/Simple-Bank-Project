﻿using BankBusinessLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace Bank.Currency
{
    public partial class frmCurrencyList : Form
    {
        public frmCurrencyList()
        {
            InitializeComponent();
        }

        private void _FillTableWithData()
        {
            gdgvCurrencyList.DataSource = clsCurrenciesBusinessLayer.GetCurrencies();
            lblCountRecords.Text = gdgvCurrencyList.Rows.Count.ToString();
        }
        private void frmCurrencyList_Load(object sender, EventArgs e)
        {
            _FillTableWithData();
        }

        private void gbtnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
