﻿using BankBusinessLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bank.Currency
{
    public partial class frmCurrencyCalculator : Form
    {
        public frmCurrencyCalculator()
        {
            InitializeComponent();
        }

        private void _FillComboBoxes()
        {
            DataTable CurrenciesCode = clsCurrenciesBusinessLayer.GetCurrencies();

            foreach(DataRow r in  CurrenciesCode.Rows)
            {//Value_In_2024-06-21
                cbFrom.Items.Add(r["CurrencyCode"].ToString());
                cbTo.Items.Add(r["CurrencyCode"].ToString());
                cbFrom.SelectedIndex = 0;
                cbTo.SelectedIndex = 0;
            }
        }
        private void frmCurrencyCalculator_Load(object sender, EventArgs e)
        {
            _FillComboBoxes();
        }

        private void gbtnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void gbtnCalculate_Click(object sender, EventArgs e)
        {
            if(string.IsNullOrEmpty(txtAmuont.Text))
            {
                MessageBox.Show("Enter The amount for conver", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (cbFrom.SelectedItem == null || cbTo.SelectedItem == null) return;

            clsCurrenciesBusinessLayer From = clsCurrenciesBusinessLayer.Find(cbFrom.SelectedItem.ToString());
            clsCurrenciesBusinessLayer To = clsCurrenciesBusinessLayer.Find(cbTo.SelectedItem.ToString());

            double AmountPerDoller = Convert.ToDouble(txtAmuont.Text) / From.Value;
            lblResult.Text = Convert.ToDouble(To.Value * AmountPerDoller).ToString();
        }
    }
}
