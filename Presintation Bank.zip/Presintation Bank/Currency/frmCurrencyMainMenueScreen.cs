﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bank.Currency
{
    public partial class frmCurrencyMainMenueScreen : Form
    {
        public frmCurrencyMainMenueScreen()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            // Create a Pen with the desired color and width
            Pen pen = new Pen(Color.White, 1);

            // Define the start and end points for the line
            Point startPoint = new Point(20, 190);
            Point endPoint = new Point(155, 190);

            // Draw the line
            e.Graphics.DrawLine(pen, startPoint, endPoint);

            Pen pen2 = new Pen(Color.White, .5f);
            // Define the start and end points for the line
            Point startPoint2 = new Point(20, 285);
            Point endPoint2 = new Point(155, 285);

            // Draw the line
            e.Graphics.DrawLine(pen2, startPoint2, endPoint2);
        }
        private void frmCurrency_Paint(object sender, PaintEventArgs e)
        {

            // Inside your Paint event handler (e.g., Form1_Paint)

            // Create a pen (color, width, style)
            Pen BluePen = new Pen(System.Drawing.ColorTranslator.FromHtml("#cb764d"), 2);

            // Define the coordinates of the endpoints
            int x1 = 336;
            int y1 = 200;
            int x2 = 685;
            int y2 = 200;

            // Draw the line
            e.Graphics.DrawLine(BluePen, x1, y1, x2, y2);

            Pen BluePen1 = new Pen(System.Drawing.ColorTranslator.FromHtml("#cb764d"), 3);
            int xx1 = 336;
            int yy1 = 205;
            int xx2 = 685;
            int yy2 = 205;

            e.Graphics.DrawLine(BluePen1, xx1, yy1, xx2, yy2);
        }

        private void _ConvertPanelColorWhenHover(Panel panel)
        {
            panel.BackColor = System.Drawing.ColorTranslator.FromHtml("#0a0d0d");

        }
        private void _ConvertPanelColorWhenLeave(Panel panel)
        {
            panel.BackColor = System.Drawing.ColorTranslator.FromHtml("#243031");
        }

        private void panel3_MouseHover(object sender, EventArgs e)
        {
            _ConvertPanelColorWhenHover((Panel)sender);
        }

        private void panel14_MouseLeave(object sender, EventArgs e)
        {
            _ConvertPanelColorWhenLeave((Panel)sender);
        }

        private void pbClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void pictureBox1_MouseHover(object sender, EventArgs e)
        {
            pbClose.BackColor = System.Drawing.ColorTranslator.FromHtml("#d3e1ed");

        }
        private void pictureBox1_MouseLeave(object sender, EventArgs e)
        {
            pbClose.BackColor = System.Drawing.ColorTranslator.FromHtml("#e7edf2");
        }




        private void panel14_Click(object sender, EventArgs e)
        {

            MessageBox.Show("Avalibal soon...");
        }

        //Currncy list
        private void panel3_Click(object sender, EventArgs e)
        {
            frmCurrencyList List = new frmCurrencyList();
            List.ShowDialog();
        }
        private void label3_Click(object sender, EventArgs e)
        {
            panel3_Click(null, null);
        }

        //Find Currency
        private void panel4_Click(object sender, EventArgs e)
        {
            frmFindCurrency FindCurrency = new frmFindCurrency();
            FindCurrency.ShowDialog();
        }
        private void label4_Click(object sender, EventArgs e)
        {
            panel4_Click(null,null);
        }

        //Currency Calculator
        private void panel5_Click(object sender, EventArgs e)
        {
            frmCurrencyCalculator Calculator = new frmCurrencyCalculator();
            Calculator.ShowDialog();
        }
        private void label5_Click(object sender, EventArgs e)
        {
            panel5_Click(null, null);
        }
    }
}
