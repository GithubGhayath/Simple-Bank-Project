﻿namespace Bank.Currency
{
    partial class frmFindCurrency
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.gbtnClose = new Guna.UI2.WinForms.Guna2Button();
            this.gbtnFind = new Guna.UI2.WinForms.Guna2Button();
            this.label3 = new System.Windows.Forms.Label();
            this.cbCurrencyCodes = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lblCurrencyRate = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Bank.Properties.Resources.dollar;
            this.pictureBox1.Location = new System.Drawing.Point(15, 8);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(64, 64);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(82, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 22);
            this.label1.TabIndex = 1;
            this.label1.Text = "Find";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(118)))), ((int)(((byte)(77)))));
            this.label2.Location = new System.Drawing.Point(122, 29);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 22);
            this.label2.TabIndex = 2;
            this.label2.Text = "Currency";
            // 
            // gbtnClose
            // 
            this.gbtnClose.Animated = true;
            this.gbtnClose.AutoRoundedCorners = true;
            this.gbtnClose.BorderRadius = 9;
            this.gbtnClose.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.gbtnClose.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.gbtnClose.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.gbtnClose.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.gbtnClose.FillColor = System.Drawing.Color.Red;
            this.gbtnClose.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gbtnClose.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.gbtnClose.Location = new System.Drawing.Point(361, 203);
            this.gbtnClose.Name = "gbtnClose";
            this.gbtnClose.Size = new System.Drawing.Size(90, 20);
            this.gbtnClose.TabIndex = 20;
            this.gbtnClose.Text = "Close";
            this.gbtnClose.Click += new System.EventHandler(this.gbtnClose_Click);
            // 
            // gbtnFind
            // 
            this.gbtnFind.Animated = true;
            this.gbtnFind.AutoRoundedCorners = true;
            this.gbtnFind.BorderRadius = 9;
            this.gbtnFind.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.gbtnFind.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.gbtnFind.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.gbtnFind.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.gbtnFind.Enabled = false;
            this.gbtnFind.FillColor = System.Drawing.Color.Lime;
            this.gbtnFind.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gbtnFind.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.gbtnFind.Location = new System.Drawing.Point(460, 203);
            this.gbtnFind.Name = "gbtnFind";
            this.gbtnFind.Size = new System.Drawing.Size(90, 20);
            this.gbtnFind.TabIndex = 19;
            this.gbtnFind.Text = "Find";
            this.gbtnFind.Click += new System.EventHandler(this.gbtnFind_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label3.Location = new System.Drawing.Point(72, 121);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(124, 15);
            this.label3.TabIndex = 22;
            this.label3.Text = "Enter Currency Code:";
            // 
            // cbCurrencyCodes
            // 
            this.cbCurrencyCodes.DropDownHeight = 150;
            this.cbCurrencyCodes.FormattingEnabled = true;
            this.cbCurrencyCodes.IntegralHeight = false;
            this.cbCurrencyCodes.Location = new System.Drawing.Point(203, 118);
            this.cbCurrencyCodes.Name = "cbCurrencyCodes";
            this.cbCurrencyCodes.Size = new System.Drawing.Size(248, 21);
            this.cbCurrencyCodes.TabIndex = 23;
            this.cbCurrencyCodes.SelectedIndexChanged += new System.EventHandler(this.cbCurrencyCodes_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label4.Location = new System.Drawing.Point(92, 158);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(104, 15);
            this.label4.TabIndex = 24;
            this.label4.Text = "Rate Per 1 Doller:";
            // 
            // lblCurrencyRate
            // 
            this.lblCurrencyRate.AutoSize = true;
            this.lblCurrencyRate.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCurrencyRate.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblCurrencyRate.Location = new System.Drawing.Point(203, 158);
            this.lblCurrencyRate.Name = "lblCurrencyRate";
            this.lblCurrencyRate.Size = new System.Drawing.Size(34, 15);
            this.lblCurrencyRate.TabIndex = 25;
            this.lblCurrencyRate.Text = "[???]";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 6.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label5.Location = new System.Drawing.Point(113, 80);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(315, 24);
            this.label5.TabIndex = 26;
            this.label5.Text = "*You drop list down to find what currency code you want to check the rate\r\nOr you" +
    " can search for the code inside the box";
            // 
            // frmFindCurrency
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(45)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(562, 233);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblCurrencyRate);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cbCurrencyCodes);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.gbtnClose);
            this.Controls.Add(this.gbtnFind);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmFindCurrency";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmFindCurrency";
            this.Load += new System.EventHandler(this.frmFindCurrency_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2Button gbtnClose;
        private Guna.UI2.WinForms.Guna2Button gbtnFind;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbCurrencyCodes;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblCurrencyRate;
        private System.Windows.Forms.Label label5;
    }
}