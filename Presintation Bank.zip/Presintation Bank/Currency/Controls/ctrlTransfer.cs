﻿using Bank.Generals;
using BankBusinessLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bank.Currency.Controls
{
    public partial class ctrlTransfer : UserControl
    {
        Form FormForClose;
        private void _CustomInterface()
        {

            lblTitle.ForeColor = System.Drawing.ColorTranslator.FromHtml("#cb764d");
            this.BackColor = System.Drawing.ColorTranslator.FromHtml("#243031");
            panel1.BackColor = System.Drawing.ColorTranslator.FromHtml("#43585A");
            txtFromaAccount.Text = clsGloablClient.CurrentClient.PersonInfo.accountNumber;
        }
            public ctrlTransfer()
        {
            InitializeComponent();
        }

        private void ctrlTransfer_Load(object sender, EventArgs e)
        {
            _CustomInterface();
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(char.IsLetter(e.KeyChar))
            { e.Handled = true; }
        }

        private void textBox3_Validating(object sender, CancelEventArgs e)
        {

            if (Convert.ToDecimal(txtAmount.Text) < 0)
            {
                errorProvider1.SetError(txtAmount, "it must to be positive");
                e.Cancel = true;
            }
            else
                e.Cancel = false;
        }

        private void gbtnTransfer_Click(object sender, EventArgs e)
        {
            if(string.IsNullOrEmpty(txtAmount.Text)|| string.IsNullOrEmpty(txtFromaAccount.Text)|| string.IsNullOrEmpty(txtToAccount.Text))
            {
                MessageBox.Show("All fields are required", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (MessageBox.Show("Are you sure you want to perform Transfer", "Confirm", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                if (clsGloablClient.CurrentClient.Transfer(txtToAccount.Text, Convert.ToDecimal(txtAmount.Text)))
                {
                    MessageBox.Show("Transfer Done successfuly", "info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                    MessageBox.Show("Something wrong!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            else
                MessageBox.Show("Transfer canceled successfuly", "info", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        public void _PerentFormForClose(Form perent)
        {
            FormForClose = perent;
        }

        private void gbtnClose_Click(object sender, EventArgs e)
        {
            FormForClose.Close();
        }

     
    }
}
