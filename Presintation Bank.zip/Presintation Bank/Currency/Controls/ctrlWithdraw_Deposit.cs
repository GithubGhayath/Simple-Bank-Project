﻿using Bank.Generals;
using BankBusinessLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bank.Currency.Controls
{
    public partial class ctrlWithdraw_Deposit : UserControl
    {
        Form ForPerformClose;

        private enum enMode { Deposit = 1, Withdraw = 2 }
        private enMode Mode { get; set; }

        public int eMode { get; set; }

        private void _ControlMode()
        {
            this.Mode = (eMode == 1) ? enMode.Deposit : enMode.Withdraw;
        }
        private void _CustomInterface()
        {

            lblTitle.ForeColor = System.Drawing.ColorTranslator.FromHtml("#cb764d");
            this.BackColor = System.Drawing.ColorTranslator.FromHtml("#243031");
            gbtnWithdraw.FillColor = System.Drawing.ColorTranslator.FromHtml("#1fbf66");
            panel1.BackColor = System.Drawing.ColorTranslator.FromHtml("#43585A");
            lblClientID.Text = clsGloablClient.CurrentClient.ClientID.ToString();
            lblAccountNumber.Text = clsGloablClient.CurrentClient.PersonInfo.accountNumber;
            lblAccountBalance.Text = clsGloablClient.CurrentClient.PersonInfo.accountBalance.ToString();


            //Reminde Img
            if (Mode == enMode.Deposit)
            {
                lblTitle.Text = "Deposit Screen";
                lblDescription.Text = "Verify the account number to which you will deposit.\r\n*You can deposit any amount you want.\r\n*All deposits are recorded";
                gbtnWithdraw.Text = "Deposit";
            }
            else
            {
                gbtnWithdraw.Text = "Withdraw";
                lblTitle.Text = "Withdraw Screen";
                lblDescription.Text = "*The balance to be withdrawn must be less than your balance 10$\r\n*The account cannot be left empty.\r\n*All empty accounts are deleted when filtering\r\n*All withdrawals are recorded";
            }
        }
        public ctrlWithdraw_Deposit()
        {
            InitializeComponent();
        }

        private void ctrlWithdraw_Load(object sender, EventArgs e)
        {
            if (!DesignMode)
            {
                _ControlMode();
                _CustomInterface();
            }
        }

        private void gbtnWithdraw_Click(object sender, EventArgs e)
        {
            if(string.IsNullOrEmpty(txtAmount.Text))
            {
                MessageBox.Show("You must fill the field first", "info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (this.Mode == enMode.Withdraw)
            {
                if (MessageBox.Show("Are you sure you want to perform this withdraw", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    if (clsGloablClient.CurrentClient.Withdraw(Convert.ToInt32(txtAmount.Text)))
                    {
                        lblAccountBalance.Text = clsClientsBusinessLayer.Find(clsGloablClient.CurrentClient.ClientID).PersonInfo.accountBalance.ToString();
                        MessageBox.Show($"The withdraw done successfuly with amount: {txtAmount.Text} from account Number: {clsGloablClient.CurrentClient.PersonInfo.accountNumber}", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information); 
                    }
                    else
                        MessageBox.Show($"You can't withdraw \nYour balance is " + clsGloablClient.CurrentClient.PersonInfo.accountBalance, "fail", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                    MessageBox.Show("Operation canceled successfuly", "info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if (this.Mode==enMode.Deposit)
            {
                if (MessageBox.Show("Are you sure you want to perform this Deposit", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    if (clsGloablClient.CurrentClient.Deposit(Convert.ToInt32(txtAmount.Text)))
                    {
                        lblAccountBalance.Text = clsClientsBusinessLayer.Find(clsGloablClient.CurrentClient.ClientID).PersonInfo.accountBalance.ToString();
                        MessageBox.Show($"The Deposit done successfuly with amount: {txtAmount.Text} from account Number: {clsGloablClient.CurrentClient.PersonInfo.accountNumber}", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                        MessageBox.Show($"Something wrong!", "fail", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                    MessageBox.Show("Operation canceled successfuly", "info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void txtAmount_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(char.IsLetter(e.KeyChar))
            { e.Handled = true; }
        }

        public void ClosePerentForm(Form Perent)
        {
            ForPerformClose = Perent;
        }
        private void gbtnClose_Click(object sender, EventArgs e)
        {
            ForPerformClose.Close();
            clsGloablClient.CurrentClient = clsClientsBusinessLayer.Find(clsGloablClient.CurrentClient.ClientID);
        }

        private void txtAmount_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(txtAmount.Text)) return;
            if (Convert.ToDecimal(txtAmount.Text) < 0)
            {
                errorProvider1.SetError(txtAmount, "Enter Positive Value");
                e.Cancel = true;
            }
            else
                e.Cancel = false;
                
        }
    }
}
