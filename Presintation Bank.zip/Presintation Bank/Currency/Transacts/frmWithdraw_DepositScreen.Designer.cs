﻿namespace Bank.Currency
{
    partial class frmWithdraw_DepositScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ctrlWithdraw_Deposit1 = new Bank.Currency.Controls.ctrlWithdraw_Deposit();
            this.SuspendLayout();
            // 
            // ctrlWithdraw_Deposit1
            // 
            this.ctrlWithdraw_Deposit1.eMode = 0;
            this.ctrlWithdraw_Deposit1.Location = new System.Drawing.Point(0, 0);
            this.ctrlWithdraw_Deposit1.Name = "ctrlWithdraw_Deposit1";
            this.ctrlWithdraw_Deposit1.Size = new System.Drawing.Size(477, 319);
            this.ctrlWithdraw_Deposit1.TabIndex = 0;
            // 
            // frmWithdraw_DepositScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(469, 319);
            this.Controls.Add(this.ctrlWithdraw_Deposit1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmWithdraw_DepositScreen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmWithdraw_DepositScreen";
            this.Load += new System.EventHandler(this.frmWithdraw_DepositScreen_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private Controls.ctrlWithdraw_Deposit ctrlWithdraw_Deposit1;
    }
}