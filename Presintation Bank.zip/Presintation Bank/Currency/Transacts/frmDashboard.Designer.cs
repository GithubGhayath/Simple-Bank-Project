﻿namespace Bank.Currency
{
    partial class frmDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDashboard));
            this.ccTransferDiagram = new LiveCharts.WinForms.CartesianChart();
            this.ccWithdrawal_Deposit = new LiveCharts.WinForms.CartesianChart();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button2 = new Guna.UI2.WinForms.Guna2Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.guna2ShadowPanel1 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.label3 = new System.Windows.Forms.Label();
            this.guna2ShadowPanel2 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.label5 = new System.Windows.Forms.Label();
            this.guna2ShadowPanel3 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.lblTotalCommission = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.guna2ShadowPanel4 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.pbImageInSum = new System.Windows.Forms.PictureBox();
            this.lblSumCommission = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.guna2ShadowPanel5 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.pbImageInAVG = new System.Windows.Forms.PictureBox();
            this.lblAVGCommission = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.guna2ShadowPanel6 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.lblTotalWithdrawal = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.guna2ShadowPanel7 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.lblTotalDeposit = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.guna2CircleButton1 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.label8 = new System.Windows.Forms.Label();
            this.guna2ShadowPanel8 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.label10 = new System.Windows.Forms.Label();
            this.lblFirst = new System.Windows.Forms.Label();
            this.lblSecond = new System.Windows.Forms.Label();
            this.lblThird = new System.Windows.Forms.Label();
            this.lblSixth = new System.Windows.Forms.Label();
            this.lblFourth = new System.Windows.Forms.Label();
            this.lblFifth = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.gpbMaxT = new Guna.UI2.WinForms.Guna2ProgressBar();
            this.gpbLess1T = new Guna.UI2.WinForms.Guna2ProgressBar();
            this.gpbLess2T = new Guna.UI2.WinForms.Guna2ProgressBar();
            this.gpbLess3T = new Guna.UI2.WinForms.Guna2ProgressBar();
            this.gpbLess4T = new Guna.UI2.WinForms.Guna2ProgressBar();
            this.gpbMinT = new Guna.UI2.WinForms.Guna2ProgressBar();
            this.guna2ShadowPanel11 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.gpbMinW = new Guna.UI2.WinForms.Guna2ProgressBar();
            this.gpbLess4W = new Guna.UI2.WinForms.Guna2ProgressBar();
            this.gpbLess3W = new Guna.UI2.WinForms.Guna2ProgressBar();
            this.gpbLess2W = new Guna.UI2.WinForms.Guna2ProgressBar();
            this.gpbLess1W = new Guna.UI2.WinForms.Guna2ProgressBar();
            this.gpbMaxW = new Guna.UI2.WinForms.Guna2ProgressBar();
            this.lblFirstW = new System.Windows.Forms.Label();
            this.lblSecondW = new System.Windows.Forms.Label();
            this.lblThirdW = new System.Windows.Forms.Label();
            this.lblSixthW = new System.Windows.Forms.Label();
            this.lblFourthW = new System.Windows.Forms.Label();
            this.lblFifthW = new System.Windows.Forms.Label();
            this.guna2ShadowPanel10 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.gpbMinD = new Guna.UI2.WinForms.Guna2ProgressBar();
            this.gpbLess4D = new Guna.UI2.WinForms.Guna2ProgressBar();
            this.gpbLess3D = new Guna.UI2.WinForms.Guna2ProgressBar();
            this.gpbLess2D = new Guna.UI2.WinForms.Guna2ProgressBar();
            this.gpbLess1D = new Guna.UI2.WinForms.Guna2ProgressBar();
            this.gpbMaxD = new Guna.UI2.WinForms.Guna2ProgressBar();
            this.lblFirstD = new System.Windows.Forms.Label();
            this.lblSecondD = new System.Windows.Forms.Label();
            this.lblThirdD = new System.Windows.Forms.Label();
            this.lblSixthD = new System.Windows.Forms.Label();
            this.lblFourthD = new System.Windows.Forms.Label();
            this.lblFifthD = new System.Windows.Forms.Label();
            this.guna2ShadowPanel1.SuspendLayout();
            this.guna2ShadowPanel2.SuspendLayout();
            this.guna2ShadowPanel3.SuspendLayout();
            this.guna2ShadowPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbImageInSum)).BeginInit();
            this.guna2ShadowPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbImageInAVG)).BeginInit();
            this.guna2ShadowPanel6.SuspendLayout();
            this.guna2ShadowPanel7.SuspendLayout();
            this.panel1.SuspendLayout();
            this.guna2ShadowPanel8.SuspendLayout();
            this.guna2ShadowPanel11.SuspendLayout();
            this.guna2ShadowPanel10.SuspendLayout();
            this.SuspendLayout();
            // 
            // ccTransferDiagram
            // 
            this.ccTransferDiagram.Location = new System.Drawing.Point(16, 32);
            this.ccTransferDiagram.Name = "ccTransferDiagram";
            this.ccTransferDiagram.Size = new System.Drawing.Size(524, 194);
            this.ccTransferDiagram.TabIndex = 0;
            this.ccTransferDiagram.Text = "cartesianChart1";
            // 
            // ccWithdrawal_Deposit
            // 
            this.ccWithdrawal_Deposit.Location = new System.Drawing.Point(25, 40);
            this.ccWithdrawal_Deposit.Name = "ccWithdrawal_Deposit";
            this.ccWithdrawal_Deposit.Size = new System.Drawing.Size(524, 194);
            this.ccWithdrawal_Deposit.TabIndex = 1;
            this.ccWithdrawal_Deposit.Text = "cartesianChart1";
            // 
            // guna2Button1
            // 
            this.guna2Button1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button1.FillColor = System.Drawing.SystemColors.HotTrack;
            this.guna2Button1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button1.ForeColor = System.Drawing.Color.White;
            this.guna2Button1.Location = new System.Drawing.Point(177, 24);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.Size = new System.Drawing.Size(25, 10);
            this.guna2Button1.TabIndex = 2;
            this.guna2Button1.Text = "guna2Button1";
            // 
            // guna2Button2
            // 
            this.guna2Button2.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button2.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button2.FillColor = System.Drawing.Color.Red;
            this.guna2Button2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button2.ForeColor = System.Drawing.Color.White;
            this.guna2Button2.Location = new System.Drawing.Point(267, 24);
            this.guna2Button2.Name = "guna2Button2";
            this.guna2Button2.Size = new System.Drawing.Size(25, 10);
            this.guna2Button2.TabIndex = 3;
            this.guna2Button2.Text = "guna2Button2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(202, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 14);
            this.label1.TabIndex = 4;
            this.label1.Text = "Withdraw";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(292, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 14);
            this.label2.TabIndex = 5;
            this.label2.Text = "Deposit";
            // 
            // guna2ShadowPanel1
            // 
            this.guna2ShadowPanel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2ShadowPanel1.Controls.Add(this.ccTransferDiagram);
            this.guna2ShadowPanel1.Controls.Add(this.label3);
            this.guna2ShadowPanel1.FillColor = System.Drawing.Color.White;
            this.guna2ShadowPanel1.Location = new System.Drawing.Point(8, 130);
            this.guna2ShadowPanel1.Name = "guna2ShadowPanel1";
            this.guna2ShadowPanel1.Radius = 8;
            this.guna2ShadowPanel1.ShadowColor = System.Drawing.Color.Gray;
            this.guna2ShadowPanel1.ShadowDepth = 150;
            this.guna2ShadowPanel1.Size = new System.Drawing.Size(589, 237);
            this.guna2ShadowPanel1.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(16, 12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 16);
            this.label3.TabIndex = 8;
            this.label3.Text = "Transfer Chart";
            // 
            // guna2ShadowPanel2
            // 
            this.guna2ShadowPanel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2ShadowPanel2.Controls.Add(this.label5);
            this.guna2ShadowPanel2.Controls.Add(this.guna2Button1);
            this.guna2ShadowPanel2.Controls.Add(this.label2);
            this.guna2ShadowPanel2.Controls.Add(this.ccWithdrawal_Deposit);
            this.guna2ShadowPanel2.Controls.Add(this.label1);
            this.guna2ShadowPanel2.Controls.Add(this.guna2Button2);
            this.guna2ShadowPanel2.FillColor = System.Drawing.Color.White;
            this.guna2ShadowPanel2.Location = new System.Drawing.Point(604, 130);
            this.guna2ShadowPanel2.Name = "guna2ShadowPanel2";
            this.guna2ShadowPanel2.Radius = 8;
            this.guna2ShadowPanel2.ShadowColor = System.Drawing.Color.Gray;
            this.guna2ShadowPanel2.ShadowDepth = 150;
            this.guna2ShadowPanel2.Size = new System.Drawing.Size(589, 237);
            this.guna2ShadowPanel2.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(25, 21);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(134, 16);
            this.label5.TabIndex = 9;
            this.label5.Text = "Withdraw - Deposit Chart";
            // 
            // guna2ShadowPanel3
            // 
            this.guna2ShadowPanel3.BackColor = System.Drawing.Color.Transparent;
            this.guna2ShadowPanel3.Controls.Add(this.lblTotalCommission);
            this.guna2ShadowPanel3.Controls.Add(this.label4);
            this.guna2ShadowPanel3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(221)))), ((int)(((byte)(139)))));
            this.guna2ShadowPanel3.Location = new System.Drawing.Point(24, 46);
            this.guna2ShadowPanel3.Name = "guna2ShadowPanel3";
            this.guna2ShadowPanel3.Radius = 8;
            this.guna2ShadowPanel3.ShadowColor = System.Drawing.Color.Gray;
            this.guna2ShadowPanel3.ShadowDepth = 150;
            this.guna2ShadowPanel3.Size = new System.Drawing.Size(142, 78);
            this.guna2ShadowPanel3.TabIndex = 9;
            // 
            // lblTotalCommission
            // 
            this.lblTotalCommission.AutoSize = true;
            this.lblTotalCommission.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalCommission.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(74)))), ((int)(((byte)(105)))));
            this.lblTotalCommission.Location = new System.Drawing.Point(16, 32);
            this.lblTotalCommission.Name = "lblTotalCommission";
            this.lblTotalCommission.Size = new System.Drawing.Size(28, 14);
            this.lblTotalCommission.TabIndex = 9;
            this.lblTotalCommission.Text = "[???]";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(74)))), ((int)(((byte)(105)))));
            this.label4.Location = new System.Drawing.Point(16, 12);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(93, 14);
            this.label4.TabIndex = 8;
            this.label4.Text = "Total Commission:";
            // 
            // guna2ShadowPanel4
            // 
            this.guna2ShadowPanel4.BackColor = System.Drawing.Color.Transparent;
            this.guna2ShadowPanel4.Controls.Add(this.pbImageInSum);
            this.guna2ShadowPanel4.Controls.Add(this.lblSumCommission);
            this.guna2ShadowPanel4.Controls.Add(this.label6);
            this.guna2ShadowPanel4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(231)))), ((int)(((byte)(240)))));
            this.guna2ShadowPanel4.Location = new System.Drawing.Point(342, 46);
            this.guna2ShadowPanel4.Name = "guna2ShadowPanel4";
            this.guna2ShadowPanel4.Radius = 8;
            this.guna2ShadowPanel4.ShadowColor = System.Drawing.Color.Gray;
            this.guna2ShadowPanel4.ShadowDepth = 150;
            this.guna2ShadowPanel4.Size = new System.Drawing.Size(142, 78);
            this.guna2ShadowPanel4.TabIndex = 10;
            // 
            // pbImageInSum
            // 
            this.pbImageInSum.Image = ((System.Drawing.Image)(resources.GetObject("pbImageInSum.Image")));
            this.pbImageInSum.Location = new System.Drawing.Point(96, 41);
            this.pbImageInSum.Name = "pbImageInSum";
            this.pbImageInSum.Size = new System.Drawing.Size(20, 20);
            this.pbImageInSum.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbImageInSum.TabIndex = 12;
            this.pbImageInSum.TabStop = false;
            // 
            // lblSumCommission
            // 
            this.lblSumCommission.AutoSize = true;
            this.lblSumCommission.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSumCommission.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(74)))), ((int)(((byte)(105)))));
            this.lblSumCommission.Location = new System.Drawing.Point(16, 48);
            this.lblSumCommission.Name = "lblSumCommission";
            this.lblSumCommission.Size = new System.Drawing.Size(28, 14);
            this.lblSumCommission.TabIndex = 9;
            this.lblSumCommission.Text = "[???]";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(74)))), ((int)(((byte)(105)))));
            this.label6.Location = new System.Drawing.Point(16, 12);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 28);
            this.label6.TabIndex = 8;
            this.label6.Text = "Sum of commission\r\nLast 10 Days:";
            // 
            // guna2ShadowPanel5
            // 
            this.guna2ShadowPanel5.BackColor = System.Drawing.Color.Transparent;
            this.guna2ShadowPanel5.Controls.Add(this.pbImageInAVG);
            this.guna2ShadowPanel5.Controls.Add(this.lblAVGCommission);
            this.guna2ShadowPanel5.Controls.Add(this.label7);
            this.guna2ShadowPanel5.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(221)))), ((int)(((byte)(224)))));
            this.guna2ShadowPanel5.Location = new System.Drawing.Point(183, 46);
            this.guna2ShadowPanel5.Name = "guna2ShadowPanel5";
            this.guna2ShadowPanel5.Radius = 8;
            this.guna2ShadowPanel5.ShadowColor = System.Drawing.Color.Gray;
            this.guna2ShadowPanel5.ShadowDepth = 150;
            this.guna2ShadowPanel5.Size = new System.Drawing.Size(142, 78);
            this.guna2ShadowPanel5.TabIndex = 10;
            // 
            // pbImageInAVG
            // 
            this.pbImageInAVG.Image = global::Bank.Properties.Resources.Line;
            this.pbImageInAVG.Location = new System.Drawing.Point(102, 41);
            this.pbImageInAVG.Name = "pbImageInAVG";
            this.pbImageInAVG.Size = new System.Drawing.Size(20, 20);
            this.pbImageInAVG.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbImageInAVG.TabIndex = 11;
            this.pbImageInAVG.TabStop = false;
            // 
            // lblAVGCommission
            // 
            this.lblAVGCommission.AutoSize = true;
            this.lblAVGCommission.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAVGCommission.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(74)))), ((int)(((byte)(105)))));
            this.lblAVGCommission.Location = new System.Drawing.Point(16, 48);
            this.lblAVGCommission.Name = "lblAVGCommission";
            this.lblAVGCommission.Size = new System.Drawing.Size(28, 14);
            this.lblAVGCommission.TabIndex = 9;
            this.lblAVGCommission.Text = "[???]";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(74)))), ((int)(((byte)(105)))));
            this.label7.Location = new System.Drawing.Point(16, 12);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(101, 28);
            this.label7.TabIndex = 8;
            this.label7.Text = "Avg of Commission \r\nlast 10 Days:";
            // 
            // guna2ShadowPanel6
            // 
            this.guna2ShadowPanel6.BackColor = System.Drawing.Color.Transparent;
            this.guna2ShadowPanel6.Controls.Add(this.lblTotalWithdrawal);
            this.guna2ShadowPanel6.Controls.Add(this.label9);
            this.guna2ShadowPanel6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(221)))), ((int)(((byte)(139)))));
            this.guna2ShadowPanel6.Location = new System.Drawing.Point(621, 46);
            this.guna2ShadowPanel6.Name = "guna2ShadowPanel6";
            this.guna2ShadowPanel6.Radius = 8;
            this.guna2ShadowPanel6.ShadowColor = System.Drawing.Color.Gray;
            this.guna2ShadowPanel6.ShadowDepth = 150;
            this.guna2ShadowPanel6.Size = new System.Drawing.Size(142, 78);
            this.guna2ShadowPanel6.TabIndex = 10;
            // 
            // lblTotalWithdrawal
            // 
            this.lblTotalWithdrawal.AutoSize = true;
            this.lblTotalWithdrawal.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalWithdrawal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(74)))), ((int)(((byte)(105)))));
            this.lblTotalWithdrawal.Location = new System.Drawing.Point(16, 49);
            this.lblTotalWithdrawal.Name = "lblTotalWithdrawal";
            this.lblTotalWithdrawal.Size = new System.Drawing.Size(28, 14);
            this.lblTotalWithdrawal.TabIndex = 9;
            this.lblTotalWithdrawal.Text = "[???]";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(74)))), ((int)(((byte)(105)))));
            this.label9.Location = new System.Drawing.Point(16, 12);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(81, 28);
            this.label9.TabIndex = 8;
            this.label9.Text = "Total Withrawal\r\nLast 10 Days:";
            // 
            // guna2ShadowPanel7
            // 
            this.guna2ShadowPanel7.BackColor = System.Drawing.Color.Transparent;
            this.guna2ShadowPanel7.Controls.Add(this.lblTotalDeposit);
            this.guna2ShadowPanel7.Controls.Add(this.label11);
            this.guna2ShadowPanel7.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(221)))), ((int)(((byte)(224)))));
            this.guna2ShadowPanel7.Location = new System.Drawing.Point(780, 46);
            this.guna2ShadowPanel7.Name = "guna2ShadowPanel7";
            this.guna2ShadowPanel7.Radius = 8;
            this.guna2ShadowPanel7.ShadowColor = System.Drawing.Color.Gray;
            this.guna2ShadowPanel7.ShadowDepth = 150;
            this.guna2ShadowPanel7.Size = new System.Drawing.Size(142, 78);
            this.guna2ShadowPanel7.TabIndex = 11;
            // 
            // lblTotalDeposit
            // 
            this.lblTotalDeposit.AutoSize = true;
            this.lblTotalDeposit.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalDeposit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(74)))), ((int)(((byte)(105)))));
            this.lblTotalDeposit.Location = new System.Drawing.Point(16, 49);
            this.lblTotalDeposit.Name = "lblTotalDeposit";
            this.lblTotalDeposit.Size = new System.Drawing.Size(28, 14);
            this.lblTotalDeposit.TabIndex = 9;
            this.lblTotalDeposit.Text = "[???]";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(74)))), ((int)(((byte)(105)))));
            this.label11.Location = new System.Drawing.Point(16, 12);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(70, 28);
            this.label11.TabIndex = 8;
            this.label11.Text = "Total Deposit\r\nLast 10 Days:\r\n";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.guna2CircleButton1);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1225, 37);
            this.panel1.TabIndex = 12;
            // 
            // guna2CircleButton1
            // 
            this.guna2CircleButton1.Animated = true;
            this.guna2CircleButton1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2CircleButton1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2CircleButton1.FillColor = System.Drawing.Color.Red;
            this.guna2CircleButton1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2CircleButton1.ForeColor = System.Drawing.Color.White;
            this.guna2CircleButton1.Location = new System.Drawing.Point(1189, 3);
            this.guna2CircleButton1.Name = "guna2CircleButton1";
            this.guna2CircleButton1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton1.Size = new System.Drawing.Size(30, 30);
            this.guna2CircleButton1.TabIndex = 7;
            this.guna2CircleButton1.Text = "X";
            this.guna2CircleButton1.Click += new System.EventHandler(this.guna2CircleButton1_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Bahnschrift SemiBold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label8.Location = new System.Drawing.Point(42, 4);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(199, 25);
            this.label8.TabIndex = 0;
            this.label8.Text = "Transact Dashboard";
            // 
            // guna2ShadowPanel8
            // 
            this.guna2ShadowPanel8.BackColor = System.Drawing.Color.Transparent;
            this.guna2ShadowPanel8.Controls.Add(this.gpbMinT);
            this.guna2ShadowPanel8.Controls.Add(this.gpbLess4T);
            this.guna2ShadowPanel8.Controls.Add(this.gpbLess3T);
            this.guna2ShadowPanel8.Controls.Add(this.gpbLess2T);
            this.guna2ShadowPanel8.Controls.Add(this.gpbLess1T);
            this.guna2ShadowPanel8.Controls.Add(this.gpbMaxT);
            this.guna2ShadowPanel8.Controls.Add(this.lblFirst);
            this.guna2ShadowPanel8.Controls.Add(this.lblSecond);
            this.guna2ShadowPanel8.Controls.Add(this.lblThird);
            this.guna2ShadowPanel8.Controls.Add(this.lblSixth);
            this.guna2ShadowPanel8.Controls.Add(this.lblFourth);
            this.guna2ShadowPanel8.Controls.Add(this.lblFifth);
            this.guna2ShadowPanel8.Controls.Add(this.label10);
            this.guna2ShadowPanel8.FillColor = System.Drawing.Color.White;
            this.guna2ShadowPanel8.Location = new System.Drawing.Point(24, 376);
            this.guna2ShadowPanel8.Name = "guna2ShadowPanel8";
            this.guna2ShadowPanel8.Radius = 8;
            this.guna2ShadowPanel8.ShadowColor = System.Drawing.Color.Gray;
            this.guna2ShadowPanel8.ShadowDepth = 150;
            this.guna2ShadowPanel8.Size = new System.Drawing.Size(392, 225);
            this.guna2ShadowPanel8.TabIndex = 9;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(20, 12);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(171, 16);
            this.label10.TabIndex = 8;
            this.label10.Text = "The most clients make transfers:";
            // 
            // lblFirst
            // 
            this.lblFirst.AutoSize = true;
            this.lblFirst.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblFirst.Font = new System.Drawing.Font("HoloLens MDL2 Assets", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFirst.Location = new System.Drawing.Point(18, 48);
            this.lblFirst.Name = "lblFirst";
            this.lblFirst.Size = new System.Drawing.Size(29, 12);
            this.lblFirst.TabIndex = 20;
            this.lblFirst.Text = "label1";
            // 
            // lblSecond
            // 
            this.lblSecond.AutoSize = true;
            this.lblSecond.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblSecond.Font = new System.Drawing.Font("HoloLens MDL2 Assets", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecond.Location = new System.Drawing.Point(18, 77);
            this.lblSecond.Name = "lblSecond";
            this.lblSecond.Size = new System.Drawing.Size(29, 12);
            this.lblSecond.TabIndex = 21;
            this.lblSecond.Text = "label2";
            // 
            // lblThird
            // 
            this.lblThird.AutoSize = true;
            this.lblThird.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblThird.Font = new System.Drawing.Font("HoloLens MDL2 Assets", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblThird.Location = new System.Drawing.Point(18, 106);
            this.lblThird.Name = "lblThird";
            this.lblThird.Size = new System.Drawing.Size(29, 12);
            this.lblThird.TabIndex = 24;
            this.lblThird.Text = "label5";
            // 
            // lblSixth
            // 
            this.lblSixth.AutoSize = true;
            this.lblSixth.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblSixth.Font = new System.Drawing.Font("HoloLens MDL2 Assets", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSixth.Location = new System.Drawing.Point(18, 193);
            this.lblSixth.Name = "lblSixth";
            this.lblSixth.Size = new System.Drawing.Size(29, 12);
            this.lblSixth.TabIndex = 25;
            this.lblSixth.Text = "label6";
            // 
            // lblFourth
            // 
            this.lblFourth.AutoSize = true;
            this.lblFourth.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblFourth.Font = new System.Drawing.Font("HoloLens MDL2 Assets", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFourth.Location = new System.Drawing.Point(18, 135);
            this.lblFourth.Name = "lblFourth";
            this.lblFourth.Size = new System.Drawing.Size(29, 12);
            this.lblFourth.TabIndex = 23;
            this.lblFourth.Text = "label4";
            // 
            // lblFifth
            // 
            this.lblFifth.AutoSize = true;
            this.lblFifth.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblFifth.Font = new System.Drawing.Font("HoloLens MDL2 Assets", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFifth.Location = new System.Drawing.Point(18, 164);
            this.lblFifth.Name = "lblFifth";
            this.lblFifth.Size = new System.Drawing.Size(29, 12);
            this.lblFifth.TabIndex = 22;
            this.lblFifth.Text = "label3";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(27, 12);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(178, 16);
            this.label25.TabIndex = 8;
            this.label25.Text = "The most clients make Withdraws:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Bahnschrift SemiCondensed", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(26, 17);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(167, 16);
            this.label18.TabIndex = 8;
            this.label18.Text = "The most clients make Deposits:";
            // 
            // gpbMaxT
            // 
            this.gpbMaxT.Location = new System.Drawing.Point(122, 44);
            this.gpbMaxT.Name = "gpbMaxT";
            this.gpbMaxT.Size = new System.Drawing.Size(250, 20);
            this.gpbMaxT.TabIndex = 26;
            this.gpbMaxT.Text = "guna2ProgressBar1";
            this.gpbMaxT.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            // 
            // gpbLess1T
            // 
            this.gpbLess1T.Location = new System.Drawing.Point(122, 73);
            this.gpbLess1T.Name = "gpbLess1T";
            this.gpbLess1T.Size = new System.Drawing.Size(250, 20);
            this.gpbLess1T.TabIndex = 27;
            this.gpbLess1T.Text = "guna2ProgressBar1";
            this.gpbLess1T.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            // 
            // gpbLess2T
            // 
            this.gpbLess2T.Location = new System.Drawing.Point(122, 102);
            this.gpbLess2T.Name = "gpbLess2T";
            this.gpbLess2T.Size = new System.Drawing.Size(250, 20);
            this.gpbLess2T.TabIndex = 28;
            this.gpbLess2T.Text = "guna2ProgressBar1";
            this.gpbLess2T.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            // 
            // gpbLess3T
            // 
            this.gpbLess3T.Location = new System.Drawing.Point(122, 131);
            this.gpbLess3T.Name = "gpbLess3T";
            this.gpbLess3T.Size = new System.Drawing.Size(250, 20);
            this.gpbLess3T.TabIndex = 29;
            this.gpbLess3T.Text = "guna2ProgressBar1";
            this.gpbLess3T.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            // 
            // gpbLess4T
            // 
            this.gpbLess4T.Location = new System.Drawing.Point(122, 160);
            this.gpbLess4T.Name = "gpbLess4T";
            this.gpbLess4T.Size = new System.Drawing.Size(250, 20);
            this.gpbLess4T.TabIndex = 30;
            this.gpbLess4T.Text = "guna2ProgressBar1";
            this.gpbLess4T.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            // 
            // gpbMinT
            // 
            this.gpbMinT.Location = new System.Drawing.Point(122, 189);
            this.gpbMinT.Name = "gpbMinT";
            this.gpbMinT.Size = new System.Drawing.Size(250, 20);
            this.gpbMinT.TabIndex = 31;
            this.gpbMinT.Text = "guna2ProgressBar1";
            this.gpbMinT.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            // 
            // guna2ShadowPanel11
            // 
            this.guna2ShadowPanel11.BackColor = System.Drawing.Color.Transparent;
            this.guna2ShadowPanel11.Controls.Add(this.gpbMinW);
            this.guna2ShadowPanel11.Controls.Add(this.gpbLess4W);
            this.guna2ShadowPanel11.Controls.Add(this.gpbLess3W);
            this.guna2ShadowPanel11.Controls.Add(this.gpbLess2W);
            this.guna2ShadowPanel11.Controls.Add(this.gpbLess1W);
            this.guna2ShadowPanel11.Controls.Add(this.gpbMaxW);
            this.guna2ShadowPanel11.Controls.Add(this.lblFirstW);
            this.guna2ShadowPanel11.Controls.Add(this.lblSecondW);
            this.guna2ShadowPanel11.Controls.Add(this.lblThirdW);
            this.guna2ShadowPanel11.Controls.Add(this.lblSixthW);
            this.guna2ShadowPanel11.Controls.Add(this.lblFourthW);
            this.guna2ShadowPanel11.Controls.Add(this.lblFifthW);
            this.guna2ShadowPanel11.Controls.Add(this.label25);
            this.guna2ShadowPanel11.FillColor = System.Drawing.Color.White;
            this.guna2ShadowPanel11.Location = new System.Drawing.Point(422, 376);
            this.guna2ShadowPanel11.Name = "guna2ShadowPanel11";
            this.guna2ShadowPanel11.Radius = 8;
            this.guna2ShadowPanel11.ShadowColor = System.Drawing.Color.Gray;
            this.guna2ShadowPanel11.ShadowDepth = 150;
            this.guna2ShadowPanel11.Size = new System.Drawing.Size(392, 225);
            this.guna2ShadowPanel11.TabIndex = 32;
            // 
            // gpbMinW
            // 
            this.gpbMinW.Location = new System.Drawing.Point(116, 189);
            this.gpbMinW.Name = "gpbMinW";
            this.gpbMinW.Size = new System.Drawing.Size(250, 20);
            this.gpbMinW.TabIndex = 31;
            this.gpbMinW.Text = "guna2ProgressBar1";
            this.gpbMinW.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            // 
            // gpbLess4W
            // 
            this.gpbLess4W.Location = new System.Drawing.Point(116, 160);
            this.gpbLess4W.Name = "gpbLess4W";
            this.gpbLess4W.Size = new System.Drawing.Size(250, 20);
            this.gpbLess4W.TabIndex = 30;
            this.gpbLess4W.Text = "guna2ProgressBar1";
            this.gpbLess4W.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            // 
            // gpbLess3W
            // 
            this.gpbLess3W.Location = new System.Drawing.Point(116, 131);
            this.gpbLess3W.Name = "gpbLess3W";
            this.gpbLess3W.Size = new System.Drawing.Size(250, 20);
            this.gpbLess3W.TabIndex = 29;
            this.gpbLess3W.Text = "guna2ProgressBar1";
            this.gpbLess3W.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            // 
            // gpbLess2W
            // 
            this.gpbLess2W.Location = new System.Drawing.Point(116, 102);
            this.gpbLess2W.Name = "gpbLess2W";
            this.gpbLess2W.Size = new System.Drawing.Size(250, 20);
            this.gpbLess2W.TabIndex = 28;
            this.gpbLess2W.Text = "guna2ProgressBar1";
            this.gpbLess2W.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            // 
            // gpbLess1W
            // 
            this.gpbLess1W.Location = new System.Drawing.Point(116, 73);
            this.gpbLess1W.Name = "gpbLess1W";
            this.gpbLess1W.Size = new System.Drawing.Size(250, 20);
            this.gpbLess1W.TabIndex = 27;
            this.gpbLess1W.Text = "guna2ProgressBar1";
            this.gpbLess1W.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            // 
            // gpbMaxW
            // 
            this.gpbMaxW.Location = new System.Drawing.Point(116, 44);
            this.gpbMaxW.Name = "gpbMaxW";
            this.gpbMaxW.Size = new System.Drawing.Size(250, 20);
            this.gpbMaxW.TabIndex = 26;
            this.gpbMaxW.Text = "guna2ProgressBar1";
            this.gpbMaxW.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            // 
            // lblFirstW
            // 
            this.lblFirstW.AutoSize = true;
            this.lblFirstW.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblFirstW.Font = new System.Drawing.Font("HoloLens MDL2 Assets", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFirstW.Location = new System.Drawing.Point(17, 48);
            this.lblFirstW.Name = "lblFirstW";
            this.lblFirstW.Size = new System.Drawing.Size(29, 12);
            this.lblFirstW.TabIndex = 20;
            this.lblFirstW.Text = "label1";
            // 
            // lblSecondW
            // 
            this.lblSecondW.AutoSize = true;
            this.lblSecondW.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblSecondW.Font = new System.Drawing.Font("HoloLens MDL2 Assets", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecondW.Location = new System.Drawing.Point(17, 77);
            this.lblSecondW.Name = "lblSecondW";
            this.lblSecondW.Size = new System.Drawing.Size(29, 12);
            this.lblSecondW.TabIndex = 21;
            this.lblSecondW.Text = "label2";
            // 
            // lblThirdW
            // 
            this.lblThirdW.AutoSize = true;
            this.lblThirdW.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblThirdW.Font = new System.Drawing.Font("HoloLens MDL2 Assets", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblThirdW.Location = new System.Drawing.Point(17, 106);
            this.lblThirdW.Name = "lblThirdW";
            this.lblThirdW.Size = new System.Drawing.Size(29, 12);
            this.lblThirdW.TabIndex = 24;
            this.lblThirdW.Text = "label5";
            // 
            // lblSixthW
            // 
            this.lblSixthW.AutoSize = true;
            this.lblSixthW.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblSixthW.Font = new System.Drawing.Font("HoloLens MDL2 Assets", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSixthW.Location = new System.Drawing.Point(17, 193);
            this.lblSixthW.Name = "lblSixthW";
            this.lblSixthW.Size = new System.Drawing.Size(29, 12);
            this.lblSixthW.TabIndex = 25;
            this.lblSixthW.Text = "label6";
            // 
            // lblFourthW
            // 
            this.lblFourthW.AutoSize = true;
            this.lblFourthW.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblFourthW.Font = new System.Drawing.Font("HoloLens MDL2 Assets", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFourthW.Location = new System.Drawing.Point(17, 135);
            this.lblFourthW.Name = "lblFourthW";
            this.lblFourthW.Size = new System.Drawing.Size(29, 12);
            this.lblFourthW.TabIndex = 23;
            this.lblFourthW.Text = "label4";
            // 
            // lblFifthW
            // 
            this.lblFifthW.AutoSize = true;
            this.lblFifthW.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblFifthW.Font = new System.Drawing.Font("HoloLens MDL2 Assets", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFifthW.Location = new System.Drawing.Point(17, 164);
            this.lblFifthW.Name = "lblFifthW";
            this.lblFifthW.Size = new System.Drawing.Size(29, 12);
            this.lblFifthW.TabIndex = 22;
            this.lblFifthW.Text = "label3";
            // 
            // guna2ShadowPanel10
            // 
            this.guna2ShadowPanel10.BackColor = System.Drawing.Color.Transparent;
            this.guna2ShadowPanel10.Controls.Add(this.gpbMinD);
            this.guna2ShadowPanel10.Controls.Add(this.gpbLess4D);
            this.guna2ShadowPanel10.Controls.Add(this.gpbLess3D);
            this.guna2ShadowPanel10.Controls.Add(this.gpbLess2D);
            this.guna2ShadowPanel10.Controls.Add(this.gpbLess1D);
            this.guna2ShadowPanel10.Controls.Add(this.gpbMaxD);
            this.guna2ShadowPanel10.Controls.Add(this.lblFirstD);
            this.guna2ShadowPanel10.Controls.Add(this.lblSecondD);
            this.guna2ShadowPanel10.Controls.Add(this.lblThirdD);
            this.guna2ShadowPanel10.Controls.Add(this.lblSixthD);
            this.guna2ShadowPanel10.Controls.Add(this.lblFourthD);
            this.guna2ShadowPanel10.Controls.Add(this.lblFifthD);
            this.guna2ShadowPanel10.Controls.Add(this.label18);
            this.guna2ShadowPanel10.FillColor = System.Drawing.Color.White;
            this.guna2ShadowPanel10.Location = new System.Drawing.Point(819, 376);
            this.guna2ShadowPanel10.Name = "guna2ShadowPanel10";
            this.guna2ShadowPanel10.Radius = 8;
            this.guna2ShadowPanel10.ShadowColor = System.Drawing.Color.Gray;
            this.guna2ShadowPanel10.ShadowDepth = 150;
            this.guna2ShadowPanel10.Size = new System.Drawing.Size(392, 225);
            this.guna2ShadowPanel10.TabIndex = 33;
            // 
            // gpbMinD
            // 
            this.gpbMinD.Location = new System.Drawing.Point(120, 189);
            this.gpbMinD.Name = "gpbMinD";
            this.gpbMinD.Size = new System.Drawing.Size(250, 20);
            this.gpbMinD.TabIndex = 31;
            this.gpbMinD.Text = "guna2ProgressBar7";
            this.gpbMinD.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            // 
            // gpbLess4D
            // 
            this.gpbLess4D.Location = new System.Drawing.Point(120, 160);
            this.gpbLess4D.Name = "gpbLess4D";
            this.gpbLess4D.Size = new System.Drawing.Size(250, 20);
            this.gpbLess4D.TabIndex = 30;
            this.gpbLess4D.Text = "guna2ProgressBar1";
            this.gpbLess4D.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            // 
            // gpbLess3D
            // 
            this.gpbLess3D.Location = new System.Drawing.Point(120, 131);
            this.gpbLess3D.Name = "gpbLess3D";
            this.gpbLess3D.Size = new System.Drawing.Size(250, 20);
            this.gpbLess3D.TabIndex = 29;
            this.gpbLess3D.Text = "guna2ProgressBar1";
            this.gpbLess3D.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            // 
            // gpbLess2D
            // 
            this.gpbLess2D.Location = new System.Drawing.Point(120, 102);
            this.gpbLess2D.Name = "gpbLess2D";
            this.gpbLess2D.Size = new System.Drawing.Size(250, 20);
            this.gpbLess2D.TabIndex = 28;
            this.gpbLess2D.Text = "guna2ProgressBar1";
            this.gpbLess2D.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            // 
            // gpbLess1D
            // 
            this.gpbLess1D.Location = new System.Drawing.Point(120, 73);
            this.gpbLess1D.Name = "gpbLess1D";
            this.gpbLess1D.Size = new System.Drawing.Size(250, 20);
            this.gpbLess1D.TabIndex = 27;
            this.gpbLess1D.Text = "guna2ProgressBar1";
            this.gpbLess1D.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            // 
            // gpbMaxD
            // 
            this.gpbMaxD.Location = new System.Drawing.Point(120, 44);
            this.gpbMaxD.Name = "gpbMaxD";
            this.gpbMaxD.Size = new System.Drawing.Size(250, 20);
            this.gpbMaxD.TabIndex = 26;
            this.gpbMaxD.Text = "guna2ProgressBar1";
            this.gpbMaxD.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            // 
            // lblFirstD
            // 
            this.lblFirstD.AutoSize = true;
            this.lblFirstD.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblFirstD.Font = new System.Drawing.Font("HoloLens MDL2 Assets", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFirstD.Location = new System.Drawing.Point(17, 48);
            this.lblFirstD.Name = "lblFirstD";
            this.lblFirstD.Size = new System.Drawing.Size(29, 12);
            this.lblFirstD.TabIndex = 20;
            this.lblFirstD.Text = "label1";
            // 
            // lblSecondD
            // 
            this.lblSecondD.AutoSize = true;
            this.lblSecondD.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblSecondD.Font = new System.Drawing.Font("HoloLens MDL2 Assets", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecondD.Location = new System.Drawing.Point(17, 77);
            this.lblSecondD.Name = "lblSecondD";
            this.lblSecondD.Size = new System.Drawing.Size(29, 12);
            this.lblSecondD.TabIndex = 21;
            this.lblSecondD.Text = "label2";
            // 
            // lblThirdD
            // 
            this.lblThirdD.AutoSize = true;
            this.lblThirdD.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblThirdD.Font = new System.Drawing.Font("HoloLens MDL2 Assets", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblThirdD.Location = new System.Drawing.Point(17, 106);
            this.lblThirdD.Name = "lblThirdD";
            this.lblThirdD.Size = new System.Drawing.Size(29, 12);
            this.lblThirdD.TabIndex = 24;
            this.lblThirdD.Text = "label5";
            // 
            // lblSixthD
            // 
            this.lblSixthD.AutoSize = true;
            this.lblSixthD.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblSixthD.Font = new System.Drawing.Font("HoloLens MDL2 Assets", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSixthD.Location = new System.Drawing.Point(17, 193);
            this.lblSixthD.Name = "lblSixthD";
            this.lblSixthD.Size = new System.Drawing.Size(29, 12);
            this.lblSixthD.TabIndex = 25;
            this.lblSixthD.Text = "label6";
            // 
            // lblFourthD
            // 
            this.lblFourthD.AutoSize = true;
            this.lblFourthD.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblFourthD.Font = new System.Drawing.Font("HoloLens MDL2 Assets", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFourthD.Location = new System.Drawing.Point(17, 135);
            this.lblFourthD.Name = "lblFourthD";
            this.lblFourthD.Size = new System.Drawing.Size(29, 12);
            this.lblFourthD.TabIndex = 23;
            this.lblFourthD.Text = "label4";
            // 
            // lblFifthD
            // 
            this.lblFifthD.AutoSize = true;
            this.lblFifthD.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblFifthD.Font = new System.Drawing.Font("HoloLens MDL2 Assets", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFifthD.Location = new System.Drawing.Point(17, 164);
            this.lblFifthD.Name = "lblFifthD";
            this.lblFifthD.Size = new System.Drawing.Size(29, 12);
            this.lblFifthD.TabIndex = 22;
            this.lblFifthD.Text = "label3";
            // 
            // frmDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.HighlightText;
            this.ClientSize = new System.Drawing.Size(1225, 609);
            this.Controls.Add(this.guna2ShadowPanel10);
            this.Controls.Add(this.guna2ShadowPanel11);
            this.Controls.Add(this.guna2ShadowPanel8);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.guna2ShadowPanel7);
            this.Controls.Add(this.guna2ShadowPanel6);
            this.Controls.Add(this.guna2ShadowPanel4);
            this.Controls.Add(this.guna2ShadowPanel5);
            this.Controls.Add(this.guna2ShadowPanel3);
            this.Controls.Add(this.guna2ShadowPanel2);
            this.Controls.Add(this.guna2ShadowPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmDashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmDashboard";
            this.Load += new System.EventHandler(this.frmDashboard_Load);
            this.guna2ShadowPanel1.ResumeLayout(false);
            this.guna2ShadowPanel1.PerformLayout();
            this.guna2ShadowPanel2.ResumeLayout(false);
            this.guna2ShadowPanel2.PerformLayout();
            this.guna2ShadowPanel3.ResumeLayout(false);
            this.guna2ShadowPanel3.PerformLayout();
            this.guna2ShadowPanel4.ResumeLayout(false);
            this.guna2ShadowPanel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbImageInSum)).EndInit();
            this.guna2ShadowPanel5.ResumeLayout(false);
            this.guna2ShadowPanel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbImageInAVG)).EndInit();
            this.guna2ShadowPanel6.ResumeLayout(false);
            this.guna2ShadowPanel6.PerformLayout();
            this.guna2ShadowPanel7.ResumeLayout(false);
            this.guna2ShadowPanel7.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.guna2ShadowPanel8.ResumeLayout(false);
            this.guna2ShadowPanel8.PerformLayout();
            this.guna2ShadowPanel11.ResumeLayout(false);
            this.guna2ShadowPanel11.PerformLayout();
            this.guna2ShadowPanel10.ResumeLayout(false);
            this.guna2ShadowPanel10.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private LiveCharts.WinForms.CartesianChart ccTransferDiagram;
        private LiveCharts.WinForms.CartesianChart ccWithdrawal_Deposit;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private Guna.UI2.WinForms.Guna2Button guna2Button2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel1;
        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel3;
        private System.Windows.Forms.Label label4;
        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel4;
        private System.Windows.Forms.Label label6;
        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblTotalCommission;
        private System.Windows.Forms.Label lblSumCommission;
        private System.Windows.Forms.Label lblAVGCommission;
        private System.Windows.Forms.PictureBox pbImageInSum;
        private System.Windows.Forms.PictureBox pbImageInAVG;
        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel6;
        private System.Windows.Forms.Label lblTotalWithdrawal;
        private System.Windows.Forms.Label label9;
        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel7;
        private System.Windows.Forms.Label lblTotalDeposit;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label8;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton1;
        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblFirst;
        private System.Windows.Forms.Label lblSecond;
        private System.Windows.Forms.Label lblThird;
        private System.Windows.Forms.Label lblSixth;
        private System.Windows.Forms.Label lblFourth;
        private System.Windows.Forms.Label lblFifth;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label18;
        private Guna.UI2.WinForms.Guna2ProgressBar gpbMinT;
        private Guna.UI2.WinForms.Guna2ProgressBar gpbLess4T;
        private Guna.UI2.WinForms.Guna2ProgressBar gpbLess3T;
        private Guna.UI2.WinForms.Guna2ProgressBar gpbLess2T;
        private Guna.UI2.WinForms.Guna2ProgressBar gpbLess1T;
        private Guna.UI2.WinForms.Guna2ProgressBar gpbMaxT;
        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel11;
        private Guna.UI2.WinForms.Guna2ProgressBar gpbMinW;
        private Guna.UI2.WinForms.Guna2ProgressBar gpbLess4W;
        private Guna.UI2.WinForms.Guna2ProgressBar gpbLess3W;
        private Guna.UI2.WinForms.Guna2ProgressBar gpbLess2W;
        private Guna.UI2.WinForms.Guna2ProgressBar gpbLess1W;
        private Guna.UI2.WinForms.Guna2ProgressBar gpbMaxW;
        private System.Windows.Forms.Label lblFirstW;
        private System.Windows.Forms.Label lblSecondW;
        private System.Windows.Forms.Label lblThirdW;
        private System.Windows.Forms.Label lblSixthW;
        private System.Windows.Forms.Label lblFourthW;
        private System.Windows.Forms.Label lblFifthW;
        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel10;
        private Guna.UI2.WinForms.Guna2ProgressBar gpbMinD;
        private Guna.UI2.WinForms.Guna2ProgressBar gpbLess4D;
        private Guna.UI2.WinForms.Guna2ProgressBar gpbLess3D;
        private Guna.UI2.WinForms.Guna2ProgressBar gpbLess2D;
        private Guna.UI2.WinForms.Guna2ProgressBar gpbLess1D;
        private Guna.UI2.WinForms.Guna2ProgressBar gpbMaxD;
        private System.Windows.Forms.Label lblFirstD;
        private System.Windows.Forms.Label lblSecondD;
        private System.Windows.Forms.Label lblThirdD;
        private System.Windows.Forms.Label lblSixthD;
        private System.Windows.Forms.Label lblFourthD;
        private System.Windows.Forms.Label lblFifthD;
    }
}