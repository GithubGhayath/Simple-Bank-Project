﻿using BankBusinessLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bank.Currency
{
    public partial class frmTransferLog : Form
    {
        private void _CustomInterface()
        {
            this.BackColor= System.Drawing.ColorTranslator.FromHtml("#243031");
            label2.ForeColor = System.Drawing.ColorTranslator.FromHtml("#cb764d");
            panel1.BackColor = System.Drawing.ColorTranslator.FromHtml("#43585A");
        }
        private void _FillComboBox()
        {
            foreach(DataGridViewColumn c in gdgvLogs.Columns)
            {
                if (Convert.ToString(c.Name) == "FromAccount" || Convert.ToString(c.Name) == "SenderName" ||
                    Convert.ToString(c.Name) == "ReceiverName" || Convert.ToString(c.Name) == "ToAccount")
                    cbFilterBy.Items.Add(Convert.ToString(c.Name));
            }
            cbFilterBy.SelectedIndex = 0;
            
        }
        private void _FillTable()
        {
            gdgvLogs.DataSource = clsTransactionsBusinessLayer.GetAllTransfers();
            lblCountRows.Text = (gdgvLogs.Rows.Count - 1).ToString();
            _FillComboBox();
        }
        public frmTransferLog()
        {
            InitializeComponent();
        }

        private void frmTransferLog_Load(object sender, EventArgs e)
        {
            _CustomInterface();
            _FillTable();
        }

        private void guna2CircleButton1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cbFilterBy_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbFilterBy.SelectedItem.ToString() == "None")
                txtFilterBy.Visible = false;
            else
            {
                txtFilterBy.Visible = true;
                txtFilterBy.Focus();
            }
        }

        private void _FilterData(string ColumnName)
        {




            BindingSource ForFilter = new BindingSource();
            ForFilter.DataSource = gdgvLogs.DataSource; // Assuming gdgvLogs.DataSource is already set to a data source like DataTable

            if (ColumnName == "FromAccount" || ColumnName == "SenderName" || ColumnName == "ToAccount" || ColumnName == "ReceiverName")
            {
                ForFilter.Filter = $"{ColumnName} LIKE '{txtFilterBy.Text}%'";
            }
            else if (ColumnName == "Amount" || ColumnName == "Balance_1_AfterTransfer" || ColumnName == "Balance_2_AfterTransfer")
            {
                if (string.IsNullOrEmpty(txtFilterBy.Text)) { return; }
                ForFilter.Filter = $"{ColumnName} = {Convert.ToDecimal(txtFilterBy.Text)}";
            }

            gdgvLogs.DataSource = ForFilter; // Set the DataGridView's DataSource to the BindingSource
            lblCountRows.Text = (gdgvLogs.Rows.Count - 1).ToString();
        }
        private void txtFilterBy_TextChanged(object sender, EventArgs e)
        {
          switch(cbFilterBy.SelectedItem.ToString())
            {
                case "FromAccount":
                    _FilterData("FromAccount");
                    break;
                case "SenderName":
                    _FilterData("SenderName");
                    break;
                case "ToAccount":
                    _FilterData("ToAccount");
                    break;
                case "ReceiverName":
                    _FilterData("ReceiverName");
                    break;
                case "Amount":
                    _FilterData("Amount");
                    break;
                case "Balance_1_AfterTransfer":
                    _FilterData("Balance_1_AfterTransfer");
                    break;
                case "Balance_2_AfterTransfer":
                    _FilterData("Balance_2_AfterTransfer");
                    break;
            }
                
        }
    }
}
