﻿using Bank.Generals;
using BankBusinessLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bank.Currency
{
    public partial class frmWithdraw_DepositScreen : Form
    {
        private int Mode;
        public frmWithdraw_DepositScreen(int mode)
        {
            InitializeComponent();
            this.Mode = mode;
            ctrlWithdraw_Deposit1.eMode = this.Mode;
        }

        private void frmWithdraw_DepositScreen_Load(object sender, EventArgs e)
        {
            if (!DesignMode)
            {
                ctrlWithdraw_Deposit1.ClosePerentForm(this);
            }
        }
    }
}
