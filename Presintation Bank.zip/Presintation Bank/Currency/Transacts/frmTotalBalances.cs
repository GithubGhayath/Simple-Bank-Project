﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BankBusinessLayer;
using Humanizer;

namespace Bank.Currency
{
    public partial class frmTotalBalances : Form
    {

        private void _FillTable()
        {
            gdgvTotalBalances.DataSource = clsClientsBusinessLayer.ShowTotalBalance();
            lblCountRows.Text = gdgvTotalBalances.Rows.Count.ToString();
        }
        private void _CustomInterface()
        {
            this.BackColor = System.Drawing.ColorTranslator.FromHtml("#243031");
            label2.ForeColor = System.Drawing.ColorTranslator.FromHtml("#cb764d");
            panel1.BackColor = System.Drawing.ColorTranslator.FromHtml("#43585A");
        }
        public frmTotalBalances()
        {
            InitializeComponent();
        }

        private void guna2CircleButton1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmTotalBalances_Load(object sender, EventArgs e)
        {
            _CustomInterface();
            _FillTable();
            lblTotalBalance.Text = clsClientsBusinessLayer.GetTotlaBalances().ToString();
            lblNumberAsText.Text = Humanizer.NumberToWordsExtension.ToWords((int)clsClientsBusinessLayer.GetTotlaBalances());
        }

        
    }
}
