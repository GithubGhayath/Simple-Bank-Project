﻿using Bank.Currency;
using Bank.Generals;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bank.Users
{
    public partial class frmTransactions : Form
    {
        public frmTransactions()
        {
            InitializeComponent();
        }

        private void _CustomInterface()
        {
            string FullName = clsGloablClient.CurrentClient.PersonInfo.firstName + " " +
                clsGloablClient.CurrentClient.PersonInfo.midName + " " +
                clsGloablClient.CurrentClient.PersonInfo.lastName;
            panel1.BackColor = System.Drawing.ColorTranslator.FromHtml("#243031");
            panel13.BackColor = System.Drawing.ColorTranslator.FromHtml("#243031");
            panel2.BackColor = System.Drawing.ColorTranslator.FromHtml("#e7edf2");
            panel8.BackColor = System.Drawing.ColorTranslator.FromHtml("#cb764d");
            panel9.BackColor = System.Drawing.ColorTranslator.FromHtml("#cb764d");
            panel10.BackColor = System.Drawing.ColorTranslator.FromHtml("#cb764d");
            panel11.BackColor = System.Drawing.ColorTranslator.FromHtml("#cb764d");
            panel12.BackColor = System.Drawing.ColorTranslator.FromHtml("#cb764d");
            lblClientName.Text = FullName;
            label2.ForeColor = System.Drawing.ColorTranslator.FromHtml("#cb764d");
            panel15.BackColor = System.Drawing.ColorTranslator.FromHtml("#cb764d");
        }
        private void pbClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            // Create a Pen with the desired color and width
            Pen pen = new Pen(Color.White, 1);

            // Define the start and end points for the line
            Point startPoint = new Point(20, 190);
            Point endPoint = new Point(170, 190);

            // Draw the line
            e.Graphics.DrawLine(pen, startPoint, endPoint);

            Pen pen2 = new Pen(Color.White, .5f);
            // Define the start and end points for the line
            Point startPoint2 = new Point(20, 340);
            Point endPoint2 = new Point(170, 340);

            // Draw the line
            e.Graphics.DrawLine(pen2, startPoint2, endPoint2);
        }

        private void pictureBox1_MouseHover(object sender, EventArgs e)
        {
            pbClose.BackColor = System.Drawing.ColorTranslator.FromHtml("#d3e1ed");

        }
        private void pictureBox1_MouseLeave(object sender, EventArgs e)
        {
            pbClose.BackColor = System.Drawing.ColorTranslator.FromHtml("#e7edf2");
        }
        private void frmTransactions_Load(object sender, EventArgs e)
        {
            _CustomInterface();
        }
        private void _ConvertPanelColorWhenHover(Panel panel)
        {
            panel.BackColor = System.Drawing.ColorTranslator.FromHtml("#0a0d0d");

        }
        private void _ConvertPanelColorWhenLeave(Panel panel)
        {
            panel.BackColor = System.Drawing.ColorTranslator.FromHtml("#243031");
        }

        private void panel3_MouseHover(object sender, EventArgs e)
        {
            _ConvertPanelColorWhenHover((Panel)sender);
        }

        private void panel3_MouseLeave(object sender, EventArgs e)
        {
            _ConvertPanelColorWhenLeave((Panel)sender);

        }

        private void frmTransactions_Paint(object sender, PaintEventArgs e)
        {

            // Inside your Paint event handler (e.g., Form1_Paint)

            // Create a pen (color, width, style)
            Pen BluePen = new Pen(System.Drawing.ColorTranslator.FromHtml("#cb764d"), 2);

            // Define the coordinates of the endpoints
            int x1 = 370;
            int y1 = 200;
            int x2 = 720;
            int y2 = 200;

            // Draw the line
            e.Graphics.DrawLine(BluePen, x1, y1, x2, y2);

            Pen BluePen1 = new Pen(System.Drawing.ColorTranslator.FromHtml("#cb764d"), 3);
            int xx1 = 370;
            int yy1 = 205;
            int xx2 = 720;
            int yy2 = 205;

            e.Graphics.DrawLine(BluePen1, xx1, yy1, xx2, yy2);
        }

        //Withdraw
        private void panel3_Click(object sender, EventArgs e)
        {
            frmWithdraw_DepositScreen frmWithdrawScreen = new frmWithdraw_DepositScreen(2);
            frmWithdrawScreen.ShowDialog();
        }
        private void label3_Click(object sender, EventArgs e)
        {
            panel3_Click(null, null);
        }

        //Deposit
        private void panel4_Click(object sender, EventArgs e)
        {
            frmWithdraw_DepositScreen Deposit = new frmWithdraw_DepositScreen(1);
            Deposit.ShowDialog();
        }
        private void label4_Click(object sender, EventArgs e)
        {
            panel4_Click(null, null);
        }

        //Transfer
        private void panel5_Click(object sender, EventArgs e)
        {
            Form frmTransferScreen = new frmTransfer();
            frmTransferScreen.ShowDialog();
        }
        private void label5_Click(object sender, EventArgs e)
        {
            panel5_Click(null, null);
        }
       
        //Transfer Log
        private void panel6_Click(object sender, EventArgs e)
        {
            Form frmTransferLog = new frmTransferLog();
            frmTransferLog.ShowDialog();
        }
        private void label6_Click(object sender, EventArgs e)
        {
            panel6_Click(null, null);
        }

        //Total Balances
        private void panel7_Click(object sender, EventArgs e)
        {
            Form frmTotalBalances = new frmTotalBalances();
            frmTotalBalances.ShowDialog();
        }
        private void label7_Click(object sender, EventArgs e)
        {
            panel7_Click(null, null);
        }
       
        
        //Dashboard
        private void panel14_Click(object sender, EventArgs e)
        {
            frmDashboard Dashbord=new frmDashboard();
            Dashbord.ShowDialog();
        }
        private void label10_Click(object sender, EventArgs e)
        {
            panel14_Click(null, null);
        }
    }
}
