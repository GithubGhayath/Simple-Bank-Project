﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BankBusinessLayer;
using LiveCharts.Definitions.Charts;
using LiveCharts;
using LiveCharts.WinForms;
using LiveCharts.Wpf;
using LiveCharts.Defaults;
using System.Linq;

namespace Bank.Currency
{
    public partial class frmDashboard : Form
    {
        DataTable TransferInfoLast10Days = new DataTable();
        DataTable WithdrawalInfoLast10Days = new DataTable();
        DataTable DepositInfoLast10Days = new DataTable();

        private void _CustomInterface()
        {
            panel1.BackColor = System.Drawing.ColorTranslator.FromHtml("#243031");
        }
        private void _FillDataTables()
        {
            TransferInfoLast10Days = clsTransactionsBusinessLayer.GetNumberOfTransferLasstTenDays();
            WithdrawalInfoLast10Days = clsTransactionsBusinessLayer.GetNumberOfWithdrawalLasstTenDays();
            DepositInfoLast10Days = clsTransactionsBusinessLayer.GetNumberOfDepositLasstTenDays();
            
        }
        private void _CustomTransferChart()
        {
            _FillDataTables();
            // Assuming you have a CartesianChart control named 'cartesianChart'
            // and a DataTable with columns "DateColumn" for DateTime and "ValueColumn" for int

            // Create a new series collection
            var seriesCollection = new SeriesCollection();

            // Create a new line series
            var lineSeries = new LineSeries
            {
                Values = new ChartValues<DateTimePoint>()
            };

            // Iterate over the rows of the DataTable and add values to the line series
            foreach (DataRow row in TransferInfoLast10Days.Rows)
            {
                DateTime xValue = Convert.ToDateTime(row["Date"]); // Replace with your column name for DateTime values
                int yValue = Convert.ToInt32(row["NumberOfTransferProcess"]); // Replace with your column name for int values
                lineSeries.Values.Add(new DateTimePoint(xValue, yValue));
            }

            // Add the line series to the series collection
            seriesCollection.Add(lineSeries);

            // Assign the series collection to the chart
            ccTransferDiagram.Series = seriesCollection;

            // Configure X axis for DateTime values
            ccTransferDiagram.AxisX.Add(new Axis
            {
                LabelFormatter = value => new DateTime((long)value).ToString("MM/dd/yyyy") // Format DateTime labels as you prefer
            });

            // Configure Y axis for int values
            ccTransferDiagram.AxisY.Add(new Axis
            {
                LabelFormatter = value => value.ToString("N0") // Format int labels as numbers without decimals
            });
            _FillTransfersPanelWithData();
           

        }
        private void _CustomWithdrawal_DepositChart()
        {
            // Assuming you have a CartesianChart control named 'cartesianChart'
            // and two DataTables named 'dataTable1' and 'dataTable2'

            // Create a new series collection
            var seriesCollection = new SeriesCollection();

            // Create the first line series for dataTable1
            var lineSeries1 = new LineSeries
            {
                Title = "Dataset 1",
                Values = new ChartValues<DateTimePoint>(),
                Stroke = System.Windows.Media.Brushes.Blue
            };

            // Add values to the first line series
            foreach (DataRow row in WithdrawalInfoLast10Days.Rows)
            {
                DateTime xValue = Convert.ToDateTime(row["Date"]);
                int yValue = Convert.ToInt32(row["NumberOfWithdraw"]);
                lineSeries1.Values.Add(new DateTimePoint(xValue, yValue));
            }

            // Create the second line series for dataTable2
            var lineSeries2 = new LineSeries
            {
                Title = "Dataset 2",
                Values = new ChartValues<DateTimePoint>(),
                Stroke = System.Windows.Media.Brushes.Red
            };

            // Add values to the second line series
            foreach (DataRow row in DepositInfoLast10Days.Rows)
            {
                DateTime xValue = Convert.ToDateTime(row["Date"]);
                int yValue = Convert.ToInt32(row["NumberOfDeposit"]);
                lineSeries2.Values.Add(new DateTimePoint(xValue, yValue));
            }

            // Add both line series to the series collection
            seriesCollection.Add(lineSeries1);
            seriesCollection.Add(lineSeries2);

            // Assign the series collection to the chart
            ccWithdrawal_Deposit.Series = seriesCollection;

            // Configure X axis for DateTime values
            ccWithdrawal_Deposit.AxisX.Add(new Axis
            {
                LabelFormatter = value => new DateTime((long)value).ToString("MM/dd/yyyy") // Format DateTime labels as you prefer
            });

            // Configure Y axis for int values
            ccWithdrawal_Deposit.AxisY.Add(new Axis
            {
                LabelFormatter = value => value.ToString("N0") // Format int labels as numbers without decimals
            });
            _FillWithdraw_DepositPanelWithData();
        }
        private void _FillTransfersPanelWithData()
        {
            lblTotalCommission.Text = clsTransactionsBusinessLayer.CalculateCommissionOfTransfers().ToString() + " $";
            lblAVGCommission.Text = clsTransactionsBusinessLayer.CalculateAVGOfCommissionLast_10_Days().ToString() + " $";
            lblSumCommission.Text = clsTransactionsBusinessLayer.CalculateSUMOfCommissionLast_10_Days().ToString() + " $";
            _UperLineOrLower();
        }
        private void _FillWithdraw_DepositPanelWithData()
        {
            lblTotalWithdrawal.Text = clsTransactionsBusinessLayer.CalculateWithdrawLast_10_Days().ToString() + " *transact";
            lblTotalDeposit.Text = clsTransactionsBusinessLayer.CalculateDepositLast_10_Days().ToString() + " *transact";
        }
        private void _FillTransferProgressBar()
        {
            DataTable ClientInfo = clsTransactionsBusinessLayer.GetTheTop6ClientDoTransfers();
            
            if (ClientInfo.Rows.Count>0)
            {
                gpbMaxT.Value = Convert.ToInt32(ClientInfo.Rows[0].Field<int>("NumberOfTransfers"));
                lblFirst.Text = Convert.ToString(ClientInfo.Rows[0].Field<string>("FullName"));
            }
            else
                lblFirst.Text = "No Client";
            if (ClientInfo.Rows.Count > 1)
            {
                gpbLess1T.Value = Convert.ToInt32(ClientInfo.Rows[1].Field<int>("NumberOfTransfers"));
                lblSecond.Text = Convert.ToString(ClientInfo.Rows[1].Field<string>("FullName"));
            }
            else
                lblSecond.Text = "No Client";
            if (ClientInfo.Rows.Count > 2)
            {
                gpbLess2T.Value = Convert.ToInt32(ClientInfo.Rows[2].Field<int>("NumberOfTransfers"));
                lblThird.Text = Convert.ToString(ClientInfo.Rows[2].Field<string>("FullName"));
            }
            else
                lblThird.Text = "No Client";
            if (ClientInfo.Rows.Count > 3)
            {
                gpbLess3T.Value = Convert.ToInt32(ClientInfo.Rows[3].Field<int>("NumberOfTransfers"));
                lblFourth.Text = Convert.ToString(ClientInfo.Rows[3].Field<string>("FullName"));
            }
            else
                lblFourth.Text = "No Client";
            if (ClientInfo.Rows.Count > 4)
            {
                gpbLess4T.Value = Convert.ToInt32(ClientInfo.Rows[4].Field<int>("NumberOfTransfers"));
                lblFifth.Text = Convert.ToString(ClientInfo.Rows[4].Field<string>("FullName"));
            }
            else
                lblFifth.Text = "No Client";
            if (ClientInfo.Rows.Count > 5)
            {
                gpbMinT.Value = Convert.ToInt32(ClientInfo.Rows[5].Field<int>("NumberOfTransfers"));
                lblSixth.Text = Convert.ToString(ClientInfo.Rows[5].Field<string>("FullName"));
            }
            else
                lblSixth.Text = "No Client";
        }
        private void _FillWithrawalProgressBar()
        {
            DataTable ClientInfo = clsTransactionsBusinessLayer.GetTheTopClientDoWithdrawal();

            if (ClientInfo.Rows.Count > 0)
            {
                gpbMaxW.Value = Convert.ToInt32(ClientInfo.Rows[0].Field<int>("NUMBEROFWITHDRAWAL"));
                lblFirstW.Text = Convert.ToString(ClientInfo.Rows[0].Field<string>("CLIENTNAME"));
            }
            else
                lblFirstW.Text = "No Client";
            if (ClientInfo.Rows.Count > 1)
            {
                gpbLess1W.Value = Convert.ToInt32(ClientInfo.Rows[1].Field<int>("NUMBEROFWITHDRAWAL"));
                lblSecondW.Text = Convert.ToString(ClientInfo.Rows[1].Field<string>("CLIENTNAME"));
            }
            else
                lblSecondW.Text = "No Client";
            if (ClientInfo.Rows.Count > 2)
            {
                gpbLess2W.Value = Convert.ToInt32(ClientInfo.Rows[2].Field<int>("NUMBEROFWITHDRAWAL"));
                lblThirdW.Text = Convert.ToString(ClientInfo.Rows[2].Field<string>("CLIENTNAME"));
            }
            else
                lblThirdW.Text = "No Client";
            if (ClientInfo.Rows.Count > 3)
            {
                gpbLess3W.Value = Convert.ToInt32(ClientInfo.Rows[3].Field<int>("NUMBEROFWITHDRAWAL"));
                lblFourthW.Text = Convert.ToString(ClientInfo.Rows[3].Field<string>("CLIENTNAME"));
            }
            else
                lblFourthW.Text = "No Client";
            if (ClientInfo.Rows.Count > 4)
            {
                gpbLess4W.Value = Convert.ToInt32(ClientInfo.Rows[4].Field<int>("NUMBEROFWITHDRAWAL"));
                lblFifthW.Text = Convert.ToString(ClientInfo.Rows[4].Field<string>("CLIENTNAME"));
            }
            else
                lblFifthW.Text = "No Client";
            if (ClientInfo.Rows.Count > 5)
            {
                gpbMinW.Value = Convert.ToInt32(ClientInfo.Rows[5].Field<int>("NUMBEROFWITHDRAWAL"));
                lblSixthW.Text = Convert.ToString(ClientInfo.Rows[5].Field<string>("CLIENTNAME"));
            }
            else
                lblSixthW.Text = "No Client";
        }
        private void _FillDepositProgressBar()
        {
            DataTable ClientInfo = clsTransactionsBusinessLayer.GetTheTopClientDoDeposit();

            if (ClientInfo.Rows.Count > 0)
            {
                gpbMaxD.Value = Convert.ToInt32(ClientInfo.Rows[0].Field<int>("NUMBEROFDEPOSIT"));
                lblFirstD.Text = Convert.ToString(ClientInfo.Rows[0].Field<string>("CLIENTNAME"));
            }
            else
                lblFirstD.Text = "No Client";
            if (ClientInfo.Rows.Count > 1)
            {
                gpbLess1D.Value = Convert.ToInt32(ClientInfo.Rows[1].Field<int>("NUMBEROFDEPOSIT"));
                lblSecondD.Text = Convert.ToString(ClientInfo.Rows[1].Field<string>("CLIENTNAME"));
            }
            else
                lblSecondD.Text = "No Client";
            if (ClientInfo.Rows.Count > 2)
            {
                gpbLess2D.Value = Convert.ToInt32(ClientInfo.Rows[2].Field<int>("NUMBEROFDEPOSIT"));
                lblThirdD.Text = Convert.ToString(ClientInfo.Rows[2].Field<string>("CLIENTNAME"));
            }
            else
                lblThirdD.Text = "No Client";
            if (ClientInfo.Rows.Count > 3)
            {
                gpbLess3D.Value = Convert.ToInt32(ClientInfo.Rows[3].Field<int>("NUMBEROFDEPOSIT"));
                lblFourthD.Text = Convert.ToString(ClientInfo.Rows[3].Field<string>("CLIENTNAME"));
            }
            else
                lblFourthD.Text = "No Client";
            if (ClientInfo.Rows.Count > 4)
            {
                gpbLess4D.Value = Convert.ToInt32(ClientInfo.Rows[4].Field<int>("NUMBEROFDEPOSIT"));
                lblFifthD.Text = Convert.ToString(ClientInfo.Rows[4].Field<string>("CLIENTNAME"));
            }
            else
                lblFifthD.Text = "No Client";
            if (ClientInfo.Rows.Count > 5)
            {
                gpbMinD.Value = Convert.ToInt32(ClientInfo.Rows[5].Field<int>("NUMBEROFDEPOSIT"));
                lblSixthD.Text = Convert.ToString(ClientInfo.Rows[5].Field<string>("CLIENTNAME"));
            }
            else
                lblSixthD.Text = "No Client";
        }
        public frmDashboard()
        {
            InitializeComponent();
        }
        private void _UperLineOrLower()
        {

            (int, int) Result = clsTransactionsBusinessLayer.GetTheLastTwoValueFromCommissionTransfer10Days();

            if(Result.Item1> Result.Item2)
            {
                pbImageInAVG.Image = Properties.Resources.up_arrow;
                pbImageInSum.Image = Properties.Resources.up_arrow;
            }
            else if (Result.Item1 < Result.Item2)
            {
                pbImageInAVG.Image = Properties.Resources.down_arrow;
                pbImageInSum.Image = Properties.Resources.down_arrow;
            }
            else
            {
                pbImageInAVG.Image = Properties.Resources.Line;
                pbImageInSum.Image = Properties.Resources.Line;
            }
           
        }
        private void frmDashboard_Load(object sender, EventArgs e)
        {
            _CustomInterface();
            _CustomTransferChart();
            _CustomWithdrawal_DepositChart();
            _FillTransferProgressBar();
            _FillWithrawalProgressBar();
            _FillDepositProgressBar();
            //Blue : Withdraw
            //Red : Deposit
        }

        private void guna2CircleButton1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
