﻿using Bank.Clients;
using Bank.Currency;
using Bank.Generals;
using Bank.Users;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bank
{

    //#FD9B63
    //#E7D37F
    //#81A263
    public partial class MainScreen : Form
    {
        public MainScreen()
        {
            InitializeComponent();
        }

        private void ConvertPanelStyleWhenHover(Panel pene)
        {
            pene.BackColor = System.Drawing.ColorTranslator.FromHtml("#355832");
        }
        private void ConvertPanelStyleWhenMouceOut(Panel pene)
        {
            pene.BackColor = Color.Transparent;
        }

        private void CustomScreenModel()
        {
            panel1.BackColor = System.Drawing.ColorTranslator.FromHtml("#365e32");
            panel2.BackColor = System.Drawing.ColorTranslator.FromHtml("#365e32");
            lblCurrentUserName.ForeColor= System.Drawing.ColorTranslator.FromHtml("#ffffff");
            label1.ForeColor = System.Drawing.ColorTranslator.FromHtml("#365e32 ");
            label2.ForeColor = System.Drawing.ColorTranslator.FromHtml("#81A263");
            label3.ForeColor = System.Drawing.ColorTranslator.FromHtml("#ffffff");
            label4.ForeColor = System.Drawing.ColorTranslator.FromHtml("#ffffff");
            label5.ForeColor = System.Drawing.ColorTranslator.FromHtml("#ffffff");
            label6.ForeColor = System.Drawing.ColorTranslator.FromHtml("#ffffff");
            label7.ForeColor = System.Drawing.ColorTranslator.FromHtml("#ffffff");
            label8.ForeColor = System.Drawing.ColorTranslator.FromHtml("#ffffff");
            label10.ForeColor = System.Drawing.ColorTranslator.FromHtml("#ffffff");
            label11.ForeColor = System.Drawing.ColorTranslator.FromHtml("#ffffff");
            label12.ForeColor = System.Drawing.ColorTranslator.FromHtml("#ffffff");
            lblCurrentUserName.Text = clsGloablUser.CurrentUser.UserName;


        }
        private void MainScreen_Load(object sender, EventArgs e)
        {
            //UI
            CustomScreenModel();
        }
        private void MainScreen_Paint(object sender, PaintEventArgs e)
        {
            //#FD9B63
            //#E7D37F
            //#81A263


            // Inside your Paint event handler (e.g., Form1_Paint)

            // Create a pen (color, width, style)
            Pen BluePen = new Pen(System.Drawing.ColorTranslator.FromHtml("#81A263"), 2);

            // Define the coordinates of the endpoints
            int x1 = 450;
            int y1 = 200;
            int x2 = 750;
            int y2 = 200;

            // Draw the line
            e.Graphics.DrawLine(BluePen, x1, y1, x2, y2);

            Pen BluePen1 = new Pen(System.Drawing.ColorTranslator.FromHtml("#81A263"), 3);
            int xx1 = 450;
            int yy1 = 205;
            int xx2 = 750;
            int yy2 = 205;

            e.Graphics.DrawLine(BluePen1, xx1, yy1, xx2, yy2);
        }

        private void ConvertPanelStyle(object sender, EventArgs e)
        {
            ConvertPanelStyleWhenHover((Panel)sender);
        }

        private void ConvertPanelStyleWhenMouceOut(object sender, EventArgs e)
        {
            ConvertPanelStyleWhenMouceOut((Panel)sender);
        }

        
        
        






       
        //For Add New Client
        private void label3_Click(object sender, EventArgs e)
        {
            panel7_MouseDown(null, null);
        }
        private void pictureBox7_Click(object sender, EventArgs e)
        {
            panel7_MouseDown(null, null);
        }
        private void panel7_MouseDown(object sender, MouseEventArgs e)
        {
            if (clsUtility.CheckPermissions(2))
            {
                frmDenite DeScreen = new frmDenite();
                DeScreen.ShowDialog();
                return;
            }
            Form frmAddNewClient = new frmAddUpdateClient();
            frmAddNewClient.ShowDialog();
        }

        //For Update Client
        private void label5_Click(object sender, EventArgs e)
        {
            panel3_MouseDown(null, null);
        }
        private void pictureBox5_Click(object sender, EventArgs e)
        {
            panel3_MouseDown(null, null);
        }
        private void panel3_MouseDown(object sender, MouseEventArgs e)
        {
            if (clsUtility.CheckPermissions(4))
            {
                frmDenite DeScreen = new frmDenite();
                DeScreen.ShowDialog();
                return;
            }
            Form frmUpdateClient = new frmUpdateClientInfo();
            frmUpdateClient.ShowDialog();
        }



        //For Delete Client
        private void panel6_MouseDown(object sender, MouseEventArgs e)
        {
            if (clsUtility.CheckPermissions(8))
            {
                frmDenite DeScreen = new frmDenite();
                DeScreen.ShowDialog();
                return;
            }
            Form frmDeleteClient = new frmDeleteClient();
            frmDeleteClient.ShowDialog();
        }
        private void label4_Click(object sender, EventArgs e)
        {
            panel6_MouseDown(null, null);
        }
        private void pictureBox6_Click(object sender, EventArgs e)
        {
            panel6_MouseDown(null, null);
        }


        //For Find Client
        private void panel4_MouseDown(object sender, MouseEventArgs e)
        {
            if (clsUtility.CheckPermissions(16))
            {
                frmDenite DeScreen = new frmDenite();
                DeScreen.ShowDialog();
                return;
            }
            Form frmFindClient = new frmFindClientInReadMode();
            frmFindClient.ShowDialog();
        }
        private void label6_Click(object sender, EventArgs e)
        {
            panel4_MouseDown(null, null);
        }
        private void pictureBox4_Click(object sender, EventArgs e)
        {
            panel4_MouseDown(null, null);
        }


        //For Logout
        private void panel9_MouseDown(object sender, MouseEventArgs e)
        {
            this.Close();
          
        }
        private void label11_Click(object sender, EventArgs e)
        {
            panel9_MouseDown(null, null);
        }
        private void pictureBox8_Click(object sender, EventArgs e)
        {

            panel9_MouseDown(null, null);
        }
        
        
        //For Show Client List
        private void panel8_MouseDown(object sender, MouseEventArgs e)
        {
            if(clsUtility.CheckPermissions(1))
            {
                frmDenite DeScreen = new frmDenite();
                DeScreen.ShowDialog();
                return;
            }
            Form frmShowClientList = new frmShowClientList();
            frmShowClientList.ShowDialog();
        }
        private void label7_Click(object sender, EventArgs e)
        {
            panel8_MouseDown(null, null);
        }
        private void pictureBox2_Click(object sender, EventArgs e)
        {
            panel8_MouseDown(null, null);
        }

        //Manage Users
        private void panel10_MouseDown(object sender, MouseEventArgs e)
        {
            if (clsUtility.CheckPermissions(32))
            {
                frmDenite DeScreen = new frmDenite();
                DeScreen.ShowDialog();
                return;
            }
            frmUserMainScreen frmShowMainUsersScreen = new frmUserMainScreen();
            frmShowMainUsersScreen.ShowDialog();
        }
        private void label10_Click(object sender, EventArgs e)
        {
            panel10_MouseDown(null, null);
        }
        private void pictureBox9_Click(object sender, EventArgs e)
        {
            panel10_MouseDown(null, null);
        }
       
        
        //Transactions
        private void panel5_MouseDown(object sender, MouseEventArgs e)
        {
            if (clsUtility.CheckPermissions(64))
            {
                frmDenite DeScreen = new frmDenite();
                DeScreen.ShowDialog();
                return;
            }
            Form frmShowLoginClientScreen = new frmLoginClientScreen();
            frmShowLoginClientScreen.ShowDialog();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            panel5_MouseDown(null, null);
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

            panel5_MouseDown(null, null);
        }


        //Currency Exchange
        private void panel11_Click(object sender, EventArgs e)
        {
            frmCurrencyMainMenueScreen CurrencyExchange = new frmCurrencyMainMenueScreen();
            CurrencyExchange.ShowDialog();
        }
        private void label9_Click(object sender, EventArgs e)
        {
            panel11_Click(null, null);
        }
        private void pictureBox10_Click(object sender, EventArgs e)
        {
            panel11_Click(null, null);
        }
    }
}
