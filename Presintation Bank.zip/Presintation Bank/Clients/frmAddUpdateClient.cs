﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bank.Clients
{
    public partial class frmAddUpdateClient : Form
    {
        int ClientID = -1;
        public frmAddUpdateClient()
        {
            InitializeComponent();
        }

        public frmAddUpdateClient(int clientID)
        {
            InitializeComponent();
            ctrlAddNew_UpdateClient1.ClientID = clientID;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
