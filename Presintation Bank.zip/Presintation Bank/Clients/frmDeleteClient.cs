﻿using BankBusinessLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bank.Clients
{
    public partial class frmDeleteClient : Form
    {
        public frmDeleteClient()
        {
            InitializeComponent();
        }

        private void ctrlSelectClient1_OnClientSelected(object sender, int e)
        {
            ctrlSelectClient1.MakeInfoControlDisable();
            if (MessageBox.Show("Are you sure you want to delete client with ID : " + e.ToString(), "Confirm", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning)==DialogResult.Yes)
            {
                if (clsClientsBusinessLayer.DeleteClient(e))
                    MessageBox.Show("Client Deleted Successfuly", "Done", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    MessageBox.Show("An Error occur", "Fail", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmDeleteClient_Load(object sender, EventArgs e)
        {
            ctrlSelectClient1.Title = "Delete Client";
            ctrlSelectClient1.TitleColor = Color.White;
        }
    }
}
