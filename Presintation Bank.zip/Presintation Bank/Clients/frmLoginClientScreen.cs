﻿using Bank.Generals;
using Bank.Users;
using BankBusinessLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bank.Clients
{
    public partial class frmLoginClientScreen : Form
    {
        public frmLoginClientScreen()
        {
            InitializeComponent();
        }

        private void _CustomInterface()
        {
            //gbtnLogin.FillColor = System.Drawing.ColorTranslator.FromHtml("#e2eaf5");
            this.BackColor = System.Drawing.ColorTranslator.FromHtml("#e2eaf5");
            label2.ForeColor = System.Drawing.ColorTranslator.FromHtml("#fcb920");
            label3.ForeColor = System.Drawing.ColorTranslator.FromHtml("#7597fb");
            label4.ForeColor = System.Drawing.ColorTranslator.FromHtml("#7597fb");
        }
        private void pictureBox1_MouseHover(object sender, EventArgs e)
        {
            pbClose.BackColor = System.Drawing.ColorTranslator.FromHtml("#d3e1ed");
        }
        private void pictureBox1_MouseLeave(object sender, EventArgs e)
        {
            pbClose.BackColor = System.Drawing.ColorTranslator.FromHtml("#e7edf2");
        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void frmLoginClientScreen_Load(object sender, EventArgs e)
        {
            _CustomInterface();
        }

        private void pbClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void gbtnLogin_Click(object sender, EventArgs e)
        {
            clsClientsBusinessLayer CurClient = clsClientsBusinessLayer.Find(txtAccountNumber.Text, clsUtility.ComputeHash(txtPinCode.Text).Substring(0, 4));
            if(CurClient == null)
            {
                MessageBox.Show("Verify the information entered", "ُError", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                clsUtility.LogMessageInEventLogSystem($"Client With account number: {txtAccountNumber.Text} login at: {DateTime.Now}", System.Diagnostics.EventLogEntryType.Information);
                clsGloablClient.CurrentClient = CurClient;
                frmTransactions frmTransactions = new frmTransactions();
                frmTransactions.ShowDialog();
                this.Close();
            }


        }
    }
}
