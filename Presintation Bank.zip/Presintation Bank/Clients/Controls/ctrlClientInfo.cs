﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace Bank.Clients.Controls
{
    //#FD9B63
    //#E7D37F
    //#81A263
    public partial class ctrlClientInfo : UserControl
    {
        private int _PersonID = 0;
        private int _ClientID = 0;
        private string _ClientName = string.Empty;
        private string _PhoneNumber = string.Empty;
        private string _AccountBalance = string.Empty;
        private string _AccountNumber = string.Empty;

        private void _LoadDataToScreen()
        {
            lblAccountBalance.Text = _AccountBalance;
            lblClientID.Text = _ClientID.ToString();
            lblPhoneNumber.Text = _PhoneNumber.ToString();
            lblAccountNumber.Text = _AccountNumber.ToString();
            lblPersonID.Text = _PersonID.ToString();
            lblClientName.Text = _ClientName.ToString();
        }
        private void _CustomInterface()
        {
            this.BackColor = System.Drawing.ColorTranslator.FromHtml("#81A263");
            _LoadDataToScreen();
        }
        public ctrlClientInfo()
        {
            InitializeComponent();
        }
        public ctrlClientInfo(int personID, int clientid, string clientname, string phonenumber, string accountbalance, string accountnumber)
        {
            InitializeComponent();

            this._ClientID = clientid;
            this._PersonID = personID;
            this._PhoneNumber= phonenumber;
            this._AccountBalance = accountbalance;
            this._AccountNumber = accountnumber;
            this._ClientName = clientname;
        }

        private void ctrlClientInfo_Load(object sender, EventArgs e)
        {
            _CustomInterface();
        }

     
    }
}
