﻿namespace Bank.Clients.Controls
{
    partial class ctrlSelectClient
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.ctrlAddNew_UpdateClient1 = new Bank.Clients.ctrlAddNew_UpdateClient();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Gadugi", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(25, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Enter Client ID:";
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(119, 9);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(174, 20);
            this.txtSearch.TabIndex = 2;
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
            this.txtSearch.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSearch_KeyPress);
            // 
            // btnSearch
            // 
            this.btnSearch.Enabled = false;
            this.btnSearch.Image = global::Bank.Properties.Resources.search__3_;
            this.btnSearch.Location = new System.Drawing.Point(299, 4);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(30, 30);
            this.btnSearch.TabIndex = 3;
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // ctrlAddNew_UpdateClient1
            // 
            this.ctrlAddNew_UpdateClient1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ctrlAddNew_UpdateClient1.Enabled = false;
            this.ctrlAddNew_UpdateClient1.Location = new System.Drawing.Point(0, 36);
            this.ctrlAddNew_UpdateClient1.Name = "ctrlAddNew_UpdateClient1";
            this.ctrlAddNew_UpdateClient1.Size = new System.Drawing.Size(412, 376);
            this.ctrlAddNew_UpdateClient1.TabIndex = 0;
            this.ctrlAddNew_UpdateClient1.ClientChanged += new System.EventHandler<Bank.Clients.ctrlAddNew_UpdateClient.Client_PersonEventArgs>(this.ctrlAddNew_UpdateClient1_ClientChanged);
            // 
            // ctrlSelectClient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ctrlAddNew_UpdateClient1);
            this.Name = "ctrlSelectClient";
            this.Size = new System.Drawing.Size(412, 416);
            this.Load += new System.EventHandler(this.ctrlSelectClient_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ctrlAddNew_UpdateClient ctrlAddNew_UpdateClient1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Button btnSearch;
    }
}
