﻿using BankBusinessLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bank.Clients.Controls
{
    public partial class ctrlSelectClient : UserControl
    {
        public event EventHandler<int> OnClientSelected;

        public string Title
        {
            set
            {
                ctrlAddNew_UpdateClient1.Title = value;
            }
            get
            {
                return ctrlAddNew_UpdateClient1.Title;
            }
        }
        public Color TitleColor
        {
            set
            {
                ctrlAddNew_UpdateClient1.TitleColor = value;
            }
        }
        public ctrlSelectClient()
        {
            InitializeComponent();
        }

        private void InitialValues()
        {
            txtSearch.Focus();
        }
        private void ctrlSelectClient_Load(object sender, EventArgs e)
        {
            InitialValues();
        }

        public void MakeInfoControlDisable()
        {
            ctrlAddNew_UpdateClient1.MakeAllTextBoxDisable();
        }
        private void txtSearch_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (clsClientsBusinessLayer.IsExists(Convert.ToInt32(txtSearch.Text)))
            {
                ctrlAddNew_UpdateClient1.ClientID = Convert.ToInt32(txtSearch.Text);
                ctrlAddNew_UpdateClient1._PerformOperationByMode();
                ctrlAddNew_UpdateClient1.Enabled = true;
                if (OnClientSelected != null)
                    OnClientSelected?.Invoke(this, Convert.ToInt32(txtSearch.Text));
            }
            else
            {
                MessageBox.Show($"Not Found Client With ID : {txtSearch.Text} Choose Another one.", "Not found", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtSearch.Text = string.Empty;
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            btnSearch.Enabled = true;
        }

        private void ctrlAddNew_UpdateClient1_ClientChanged(object sender, ctrlAddNew_UpdateClient.Client_PersonEventArgs e)
        {
            ctrlAddNew_UpdateClient1.MakeAllTextBoxDisable();
        }
    }
}
