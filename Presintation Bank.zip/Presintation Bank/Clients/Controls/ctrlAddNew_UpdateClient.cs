﻿using BankBusinessLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bank.Clients
{
   
    public partial class ctrlAddNew_UpdateClient : UserControl
    {
        public class Client_PersonEventArgs
        {
            public clsPeopleBusinessLayer PersonInfo { get; set; }

            public clsClientsBusinessLayer Client { get; set; }

            public bool IsSaveButtonClicked { get; set; }

            public Client_PersonEventArgs(clsClientsBusinessLayer ClientInfo, bool IsSaveButtonClicked)
            {
                this.Client = ClientInfo;
                this.PersonInfo = clsPeopleBusinessLayer.Find(ClientInfo.PersonInfo.PersonID);
                this.IsSaveButtonClicked = IsSaveButtonClicked;
            }

        }

        public int ClientID = -1;

        public event EventHandler<Client_PersonEventArgs> ClientChanged;

        public string Title
        {
            get
            {
                return lblTitle.Text;
            }
            set
            {
                lblTitle.Text = value;
            }
        }
        public Color TitleColor
        {
            set
            {
                lblTitle.ForeColor = value;
            }
        }

        protected virtual void OnSaveButtonClick(Client_PersonEventArgs e)
        {
            ClientChanged?.Invoke(this, e);
        }
        public void OnSaveButtonClick(clsClientsBusinessLayer ClientInfo,bool IsButtonSaveClicked)
        {
            OnSaveButtonClick(new Client_PersonEventArgs(ClientInfo, IsButtonSaveClicked));
        }


        enum enMode { AddNew,Update}
         enMode Mode = enMode.Update;
        clsClientsBusinessLayer Client = new clsClientsBusinessLayer();


        private void _SelectMode()
        {
            this.Mode = (ClientID != -1) ? enMode.Update : enMode.AddNew;
        }
        public ctrlAddNew_UpdateClient()
        {
            InitializeComponent();
            
        }

        private void _CustomInterface()
        {
            panel1.BackColor = System.Drawing.ColorTranslator.FromHtml("#81A263");
            lblTitle.Text = (this.Mode == enMode.AddNew) ? "Add New Client" : "Update Client";
            txtFirstName.Focus();
        }
        
        public void MakeAllTextBoxDisable()
        {
            txtAccoutBalance.Enabled = false;
            txtFirstName.Enabled = false;
            txtSecondName.Enabled = false;
            txtThirdName.Enabled = false;
            txtPhoneNumber.Enabled = false;
            txtPINCode.Enabled = false;
        }

        public void _PerformOperationByMode()
        {
            _SelectMode();

            switch (this.Mode)
            {
                case enMode.AddNew:
                    {
                        break;
                    }
                case enMode.Update:
                    {
                        _LoadClientDataFromDataBase();
                        btnSaveClient.Enabled = true;
                        break;
                    }
            }
        }
        
        private void ctrlAddNew_UpdateClient_Load(object sender, EventArgs e)
        {
            _CustomInterface();
            _PerformOperationByMode();
        }

        private void _LoadClientDataToDataBase()
        {
            //This function will Call In Update And Add New
            Client.PersonInfo.firstName = txtFirstName.Text;
            Client.PersonInfo.midName = txtSecondName.Text;
            Client.PersonInfo.lastName = txtThirdName.Text;
            Client.PersonInfo.pINCode = clsUtility.ComputeHash(txtPINCode.Text);
            Client.PersonInfo.accountBalance = Convert.ToDecimal(txtAccoutBalance.Text);
            Client.PersonInfo.phoneNumber = txtPhoneNumber.Text;
            Client.PersonInfo.CreatedBy = clsGloablUser.CurrentUser.UserID;
            if (this.Mode == enMode.AddNew)
                Client.PersonInfo.accountNumber = clsUtility.GetNewAccountNumber();


        }

        private bool _Save()
        {
            bool IsSaved = false;

            _LoadClientDataToDataBase();

            if (Mode == enMode.AddNew)
                IsSaved = Client.Save();
            else
                IsSaved = Client.Save(clsGloablUser.CurrentUser.UserID);

            return IsSaved;
        }

        //This method will work when Mode = enMode.Update
        private void _LoadClientDataFromDataBase()
        {
           
                Client = clsClientsBusinessLayer.Find(ClientID);

                txtFirstName.Text = Client.PersonInfo.firstName;
                txtSecondName.Text = Client.PersonInfo.midName;
                txtThirdName.Text = Client.PersonInfo.lastName;
                txtAccoutBalance.Text = Client.PersonInfo.accountBalance.ToString();
                txtPhoneNumber.Text = Client.PersonInfo.phoneNumber;
                txtPINCode.Text = Client.PersonInfo.pINCode;

                lblAccountNumber.Text = Client.PersonInfo.accountNumber;
                lblClientID.Text = Client.ClientID.ToString();
                lblPersonID.Text = Client.PersonInfo.PersonID.ToString();
            
        }

        private void btnSaveClient_Click(object sender, EventArgs e)
        {
            if (_Save())
            {
                MessageBox.Show((Mode == enMode.AddNew) ? "Client Added Successfuly" : "Client Updated Successfuly", "Done", MessageBoxButtons.OK, MessageBoxIcon.Information);

                lblAccountNumber.Text = Client.PersonInfo.accountNumber;
                lblClientID.Text= Client.ClientID.ToString();
                lblPersonID.Text = Client.PersonInfo.PersonID.ToString();

                btnSaveClient.Enabled = false;

                //Rais Event
                if (ClientChanged != null)
                    OnSaveButtonClick(Client, true);
            }
            else
                MessageBox.Show("An Error Occur!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

        }

        private void txtFirstName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar))
                e.Handled = true;
        }

        private void txtPhoneNumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(char.IsLetter(e.KeyChar))
                e.Handled = true;
        }

        private bool _ValidatingTextBoxs(TextBox box)
        {
            if (string.IsNullOrEmpty(box.Text))
            {
                errorProvider1.SetError(box, "This Field Requerd");
                box.Focus();
                return false;
            }
            else
                return true;
        }
        private void txtFirstName_Validating(object sender, CancelEventArgs e)
        {
            if (_ValidatingTextBoxs((TextBox)sender) == false)
            {
                e.Cancel = true;
            }
            else
                e.Cancel = false;
        }
        private void txtAccoutBalance_Validating(object sender, CancelEventArgs e)
        {
            if (_ValidatingTextBoxs((TextBox)sender) == false)
            {
                e.Cancel = true;
            }
            else
            {
                btnSaveClient.Enabled = true;
                e.Cancel = false;
            }
        }
    }
}
