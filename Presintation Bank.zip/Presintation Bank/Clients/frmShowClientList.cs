﻿using Bank.Clients.Controls;
using BankBusinessLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bank.Clients
{
    public partial class frmShowClientList : Form
    {
        public frmShowClientList()
        {
            InitializeComponent();
        }
        private void _CustomInterface()
        {
            //Black
            //#0f1414  : Forest Shadow
            //#232120  : Chocolate noir
            //#170a14  : valvet aubergine


            //#F5f5f5

            panel1.BackColor = System.Drawing.ColorTranslator.FromHtml("#Fef5ea");
        }

        private void _GenerateClientCard()
        {
            int X = 10; // 10 - 460
            int Y = 10; // More Increase
            int Count = 0;

            DataTable ClientsInfo = clsClientsBusinessLayer.GetAllClients();

            foreach (DataRow Client in ClientsInfo.Rows)
            {
                Count++;

                ctrlClientInfo Card = new ctrlClientInfo(Convert.ToInt32(Client["PersonID"]),
                                                         Convert.ToInt32(Client["ClientID"]),
                                                         Convert.ToString(Client["FullName"])
                                                         , Convert.ToString(Client["PhoneNumber"]),
                                                         Convert.ToString(Client["AccountBalance"]),
                                                         Convert.ToString(Client["AccountNumber"]));
                Card.Location = new Point(X, Y);
                Card.Left = X;
                Card.Top = Y;
                panel1.Controls.Add(Card);


                X = (X == 10) ? +460 : 10;
                if (Count == 2)
                {
                    Y = Y + 245 + 10;
                    Count = 0;
                }
                //Space Between Controls virtical : 10 
                //User Control : 245
            }

        }

        private void frmShowClientList_Load(object sender, EventArgs e)
        {
            _CustomInterface();
            _GenerateClientCard();
        }
    }
}
