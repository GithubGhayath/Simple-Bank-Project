﻿using BankBusinessLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bank.Users.Controls
{
    public partial class ctrlSelectUser : UserControl
    {
        public event EventHandler<int> GetUserID;

        public ctrlSelectUser()
        {
            InitializeComponent();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            DataTable UserInfo =new DataTable();
            if(string.IsNullOrEmpty(txtFindUser.Text))
            {
                MessageBox.Show("Input UserID for search", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            UserInfo = clsUsersBusinessLayer.SelectUserFromView(Convert.ToInt32(txtFindUser.Text));
            if(UserInfo.Rows.Count==0)
            {
                MessageBox.Show("No User with ID : " + txtFindUser.Text , "Null", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                foreach(DataRow R in UserInfo.Rows)
                {
                    ctrlUserInfo1.UserID = Convert.ToInt32(R["UserID"]);
                    ctrlUserInfo1.FullName = Convert.ToString(R["FullName"]);
                    ctrlUserInfo1.UserName = Convert.ToString(R["UserName"]);
                    ctrlUserInfo1._LoadDataToScreen();
                    if (GetUserID != null)
                        GetUserID?.Invoke(this, ctrlUserInfo1.UserID);
                }
            }
           
        }

        private void txtFindUser_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}
