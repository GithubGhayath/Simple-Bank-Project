﻿using BankBusinessLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bank.Users.Controls
{
    public partial class ctrlUserInfo : UserControl
    {

        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn(
           int nLeftRect, int nTopRect, int nRightRect, int nBottomRect,
           int nWidthEllipse, int nHeightEllipse
       );

        public string UserName { get; set; }
        public int UserID { get; set; }
        public string FullName { get; set; }
        public ctrlUserInfo()
        {
            InitializeComponent();
        }
        public ctrlUserInfo(string UserName,int UserID,string FullName)
        {
            InitializeComponent();
            this.UserName = UserName;
            this.UserID = UserID;
            this.FullName = FullName;
        }

        private void _CustomInterface()
        {
            this.BackColor = System.Drawing.ColorTranslator.FromHtml("#d7dff7");
        }
        private string _PersmissionsAsTests(clsUsersBusinessLayer User)
        {
            string PermissionAsText=string.Empty;

            if ((User.Permissions & 2) == 2)
                PermissionAsText += ", Add Client";

            if ((User.Permissions & 1) == 1)
                PermissionAsText += ", Clients List";

            if ((User.Permissions & 8) == 8)
                PermissionAsText += ", Delete Client";


            if ((User.Permissions & 4) == 4)
                PermissionAsText += ", Update Client";

            if ((User.Permissions & 16) == 16)
                PermissionAsText += ", Find Client";

            if ((User.Permissions & 32) == 32)
                PermissionAsText += ", User Management";

            if ((User.Permissions & 64) == 64)
                PermissionAsText += ", Transactions";

            PermissionAsText = PermissionAsText.StartsWith(",") ? PermissionAsText.Substring(1) : PermissionAsText;
            PermissionAsText = PermissionAsText.EndsWith(",") ? PermissionAsText.Substring(0, PermissionAsText.Length - 1) : PermissionAsText;


            return PermissionAsText;
        }
        public void _LoadDataToScreen()
        {
            _CustomInterface();
            clsUsersBusinessLayer temp = clsUsersBusinessLayer.Find(UserID);
            lblUserName.Text = UserName;
            lblUserID.Text = UserID.ToString();
            lblFullName.Text =FullName;
            lblPermissions.Text = _PersmissionsAsTests(temp);
        }
        private void ctrlUserInfo_Load(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(FullName)) { return; }
            if (!DesignMode)
            {
                _LoadDataToScreen();
            }
        }
    }
}
