﻿namespace Bank.Users.Controls
{
    partial class ctrlSelectUser
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtFindUser = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.ctrlUserInfo1 = new Bank.Users.Controls.ctrlUserInfo();
            this.SuspendLayout();
            // 
            // txtFindUser
            // 
            this.txtFindUser.Location = new System.Drawing.Point(70, 15);
            this.txtFindUser.Name = "txtFindUser";
            this.txtFindUser.Size = new System.Drawing.Size(100, 20);
            this.txtFindUser.TabIndex = 1;
            this.txtFindUser.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFindUser_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Leelawadee UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(23, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "UserID:";
            // 
            // btnSearch
            // 
            this.btnSearch.Image = global::Bank.Properties.Resources.search__3_;
            this.btnSearch.Location = new System.Drawing.Point(178, 13);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(25, 25);
            this.btnSearch.TabIndex = 3;
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // ctrlUserInfo1
            // 
            this.ctrlUserInfo1.FullName = null;
            this.ctrlUserInfo1.Location = new System.Drawing.Point(0, 44);
            this.ctrlUserInfo1.Name = "ctrlUserInfo1";
            this.ctrlUserInfo1.Size = new System.Drawing.Size(240, 339);
            this.ctrlUserInfo1.TabIndex = 0;
            this.ctrlUserInfo1.UserID = 0;
            this.ctrlUserInfo1.UserName = null;
            // 
            // ctrlSelectUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtFindUser);
            this.Controls.Add(this.ctrlUserInfo1);
            this.Name = "ctrlSelectUser";
            this.Size = new System.Drawing.Size(240, 385);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ctrlUserInfo ctrlUserInfo1;
        private System.Windows.Forms.TextBox txtFindUser;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnSearch;
    }
}
