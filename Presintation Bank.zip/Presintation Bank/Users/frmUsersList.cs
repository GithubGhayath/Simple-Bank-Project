﻿using Bank.Users.Controls;
using BankBusinessLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bank.Users
{
    public partial class frmUsersList : Form
    {
        DataTable UserInfo = new DataTable();
        public frmUsersList()
        {
            InitializeComponent();
            UserInfo = clsUsersBusinessLayer.GetAllUsers();
        }

        private void _GenerateCards()
        {
            int X = 10;
            int Y = 10;
            int Count = 0;

            foreach (DataRow row in UserInfo.Rows)
            {
                ctrlUserInfo Card = new ctrlUserInfo(Convert.ToString(row["UserName"]), Convert.ToInt32(row["UserID"]), Convert.ToString(row["FullName"]));
                Card.Location = new Point(X, Y);
                Card.Left = X;
                Card.Top = Y;
                panel1.Controls.Add(Card);

                X = (X == 10) ? 260 : (X == 260) ? 510 : (X == 510) ? 10 : 0;
                Count++;

                if(Count==3)
                {
                    Count = 0;
                    Y = Y + 339 + 10;
                }
            }
        }
        private void frmUsersList_Load(object sender, EventArgs e)
        {
            _GenerateCards();
        }
    }
}
