﻿namespace Bank.Users
{
    partial class frmDashboardScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.gpbMin = new Guna.UI2.WinForms.Guna2VProgressBar();
            this.gpbLess1 = new Guna.UI2.WinForms.Guna2VProgressBar();
            this.gpbLess2 = new Guna.UI2.WinForms.Guna2VProgressBar();
            this.gpbMax = new Guna.UI2.WinForms.Guna2VProgressBar();
            this.gpbLess3 = new Guna.UI2.WinForms.Guna2VProgressBar();
            this.gpbLess4 = new Guna.UI2.WinForms.Guna2VProgressBar();
            this.lblFifth = new System.Windows.Forms.Label();
            this.lblFourth = new System.Windows.Forms.Label();
            this.lblSixth = new System.Windows.Forms.Label();
            this.lblThird = new System.Windows.Forms.Label();
            this.lblSecond = new System.Windows.Forms.Label();
            this.lblFirst = new System.Windows.Forms.Label();
            this.guna2ShadowPanel1 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.glblUserActivation = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2ShadowPanel2 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.gdgvUserInfo = new Guna.UI2.WinForms.Guna2DataGridView();
            this.guna2ShadowPanel3 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.guna2ShadowPanel4 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.lblNumberOfUsers = new System.Windows.Forms.Label();
            this.guna2ShadowPanel5 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.lblHiliestPerformance = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.guna2ShadowPanel6 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.lblDate = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.guna2ShadowPanel7 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.guna2ShadowPanel1.SuspendLayout();
            this.guna2ShadowPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gdgvUserInfo)).BeginInit();
            this.guna2ShadowPanel3.SuspendLayout();
            this.guna2ShadowPanel4.SuspendLayout();
            this.guna2ShadowPanel5.SuspendLayout();
            this.guna2ShadowPanel6.SuspendLayout();
            this.guna2ShadowPanel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(908, 31);
            this.panel1.TabIndex = 0;
            // 
            // gpbMin
            // 
            this.gpbMin.AutoRoundedCorners = true;
            this.gpbMin.BackColor = System.Drawing.Color.Transparent;
            this.gpbMin.BorderRadius = 12;
            this.gpbMin.Location = new System.Drawing.Point(260, 38);
            this.gpbMin.Name = "gpbMin";
            this.gpbMin.Size = new System.Drawing.Size(26, 140);
            this.gpbMin.TabIndex = 2;
            this.gpbMin.Text = "guna2VProgressBar1";
            this.gpbMin.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            this.gpbMin.Value = 50;
            // 
            // gpbLess1
            // 
            this.gpbLess1.AutoRoundedCorners = true;
            this.gpbLess1.BackColor = System.Drawing.Color.Transparent;
            this.gpbLess1.BorderRadius = 12;
            this.gpbLess1.Location = new System.Drawing.Point(72, 38);
            this.gpbLess1.Name = "gpbLess1";
            this.gpbLess1.Size = new System.Drawing.Size(26, 140);
            this.gpbLess1.TabIndex = 3;
            this.gpbLess1.Text = "guna2VProgressBar2";
            this.gpbLess1.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            this.gpbLess1.Value = 50;
            // 
            // gpbLess2
            // 
            this.gpbLess2.AutoRoundedCorners = true;
            this.gpbLess2.BackColor = System.Drawing.Color.Transparent;
            this.gpbLess2.BorderRadius = 12;
            this.gpbLess2.Location = new System.Drawing.Point(119, 38);
            this.gpbLess2.Name = "gpbLess2";
            this.gpbLess2.Size = new System.Drawing.Size(26, 140);
            this.gpbLess2.TabIndex = 4;
            this.gpbLess2.Text = "guna2VProgressBar3";
            this.gpbLess2.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            this.gpbLess2.Value = 50;
            // 
            // gpbMax
            // 
            this.gpbMax.AutoRoundedCorners = true;
            this.gpbMax.BackColor = System.Drawing.Color.Transparent;
            this.gpbMax.BorderRadius = 12;
            this.gpbMax.Location = new System.Drawing.Point(25, 38);
            this.gpbMax.Name = "gpbMax";
            this.gpbMax.Size = new System.Drawing.Size(26, 140);
            this.gpbMax.TabIndex = 5;
            this.gpbMax.Text = "guna2VProgressBar4";
            this.gpbMax.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            this.gpbMax.Value = 50;
            // 
            // gpbLess3
            // 
            this.gpbLess3.AutoRoundedCorners = true;
            this.gpbLess3.BackColor = System.Drawing.Color.Transparent;
            this.gpbLess3.BorderRadius = 12;
            this.gpbLess3.Location = new System.Drawing.Point(166, 38);
            this.gpbLess3.Name = "gpbLess3";
            this.gpbLess3.Size = new System.Drawing.Size(26, 140);
            this.gpbLess3.TabIndex = 6;
            this.gpbLess3.Text = "guna2VProgressBar5";
            this.gpbLess3.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            this.gpbLess3.Value = 50;
            // 
            // gpbLess4
            // 
            this.gpbLess4.AutoRoundedCorners = true;
            this.gpbLess4.BackColor = System.Drawing.Color.Transparent;
            this.gpbLess4.BorderRadius = 12;
            this.gpbLess4.Location = new System.Drawing.Point(213, 38);
            this.gpbLess4.Name = "gpbLess4";
            this.gpbLess4.Size = new System.Drawing.Size(26, 140);
            this.gpbLess4.TabIndex = 7;
            this.gpbLess4.Text = "guna2VProgressBar6";
            this.gpbLess4.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            this.gpbLess4.Value = 50;
            // 
            // lblFifth
            // 
            this.lblFifth.AutoSize = true;
            this.lblFifth.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblFifth.Font = new System.Drawing.Font("HoloLens MDL2 Assets", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFifth.Location = new System.Drawing.Point(212, 184);
            this.lblFifth.Name = "lblFifth";
            this.lblFifth.Size = new System.Drawing.Size(29, 12);
            this.lblFifth.TabIndex = 10;
            this.lblFifth.Text = "label3";
            // 
            // lblFourth
            // 
            this.lblFourth.AutoSize = true;
            this.lblFourth.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblFourth.Font = new System.Drawing.Font("HoloLens MDL2 Assets", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFourth.Location = new System.Drawing.Point(165, 184);
            this.lblFourth.Name = "lblFourth";
            this.lblFourth.Size = new System.Drawing.Size(29, 12);
            this.lblFourth.TabIndex = 11;
            this.lblFourth.Text = "label4";
            // 
            // lblSixth
            // 
            this.lblSixth.AutoSize = true;
            this.lblSixth.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblSixth.Font = new System.Drawing.Font("HoloLens MDL2 Assets", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSixth.Location = new System.Drawing.Point(259, 184);
            this.lblSixth.Name = "lblSixth";
            this.lblSixth.Size = new System.Drawing.Size(29, 12);
            this.lblSixth.TabIndex = 13;
            this.lblSixth.Text = "label6";
            // 
            // lblThird
            // 
            this.lblThird.AutoSize = true;
            this.lblThird.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblThird.Font = new System.Drawing.Font("HoloLens MDL2 Assets", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblThird.Location = new System.Drawing.Point(118, 184);
            this.lblThird.Name = "lblThird";
            this.lblThird.Size = new System.Drawing.Size(29, 12);
            this.lblThird.TabIndex = 12;
            this.lblThird.Text = "label5";
            // 
            // lblSecond
            // 
            this.lblSecond.AutoSize = true;
            this.lblSecond.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblSecond.Font = new System.Drawing.Font("HoloLens MDL2 Assets", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecond.Location = new System.Drawing.Point(71, 184);
            this.lblSecond.Name = "lblSecond";
            this.lblSecond.Size = new System.Drawing.Size(29, 12);
            this.lblSecond.TabIndex = 9;
            this.lblSecond.Text = "label2";
            // 
            // lblFirst
            // 
            this.lblFirst.AutoSize = true;
            this.lblFirst.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblFirst.Font = new System.Drawing.Font("HoloLens MDL2 Assets", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFirst.Location = new System.Drawing.Point(24, 184);
            this.lblFirst.Name = "lblFirst";
            this.lblFirst.Size = new System.Drawing.Size(29, 12);
            this.lblFirst.TabIndex = 8;
            this.lblFirst.Text = "label1";
            // 
            // guna2ShadowPanel1
            // 
            this.guna2ShadowPanel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2ShadowPanel1.Controls.Add(this.glblUserActivation);
            this.guna2ShadowPanel1.Controls.Add(this.lblFirst);
            this.guna2ShadowPanel1.Controls.Add(this.gpbMin);
            this.guna2ShadowPanel1.Controls.Add(this.lblSecond);
            this.guna2ShadowPanel1.Controls.Add(this.gpbMax);
            this.guna2ShadowPanel1.Controls.Add(this.lblThird);
            this.guna2ShadowPanel1.Controls.Add(this.gpbLess3);
            this.guna2ShadowPanel1.Controls.Add(this.lblSixth);
            this.guna2ShadowPanel1.Controls.Add(this.gpbLess2);
            this.guna2ShadowPanel1.Controls.Add(this.lblFourth);
            this.guna2ShadowPanel1.Controls.Add(this.gpbLess4);
            this.guna2ShadowPanel1.Controls.Add(this.lblFifth);
            this.guna2ShadowPanel1.Controls.Add(this.gpbLess1);
            this.guna2ShadowPanel1.FillColor = System.Drawing.Color.White;
            this.guna2ShadowPanel1.Location = new System.Drawing.Point(583, 272);
            this.guna2ShadowPanel1.Name = "guna2ShadowPanel1";
            this.guna2ShadowPanel1.Radius = 15;
            this.guna2ShadowPanel1.ShadowColor = System.Drawing.SystemColors.ActiveCaption;
            this.guna2ShadowPanel1.ShadowStyle = Guna.UI2.WinForms.Guna2ShadowPanel.ShadowMode.ForwardDiagonal;
            this.guna2ShadowPanel1.Size = new System.Drawing.Size(313, 212);
            this.guna2ShadowPanel1.TabIndex = 14;
            // 
            // glblUserActivation
            // 
            this.glblUserActivation.BackColor = System.Drawing.Color.Transparent;
            this.glblUserActivation.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.glblUserActivation.Location = new System.Drawing.Point(20, 9);
            this.glblUserActivation.Name = "glblUserActivation";
            this.glblUserActivation.Size = new System.Drawing.Size(121, 18);
            this.glblUserActivation.TabIndex = 15;
            this.glblUserActivation.Text = "User Performance:";
            // 
            // guna2ShadowPanel2
            // 
            this.guna2ShadowPanel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2ShadowPanel2.Controls.Add(this.pictureBox6);
            this.guna2ShadowPanel2.Controls.Add(this.pictureBox5);
            this.guna2ShadowPanel2.Controls.Add(this.pictureBox4);
            this.guna2ShadowPanel2.Controls.Add(this.pictureBox2);
            this.guna2ShadowPanel2.FillColor = System.Drawing.Color.White;
            this.guna2ShadowPanel2.Location = new System.Drawing.Point(16, 48);
            this.guna2ShadowPanel2.Name = "guna2ShadowPanel2";
            this.guna2ShadowPanel2.Radius = 8;
            this.guna2ShadowPanel2.ShadowColor = System.Drawing.SystemColors.ActiveCaption;
            this.guna2ShadowPanel2.Size = new System.Drawing.Size(83, 402);
            this.guna2ShadowPanel2.TabIndex = 15;
            // 
            // gdgvUserInfo
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.gdgvUserInfo.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gdgvUserInfo.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.gdgvUserInfo.ColumnHeadersHeight = 15;
            this.gdgvUserInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.gdgvUserInfo.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gdgvUserInfo.DefaultCellStyle = dataGridViewCellStyle3;
            this.gdgvUserInfo.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.gdgvUserInfo.Location = new System.Drawing.Point(11, 42);
            this.gdgvUserInfo.Name = "gdgvUserInfo";
            this.gdgvUserInfo.RowHeadersVisible = false;
            this.gdgvUserInfo.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.gdgvUserInfo.Size = new System.Drawing.Size(447, 143);
            this.gdgvUserInfo.TabIndex = 16;
            this.gdgvUserInfo.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.gdgvUserInfo.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.gdgvUserInfo.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.gdgvUserInfo.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.gdgvUserInfo.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.gdgvUserInfo.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.gdgvUserInfo.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.gdgvUserInfo.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gdgvUserInfo.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.gdgvUserInfo.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gdgvUserInfo.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.gdgvUserInfo.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.gdgvUserInfo.ThemeStyle.HeaderStyle.Height = 15;
            this.gdgvUserInfo.ThemeStyle.ReadOnly = false;
            this.gdgvUserInfo.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.gdgvUserInfo.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.gdgvUserInfo.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gdgvUserInfo.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.gdgvUserInfo.ThemeStyle.RowsStyle.Height = 22;
            this.gdgvUserInfo.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.gdgvUserInfo.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            // 
            // guna2ShadowPanel3
            // 
            this.guna2ShadowPanel3.BackColor = System.Drawing.Color.Transparent;
            this.guna2ShadowPanel3.Controls.Add(this.guna2HtmlLabel1);
            this.guna2ShadowPanel3.Controls.Add(this.gdgvUserInfo);
            this.guna2ShadowPanel3.FillColor = System.Drawing.Color.White;
            this.guna2ShadowPanel3.Location = new System.Drawing.Point(109, 273);
            this.guna2ShadowPanel3.Name = "guna2ShadowPanel3";
            this.guna2ShadowPanel3.Radius = 15;
            this.guna2ShadowPanel3.ShadowColor = System.Drawing.SystemColors.ActiveCaption;
            this.guna2ShadowPanel3.ShadowStyle = Guna.UI2.WinForms.Guna2ShadowPanel.ShadowMode.ForwardDiagonal;
            this.guna2ShadowPanel3.Size = new System.Drawing.Size(467, 212);
            this.guna2ShadowPanel3.TabIndex = 16;
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(23, 9);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(62, 18);
            this.guna2HtmlLabel1.TabIndex = 16;
            this.guna2HtmlLabel1.Text = "All Users:";
            // 
            // Column1
            // 
            this.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.Column1.FillWeight = 40F;
            this.Column1.Frozen = true;
            this.Column1.HeaderText = "UserID";
            this.Column1.MinimumWidth = 40;
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 63;
            // 
            // Column2
            // 
            this.Column2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.Column2.FillWeight = 40F;
            this.Column2.Frozen = true;
            this.Column2.HeaderText = "PersonID";
            this.Column2.MinimumWidth = 40;
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Width = 74;
            // 
            // Column3
            // 
            this.Column3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.Column3.FillWeight = 150F;
            this.Column3.HeaderText = "Full Name";
            this.Column3.MinimumWidth = 150;
            this.Column3.Name = "Column3";
            this.Column3.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column3.Width = 150;
            // 
            // Column4
            // 
            this.Column4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.Column4.FillWeight = 90F;
            this.Column4.HeaderText = "User Name";
            this.Column4.MinimumWidth = 90;
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            this.Column4.Width = 90;
            // 
            // Column5
            // 
            this.Column5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.Column5.FillWeight = 60F;
            this.Column5.HeaderText = "Password";
            this.Column5.MinimumWidth = 60;
            this.Column5.Name = "Column5";
            this.Column5.Width = 76;
            // 
            // guna2ShadowPanel4
            // 
            this.guna2ShadowPanel4.BackColor = System.Drawing.Color.Transparent;
            this.guna2ShadowPanel4.Controls.Add(this.lblNumberOfUsers);
            this.guna2ShadowPanel4.Controls.Add(this.label1);
            this.guna2ShadowPanel4.FillColor = System.Drawing.Color.White;
            this.guna2ShadowPanel4.Location = new System.Drawing.Point(145, 68);
            this.guna2ShadowPanel4.Name = "guna2ShadowPanel4";
            this.guna2ShadowPanel4.Radius = 8;
            this.guna2ShadowPanel4.ShadowColor = System.Drawing.SystemColors.ActiveCaption;
            this.guna2ShadowPanel4.Size = new System.Drawing.Size(200, 100);
            this.guna2ShadowPanel4.TabIndex = 17;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(13, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(162, 14);
            this.label1.TabIndex = 0;
            this.label1.Text = "Number of users in system:";
            // 
            // lblNumberOfUsers
            // 
            this.lblNumberOfUsers.AutoSize = true;
            this.lblNumberOfUsers.Font = new System.Drawing.Font("Arial", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumberOfUsers.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblNumberOfUsers.Location = new System.Drawing.Point(74, 43);
            this.lblNumberOfUsers.Name = "lblNumberOfUsers";
            this.lblNumberOfUsers.Size = new System.Drawing.Size(55, 40);
            this.lblNumberOfUsers.TabIndex = 1;
            this.lblNumberOfUsers.Text = "61";
            // 
            // guna2ShadowPanel5
            // 
            this.guna2ShadowPanel5.BackColor = System.Drawing.Color.Transparent;
            this.guna2ShadowPanel5.Controls.Add(this.lblHiliestPerformance);
            this.guna2ShadowPanel5.Controls.Add(this.label3);
            this.guna2ShadowPanel5.FillColor = System.Drawing.Color.White;
            this.guna2ShadowPanel5.Location = new System.Drawing.Point(395, 68);
            this.guna2ShadowPanel5.Name = "guna2ShadowPanel5";
            this.guna2ShadowPanel5.Radius = 8;
            this.guna2ShadowPanel5.ShadowColor = System.Drawing.SystemColors.ActiveCaption;
            this.guna2ShadowPanel5.Size = new System.Drawing.Size(200, 100);
            this.guna2ShadowPanel5.TabIndex = 18;
            // 
            // lblHiliestPerformance
            // 
            this.lblHiliestPerformance.AutoSize = true;
            this.lblHiliestPerformance.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHiliestPerformance.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblHiliestPerformance.Location = new System.Drawing.Point(58, 55);
            this.lblHiliestPerformance.Name = "lblHiliestPerformance";
            this.lblHiliestPerformance.Size = new System.Drawing.Size(62, 17);
            this.lblHiliestPerformance.TabIndex = 1;
            this.lblHiliestPerformance.Text = "Ghayath";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label3.Location = new System.Drawing.Point(13, 18);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(153, 14);
            this.label3.TabIndex = 0;
            this.label3.Text = "The best performance for:";
            // 
            // guna2ShadowPanel6
            // 
            this.guna2ShadowPanel6.BackColor = System.Drawing.Color.Transparent;
            this.guna2ShadowPanel6.Controls.Add(this.lblDate);
            this.guna2ShadowPanel6.Controls.Add(this.label4);
            this.guna2ShadowPanel6.FillColor = System.Drawing.Color.White;
            this.guna2ShadowPanel6.Location = new System.Drawing.Point(645, 68);
            this.guna2ShadowPanel6.Name = "guna2ShadowPanel6";
            this.guna2ShadowPanel6.Radius = 8;
            this.guna2ShadowPanel6.ShadowColor = System.Drawing.SystemColors.ActiveCaption;
            this.guna2ShadowPanel6.Size = new System.Drawing.Size(200, 100);
            this.guna2ShadowPanel6.TabIndex = 19;
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblDate.Location = new System.Drawing.Point(58, 55);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(62, 17);
            this.lblDate.TabIndex = 1;
            this.lblDate.Text = "Ghayath";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label4.Location = new System.Drawing.Point(13, 18);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 14);
            this.label4.TabIndex = 0;
            this.label4.Text = "Today\'s Date:";
            // 
            // guna2ShadowPanel7
            // 
            this.guna2ShadowPanel7.BackColor = System.Drawing.Color.Transparent;
            this.guna2ShadowPanel7.Controls.Add(this.pictureBox3);
            this.guna2ShadowPanel7.Controls.Add(this.label2);
            this.guna2ShadowPanel7.FillColor = System.Drawing.Color.White;
            this.guna2ShadowPanel7.Location = new System.Drawing.Point(185, 187);
            this.guna2ShadowPanel7.Name = "guna2ShadowPanel7";
            this.guna2ShadowPanel7.Radius = 8;
            this.guna2ShadowPanel7.ShadowColor = System.Drawing.Color.LightGray;
            this.guna2ShadowPanel7.Size = new System.Drawing.Size(608, 70);
            this.guna2ShadowPanel7.TabIndex = 20;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(38, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(298, 28);
            this.label2.TabIndex = 2;
            this.label2.Text = "*All this information is based on data in the database\r\nIt will change every day " +
    "and when an operation is performed";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Bank.Properties.Resources.info__2_;
            this.pictureBox3.Location = new System.Drawing.Point(535, 21);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(32, 32);
            this.pictureBox3.TabIndex = 3;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::Bank.Properties.Resources.web_analytics;
            this.pictureBox6.Location = new System.Drawing.Point(26, 148);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(32, 32);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 19;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::Bank.Properties.Resources.analytics;
            this.pictureBox5.Location = new System.Drawing.Point(26, 250);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(32, 32);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 18;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::Bank.Properties.Resources.pie_chart;
            this.pictureBox4.Location = new System.Drawing.Point(26, 199);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(32, 32);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 17;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Bank.Properties.Resources.analyzing__1_;
            this.pictureBox2.Location = new System.Drawing.Point(11, 20);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(62, 62);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 16;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Bank.Properties.Resources.close__2_;
            this.pictureBox1.Location = new System.Drawing.Point(881, 6);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(18, 18);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            this.pictureBox1.MouseLeave += new System.EventHandler(this.pictureBox1_MouseLeave);
            this.pictureBox1.MouseHover += new System.EventHandler(this.pictureBox1_MouseHover);
            // 
            // frmDashboardScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(908, 497);
            this.Controls.Add(this.guna2ShadowPanel7);
            this.Controls.Add(this.guna2ShadowPanel6);
            this.Controls.Add(this.guna2ShadowPanel5);
            this.Controls.Add(this.guna2ShadowPanel4);
            this.Controls.Add(this.guna2ShadowPanel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.guna2ShadowPanel1);
            this.Controls.Add(this.guna2ShadowPanel3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmDashboardScreen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmDashboardScreen";
            this.Load += new System.EventHandler(this.frmDashboardScreen_Load);
            this.panel1.ResumeLayout(false);
            this.guna2ShadowPanel1.ResumeLayout(false);
            this.guna2ShadowPanel1.PerformLayout();
            this.guna2ShadowPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gdgvUserInfo)).EndInit();
            this.guna2ShadowPanel3.ResumeLayout(false);
            this.guna2ShadowPanel3.PerformLayout();
            this.guna2ShadowPanel4.ResumeLayout(false);
            this.guna2ShadowPanel4.PerformLayout();
            this.guna2ShadowPanel5.ResumeLayout(false);
            this.guna2ShadowPanel5.PerformLayout();
            this.guna2ShadowPanel6.ResumeLayout(false);
            this.guna2ShadowPanel6.PerformLayout();
            this.guna2ShadowPanel7.ResumeLayout(false);
            this.guna2ShadowPanel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Guna.UI2.WinForms.Guna2VProgressBar gpbMin;
        private Guna.UI2.WinForms.Guna2VProgressBar gpbLess1;
        private Guna.UI2.WinForms.Guna2VProgressBar gpbLess2;
        private Guna.UI2.WinForms.Guna2VProgressBar gpbMax;
        private Guna.UI2.WinForms.Guna2VProgressBar gpbLess3;
        private Guna.UI2.WinForms.Guna2VProgressBar gpbLess4;
        private System.Windows.Forms.Label lblFifth;
        private System.Windows.Forms.Label lblFourth;
        private System.Windows.Forms.Label lblSixth;
        private System.Windows.Forms.Label lblThird;
        private System.Windows.Forms.Label lblSecond;
        private System.Windows.Forms.Label lblFirst;
        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel1;
        private Guna.UI2.WinForms.Guna2HtmlLabel glblUserActivation;
        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private Guna.UI2.WinForms.Guna2DataGridView gdgvUserInfo;
        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel3;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel4;
        private System.Windows.Forms.Label lblNumberOfUsers;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel5;
        private System.Windows.Forms.Label lblHiliestPerformance;
        private System.Windows.Forms.Label label3;
        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel6;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Label label4;
        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
    }
}