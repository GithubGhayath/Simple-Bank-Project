﻿using BankBusinessLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bank.Users
{
    //#243031  : left side
    //#cb764d  : Some Text
    //#e7edf2  : Back ground
    //#3898db  : Lines

    public partial class frmUserMainScreen : Form
    {
        enum enMode { AddNew,Update}
        enMode Mode { get; set; }
        private void _CustomInterface()
        {
            panel1.BackColor = System.Drawing.ColorTranslator.FromHtml("#243031");
            panel13.BackColor = System.Drawing.ColorTranslator.FromHtml("#243031");
            panel2.BackColor = System.Drawing.ColorTranslator.FromHtml("#e7edf2");
            label2.ForeColor = System.Drawing.ColorTranslator.FromHtml("#cb764d");
            lblTitle.ForeColor = System.Drawing.ColorTranslator.FromHtml("#cb764d");
            panel8.BackColor = System.Drawing.ColorTranslator.FromHtml("#cb764d");
            panel9.BackColor = System.Drawing.ColorTranslator.FromHtml("#cb764d");
            panel10.BackColor = System.Drawing.ColorTranslator.FromHtml("#cb764d");
            panel11.BackColor = System.Drawing.ColorTranslator.FromHtml("#cb764d");
            panel12.BackColor = System.Drawing.ColorTranslator.FromHtml("#cb764d");
            panel15.BackColor = System.Drawing.ColorTranslator.FromHtml("#cb764d");
            label8.ForeColor = System.Drawing.ColorTranslator.FromHtml("#243031");
            label9.ForeColor = System.Drawing.ColorTranslator.FromHtml("#243031");
        }
        public frmUserMainScreen()
        {
            InitializeComponent();
        }

        private void frmUserMainScreen_Load(object sender, EventArgs e)
        {
            _CustomInterface();
        }

        private void pictureBox1_MouseHover(object sender, EventArgs e)
        {
            pictureBox1.BackColor = System.Drawing.ColorTranslator.FromHtml("#d3e1ed");
            
        }

        private void pictureBox1_MouseLeave(object sender, EventArgs e)
        {
            pictureBox1.BackColor = System.Drawing.ColorTranslator.FromHtml("#e7edf2");
        }

        private void pictureBox2_MouseHover(object sender, EventArgs e)
        {
            pictureBox2.BackColor = System.Drawing.ColorTranslator.FromHtml("#d3e1ed");

        }

        private void pictureBox2_MouseLeave(object sender, EventArgs e)
        {

            pictureBox2.BackColor = System.Drawing.ColorTranslator.FromHtml("#e7edf2");
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            // Create a Pen with the desired color and width
            Pen pen = new Pen(Color.White, 1);

            // Define the start and end points for the line
            Point startPoint = new Point(20, 190);
            Point endPoint = new Point(170, 190);

            // Draw the line
            e.Graphics.DrawLine(pen, startPoint, endPoint);

            Pen pen2 = new Pen(Color.White, .5f);
            // Define the start and end points for the line
            Point startPoint2 = new Point(20, 340);
            Point endPoint2 = new Point(170, 340);

            // Draw the line
            e.Graphics.DrawLine(pen2, startPoint2, endPoint2);
        }

        private void _ConvertPanelColorWhenHover(Panel panel)
        {
            panel.BackColor = System.Drawing.ColorTranslator.FromHtml("#0a0d0d");
            
        }
        private void _ConvertPanelColorWhenLeave(Panel panel)
        {
            panel.BackColor = System.Drawing.ColorTranslator.FromHtml("#243031");
        }

        private void panel3_MouseHover(object sender, EventArgs e)
        {
            _ConvertPanelColorWhenHover((Panel)sender);
        }

        private void panel7_MouseLeave(object sender, EventArgs e)
        {
            _ConvertPanelColorWhenLeave((Panel)sender);
        }

        private void frmUserMainScreen_Paint(object sender, PaintEventArgs e)
        {
            //#FD9B63
            //#E7D37F
            //#81A263


            // Inside your Paint event handler (e.g., Form1_Paint)

            // Create a pen (color, width, style)
            Pen BluePen = new Pen(System.Drawing.ColorTranslator.FromHtml("#cb764d"), 2);

            // Define the coordinates of the endpoints
            int x1 = 370;
            int y1 = 200;
            int x2 = 720;
            int y2 = 200;

            // Draw the line
            e.Graphics.DrawLine(BluePen, x1, y1, x2, y2);

            Pen BluePen1 = new Pen(System.Drawing.ColorTranslator.FromHtml("#cb764d"), 3);
            int xx1 = 370;
            int yy1 = 205;
            int xx2 = 720;
            int yy2 = 205;

            e.Graphics.DrawLine(BluePen1, xx1, yy1, xx2, yy2);
        }


        //For Dashboard
        private void panel14_Click(object sender, EventArgs e)
        {
            Form frmDashboardScreen = new frmDashboardScreen();
            frmDashboardScreen.ShowDialog();
        }
        private void label10_Click(object sender, EventArgs e)
        {
            panel14_Click(null, null);
        }


        //For Add User
        private void panel4_Click(object sender, EventArgs e)
        {
            lblTitle.Text = "Add User Screen";
            lblTitle.Visible = true;
            _HideAllGroupBox();
            this.Mode = enMode.AddNew;
            gbAddNewUser.Visible = true;
        }
        private void label4_Click(object sender, EventArgs e)
        {
            panel4_Click(null, null);
        }

        private int _GetPermissions()
        {
            int permissions = 0;

            if (chkClientList.Checked)
                permissions += Convert.ToInt32(chkClientList.Tag);

            if (chkAddClient.Checked)
                permissions += Convert.ToInt32(chkAddClient.Tag);

            if (chkUpdateClient.Checked)
                permissions += Convert.ToInt32(chkUpdateClient.Tag);

            if (chkFindClient.Checked)
                permissions += Convert.ToInt32(chkFindClient.Tag);

            if (chkDeleteClient.Checked)
                permissions += Convert.ToInt32(chkDeleteClient.Tag);

            if (chkUserManage.Checked)
                permissions += Convert.ToInt32(chkUserManage.Tag);

            if (chkTransactions.Checked)
                permissions += Convert.ToInt32(chkTransactions.Tag);

            return permissions;
        }
        private void _LoadDataFromScreenForAddNew()
        {
            clsUsersBusinessLayer User = new clsUsersBusinessLayer();

            User.UserName = txtUsrName.Text;
            User.Password = clsUtility.ComputeHash(txtPassword.Text);
            User.PersonInfo.firstName = txtFirstName.Text;
            User.PersonInfo.midName = txtSecondName.Text;
            User.PersonInfo.lastName = txtLastName.Text;
            User.PersonInfo.phoneNumber = txtPhoneNumber.Text;
            User.PersonInfo.pINCode = txtpinCode.Text;
            User.PersonInfo.accountNumber = clsUtility.GetNewAccountNumber();
            User.PersonInfo.CreatedBy = clsGloablUser.CurrentUser.UserID;
            User.PersonInfo.accountBalance = Convert.ToDecimal(txtpinCode.Text);
            User.Permissions = _GetPermissions();

            if (User.Save())
                MessageBox.Show($"User Added Successfuly with UserID : {User.UserID} and PersonID : {User.PersonInfo.PersonID}", "Done", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
                MessageBox.Show("Something wrong", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        private void _HideAllGroupBox()
        {
            gbFindUser.Visible = false;
            gbAddNewUser.Visible = false;
            gbUpdateUserInfo.Visible = false;
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (this.Mode == enMode.AddNew)
                //this function will load data from screen to data base and save it
                _LoadDataFromScreenForAddNew();
            btnSave.Enabled = false;
        }
        private void txtConfirmPassword_Validating(object sender, CancelEventArgs e)
        {
            btnSave.Enabled = true;
            if (txtConfirmPassword.Text != txtPassword.Text)
            {
                errorProvider1.SetError(txtConfirmPassword, "Password not currect");
                e.Cancel = true;
            }
            else
                e.Cancel = false;
        }



        //For Update
        clsUsersBusinessLayer _UserForUpdaate = new clsUsersBusinessLayer();
        private void _MakeAllButtonInUpdateModeDisable()
        {
            txtUserNameUpdate.Enabled = false; 
            txtNewPassword.Enabled = false;
            txtConfirmPassword.Enabled = false;
            txtOldPassword.Enabled = false;
            chkDeleteClientt.Enabled = false;
            chkFindClientt.Enabled = false;
            chkUpdateClientt.Enabled = false;
            ckhAddClientt.Enabled = false;
            chkClientListt.Enabled = false;
            chkUserManagmentt.Enabled = false;
            chkTransactionss.Enabled = false;
        }
        private int _GetPermissionsForUpdate()
        {
            int permissions = 0;

            if (chkClientListt.Checked)
                permissions += Convert.ToInt32(chkClientList.Tag);

            if (ckhAddClientt.Checked)
                permissions += Convert.ToInt32(chkAddClient.Tag);

            if (chkUpdateClientt.Checked)
                permissions += Convert.ToInt32(chkUpdateClient.Tag);

            if (chkFindClientt.Checked)
                permissions += Convert.ToInt32(chkFindClient.Tag);

            if (chkDeleteClientt.Checked)
                permissions += Convert.ToInt32(chkDeleteClient.Tag);

            if (chkUserManagmentt.Checked)
                permissions += Convert.ToInt32(chkUserManage.Tag);

            if (chkTransactionss.Checked)
                permissions += Convert.ToInt32(chkTransactions.Tag);

            return permissions;
        }
        private void panel5_Click(object sender, EventArgs e)
        {
            lblTitle.Text = "Update User Screen";
            lblTitle.Visible = true;
            _HideAllGroupBox();
            this.Mode = enMode.Update;
            gbUpdateUserInfo.Visible = true;
        }
        private void label5_Click(object sender, EventArgs e)
        {
            panel5_Click(null, null);
        }
        private void _LoadDataFromScreenForUpdate()
        {
            //_UserForUpdaate = clsUsersBusinessLayer.Find(Convert.ToInt32(txtSearchForUser.Text));

            _UserForUpdaate.UserName = txtUserNameUpdate.Text;
            _UserForUpdaate.Password = txtNewPassword.Text;

            _UserForUpdaate.Permissions = _GetPermissionsForUpdate();

            if (_UserForUpdaate.Save())
                MessageBox.Show($"User Updated Successfuly ", "Done", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
                MessageBox.Show("Something wrong", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        private void _FillPermissions()
        {
            if ((_UserForUpdaate.Permissions & 1) == 1)
                chkClientListt.Checked = true;

            if ((_UserForUpdaate.Permissions & 2) == 2)
                ckhAddClientt.Checked = true;

            if ((_UserForUpdaate.Permissions & 8) == 8)
                chkDeleteClientt.Checked = true;

            if ((_UserForUpdaate.Permissions & 4) == 4)
                chkUpdateClientt.Checked = true;


            if ((_UserForUpdaate.Permissions & 16) == 16)
                chkFindClientt.Checked = true;


            if ((_UserForUpdaate.Permissions & 32) == 32)
                chkUserManagmentt.Checked = true;


            if ((_UserForUpdaate.Permissions & 64) == 64)
                chkTransactionss.Checked = true;


        }
        private void btnSearchForUser_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtSearchForUser.Text))
            {
                MessageBox.Show("Fill the user id field", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtSearchForUser.Text = string.Empty;
                return;
            }
            _UserForUpdaate = clsUsersBusinessLayer.Find(Convert.ToInt32(txtSearchForUser.Text));
            if( _UserForUpdaate == null )
            {
                MessageBox.Show($"User with ID: {txtSearchForUser.Text} not found!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtSearchForUser.Text = string.Empty;
                return;
            }
            else
            {
                txtUserNameUpdate.Text = _UserForUpdaate.UserName;
                _FillPermissions();

            }

        }
        private void txtOldPassword_Validating(object sender, CancelEventArgs e)
        {
            if (txtOldPassword.Text != _UserForUpdaate.Password)
            {
                errorProvider1.SetError(txtOldPassword, "Password not currect");
                e.Cancel = true;
            }
            else
                e.Cancel = false;
        }
        private void txtNewPassword_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(txtNewPassword.Text ))
            {
                errorProvider1.SetError(txtNewPassword, "Fiel this field");
                e.Cancel = true;
            }
            else
                e.Cancel = false;
        }
        private void txtConfirmNewPassword_Validating(object sender, CancelEventArgs e)
        {
            if (txtConfirmNewPassword.Text != txtNewPassword.Text)
            {
                errorProvider1.SetError(txtConfirmNewPassword, "Password dosen't mach");
                e.Cancel = true;
            }
            else
            {
                e.Cancel = false;
                btnSaveUpdate.Enabled = true;
            }
        }
        private void btnSaveUpdate_Click(object sender, EventArgs e)
        {
            _LoadDataFromScreenForUpdate();
            btnSaveUpdate.Enabled = false;
        }

        //Find User

        private void _LoadUserDataToScreen(clsUsersBusinessLayer User)
        {
            lblFirstName.Text = User.PersonInfo.firstName;
            lblSecondname.Text = User.PersonInfo.midName;
            lblLastName.Text = User.PersonInfo.lastName;
            lblPhoneNumber.Text = User.PersonInfo.phoneNumber;
            lblUserID.Text = User.UserID.ToString();
            lblUserNamee.Text = User.UserName;
            string PermissionAsText = string.Empty;

            if ((User.Permissions & 2) == 2)
                PermissionAsText += "- Add Client";

            if ((User.Permissions & 1) == 1)
                PermissionAsText += "- Clients List";

            if ((User.Permissions & 8) == 8)
                PermissionAsText += "- Delete Client";


            if ((User.Permissions & 4) == 4)
                PermissionAsText += "- Update Client";

            if ((User.Permissions & 16) == 16)
                PermissionAsText += "- Find Client";

            if ((User.Permissions & 32) == 32)
                PermissionAsText += "- User Management";

            if ((User.Permissions & 64) == 64)
                PermissionAsText += "- Transactions";

            PermissionAsText = PermissionAsText.StartsWith("-") ? PermissionAsText.Substring(1) : PermissionAsText;
            PermissionAsText = PermissionAsText.EndsWith("-") ? PermissionAsText.Substring(0, PermissionAsText.Length - 1) : PermissionAsText;


            lblPermissions.Text = PermissionAsText;
        }

        private void btnFindUser_Click(object sender, EventArgs e)
        {
            clsUsersBusinessLayer UserToFind = new clsUsersBusinessLayer();

            string input = txtForFind.Text; 

            if(string.IsNullOrEmpty(input))
            {
                MessageBox.Show("Enter User Name or User ID", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtForFind.Text = string.Empty;
                return;
            }

            bool allDigits = true;
            bool allLetters = true;

            foreach (char c in input)
            {
                if (!char.IsDigit(c))
                {
                    allDigits = false;
                }

                if (!char.IsLetter(c))
                {
                    allLetters = false;
                }
            }
            if (allLetters)
                 UserToFind = clsUsersBusinessLayer.Find(input);
            if (allDigits)
                UserToFind = clsUsersBusinessLayer.Find(Convert.ToInt32(input));

            if(UserToFind==null)
            {
                string TheInputUserNameOfUserID = (allLetters == true) ? "User Name" : (allDigits == true) ? "UserID" : "UserName or UserID";
                MessageBox.Show($"There is no user with {TheInputUserNameOfUserID} : {input}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }    

            _LoadUserDataToScreen(UserToFind);
        }

        private void panel6_Click(object sender, EventArgs e)
        {
            lblTitle.Text = "Find User Screen";
            lblTitle.Visible = true;
            _HideAllGroupBox();
            gbFindUser.Visible = true;
        }

        private void label6_Click(object sender, EventArgs e)
        {
            panel6_Click(null, null);
        }


        //Show Client List
        private void panel3_Click(object sender, EventArgs e)
        {
            Form frmUsersList = new frmUsersList();
            frmUsersList.ShowDialog();
        } 
        private void label3_Click(object sender, EventArgs e)
        {
            panel3_Click(null, null);
        }

        //Delete User
        private void panel7_Click(object sender, EventArgs e)
        {
            Form frmDeleteUser = new frmDeleteUser();
            frmDeleteUser.ShowDialog();
        }
        private void label7_Click(object sender, EventArgs e)
        {
            panel7_Click(null, null);
        }
    }
}
