﻿using BankBusinessLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bank.Users
{
    public partial class frmDeleteUser : Form
    {
        private int _UserID;
        public frmDeleteUser()
        {
            InitializeComponent();
        }

        private void _CustomInteface()
        {
            btnDelete.BackColor = System.Drawing.ColorTranslator.FromHtml("#748dff");
            btnDelete.Enabled = false;
        }
        private void frmDeleteUser_Load(object sender, EventArgs e)
        {
            _CustomInteface();
        }

        private void ctrlSelectUser1_GetUserID(object sender, int e)
        {
            btnDelete.Enabled = true;
            _UserID = e;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Are you sure you want to delete user with ID: "+_UserID,"Confirm",MessageBoxButtons.YesNoCancel,MessageBoxIcon.Question)== DialogResult.Yes)
            {
                if (clsUsersBusinessLayer.DeleteUser(_UserID))
                    MessageBox.Show("User Deleted Successfuly", "Done", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    MessageBox.Show("Something wrong", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                btnDelete.Enabled = false;
            }
        }
    }
}
