﻿namespace Bank.Users
{
    partial class frmUserMainScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.lblUserName = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.panel13 = new System.Windows.Forms.Panel();
            this.lblTitle = new System.Windows.Forms.Label();
            this.gbAddNewUser = new System.Windows.Forms.GroupBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.chkUserManage = new System.Windows.Forms.CheckBox();
            this.chkAddClient = new System.Windows.Forms.CheckBox();
            this.chkDeleteClient = new System.Windows.Forms.CheckBox();
            this.chkUpdateClient = new System.Windows.Forms.CheckBox();
            this.chkFindClient = new System.Windows.Forms.CheckBox();
            this.chkTransactions = new System.Windows.Forms.CheckBox();
            this.chkClientList = new System.Windows.Forms.CheckBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.txtConfirmPassword = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.txtpinCode = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txtPhoneNumber = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtUsrName = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtSecondName = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.txtAccountBalance = new System.Windows.Forms.TextBox();
            this.gbUpdateUserInfo = new System.Windows.Forms.GroupBox();
            this.btnSearchForUser = new System.Windows.Forms.Button();
            this.label28 = new System.Windows.Forms.Label();
            this.txtSearchForUser = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.txtOldPassword = new System.Windows.Forms.TextBox();
            this.btnSaveUpdate = new System.Windows.Forms.Button();
            this.chkUserManagmentt = new System.Windows.Forms.CheckBox();
            this.ckhAddClientt = new System.Windows.Forms.CheckBox();
            this.chkDeleteClientt = new System.Windows.Forms.CheckBox();
            this.chkUpdateClientt = new System.Windows.Forms.CheckBox();
            this.chkFindClientt = new System.Windows.Forms.CheckBox();
            this.chkTransactionss = new System.Windows.Forms.CheckBox();
            this.chkClientListt = new System.Windows.Forms.CheckBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.txtConfirmNewPassword = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.txtUserNameUpdate = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.txtNewPassword = new System.Windows.Forms.TextBox();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.gbFindUser = new System.Windows.Forms.GroupBox();
            this.label43 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.btnFindUser = new System.Windows.Forms.Button();
            this.label40 = new System.Windows.Forms.Label();
            this.txtForFind = new System.Windows.Forms.TextBox();
            this.lblUserID = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.lblPhoneNumber = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.lblSecondname = new System.Windows.Forms.Label();
            this.lblLastName = new System.Windows.Forms.Label();
            this.lblPermissions = new System.Windows.Forms.Label();
            this.lblUserNamee = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel13.SuspendLayout();
            this.gbAddNewUser.SuspendLayout();
            this.gbUpdateUserInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.gbFindUser.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel15);
            this.panel1.Controls.Add(this.panel14);
            this.panel1.Controls.Add(this.panel12);
            this.panel1.Controls.Add(this.panel11);
            this.panel1.Controls.Add(this.panel9);
            this.panel1.Controls.Add(this.panel7);
            this.panel1.Controls.Add(this.panel6);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.pictureBox4);
            this.panel1.Controls.Add(this.lblUserName);
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(194, 547);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // panel15
            // 
            this.panel15.Location = new System.Drawing.Point(0, 352);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(5, 25);
            this.panel15.TabIndex = 7;
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.Transparent;
            this.panel14.Controls.Add(this.label10);
            this.panel14.Location = new System.Drawing.Point(0, 352);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(194, 25);
            this.panel14.TabIndex = 17;
            this.panel14.Click += new System.EventHandler(this.panel14_Click);
            this.panel14.MouseLeave += new System.EventHandler(this.panel7_MouseLeave);
            this.panel14.MouseHover += new System.EventHandler(this.panel3_MouseHover);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Leelawadee UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label10.Location = new System.Drawing.Point(37, 4);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(73, 17);
            this.label10.TabIndex = 16;
            this.label10.Text = "Dashboard";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // panel12
            // 
            this.panel12.Location = new System.Drawing.Point(0, 303);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(5, 25);
            this.panel12.TabIndex = 6;
            // 
            // panel11
            // 
            this.panel11.Location = new System.Drawing.Point(0, 277);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(5, 25);
            this.panel11.TabIndex = 5;
            // 
            // panel9
            // 
            this.panel9.Location = new System.Drawing.Point(0, 225);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(5, 25);
            this.panel9.TabIndex = 3;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Transparent;
            this.panel7.Controls.Add(this.label7);
            this.panel7.Location = new System.Drawing.Point(0, 303);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(194, 25);
            this.panel7.TabIndex = 6;
            this.panel7.Click += new System.EventHandler(this.panel7_Click);
            this.panel7.MouseLeave += new System.EventHandler(this.panel7_MouseLeave);
            this.panel7.MouseHover += new System.EventHandler(this.panel3_MouseHover);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Leelawadee UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label7.Location = new System.Drawing.Point(37, 4);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(76, 17);
            this.label7.TabIndex = 16;
            this.label7.Text = "Delete User";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Transparent;
            this.panel6.Controls.Add(this.label6);
            this.panel6.Location = new System.Drawing.Point(0, 277);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(194, 25);
            this.panel6.TabIndex = 5;
            this.panel6.Click += new System.EventHandler(this.panel6_Click);
            this.panel6.MouseLeave += new System.EventHandler(this.panel7_MouseLeave);
            this.panel6.MouseHover += new System.EventHandler(this.panel3_MouseHover);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Leelawadee UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label6.Location = new System.Drawing.Point(37, 3);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 17);
            this.label6.TabIndex = 15;
            this.label6.Text = "Find User";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Transparent;
            this.panel5.Controls.Add(this.panel10);
            this.panel5.Controls.Add(this.label5);
            this.panel5.Location = new System.Drawing.Point(0, 251);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(194, 25);
            this.panel5.TabIndex = 4;
            this.panel5.Click += new System.EventHandler(this.panel5_Click);
            this.panel5.MouseLeave += new System.EventHandler(this.panel7_MouseLeave);
            this.panel5.MouseHover += new System.EventHandler(this.panel3_MouseHover);
            // 
            // panel10
            // 
            this.panel10.Location = new System.Drawing.Point(0, 0);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(5, 25);
            this.panel10.TabIndex = 4;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Leelawadee UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label5.Location = new System.Drawing.Point(37, 4);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(82, 17);
            this.label5.TabIndex = 14;
            this.label5.Text = "Update User";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Transparent;
            this.panel4.Controls.Add(this.label4);
            this.panel4.Location = new System.Drawing.Point(0, 225);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(194, 25);
            this.panel4.TabIndex = 3;
            this.panel4.Click += new System.EventHandler(this.panel4_Click);
            this.panel4.MouseLeave += new System.EventHandler(this.panel7_MouseLeave);
            this.panel4.MouseHover += new System.EventHandler(this.panel3_MouseHover);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Leelawadee UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label4.Location = new System.Drawing.Point(37, 5);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 17);
            this.label4.TabIndex = 13;
            this.label4.Text = "Add User";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Transparent;
            this.panel3.Controls.Add(this.panel8);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Location = new System.Drawing.Point(0, 199);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(194, 25);
            this.panel3.TabIndex = 2;
            this.panel3.Click += new System.EventHandler(this.panel3_Click);
            this.panel3.MouseLeave += new System.EventHandler(this.panel7_MouseLeave);
            this.panel3.MouseHover += new System.EventHandler(this.panel3_MouseHover);
            // 
            // panel8
            // 
            this.panel8.Location = new System.Drawing.Point(0, 0);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(5, 25);
            this.panel8.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Leelawadee UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label3.Location = new System.Drawing.Point(37, 4);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(99, 17);
            this.label3.TabIndex = 12;
            this.label3.Text = "Show Users List";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::Bank.Properties.Resources.user__6_;
            this.pictureBox4.Location = new System.Drawing.Point(67, 93);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(60, 60);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 10;
            this.pictureBox4.TabStop = false;
            // 
            // lblUserName
            // 
            this.lblUserName.AutoSize = true;
            this.lblUserName.Font = new System.Drawing.Font("Leelawadee UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserName.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblUserName.Location = new System.Drawing.Point(55, 155);
            this.lblUserName.Name = "lblUserName";
            this.lblUserName.Size = new System.Drawing.Size(84, 21);
            this.lblUserName.TabIndex = 11;
            this.lblUserName.Text = "UserName";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Bank.Properties.Resources.management__3_;
            this.pictureBox3.Location = new System.Drawing.Point(19, 45);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(29, 29);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 9;
            this.pictureBox3.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Leelawadee UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(108, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 21);
            this.label2.TabIndex = 3;
            this.label2.Text = "Users";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Leelawadee UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(48, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 21);
            this.label1.TabIndex = 2;
            this.label1.Text = "Manage";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.pictureBox7);
            this.panel2.Controls.Add(this.pictureBox6);
            this.panel2.Controls.Add(this.pictureBox5);
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(890, 32);
            this.panel2.TabIndex = 1;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::Bank.Properties.Resources.dot__5_;
            this.pictureBox7.Location = new System.Drawing.Point(-5, 0);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(32, 32);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 8;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::Bank.Properties.Resources.dot__6_;
            this.pictureBox6.Location = new System.Drawing.Point(19, 0);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(32, 32);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 7;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::Bank.Properties.Resources.dot__4_;
            this.pictureBox5.Location = new System.Drawing.Point(43, 0);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(32, 32);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 6;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Bank.Properties.Resources.back;
            this.pictureBox2.Location = new System.Drawing.Point(82, 8);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(16, 16);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 3;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.MouseLeave += new System.EventHandler(this.pictureBox2_MouseLeave);
            this.pictureBox2.MouseHover += new System.EventHandler(this.pictureBox2_MouseHover);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Bank.Properties.Resources.close__2_;
            this.pictureBox1.Location = new System.Drawing.Point(863, 7);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(18, 18);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            this.pictureBox1.MouseLeave += new System.EventHandler(this.pictureBox1_MouseLeave);
            this.pictureBox1.MouseHover += new System.EventHandler(this.pictureBox1_MouseHover);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Leelawadee UI", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(372, 147);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(353, 47);
            this.label8.TabIndex = 2;
            this.label8.Text = "Manage Users Screen";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Leelawadee UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(475, 210);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(250, 30);
            this.label9.TabIndex = 3;
            this.label9.Text = "All operations are tracked";
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.lblTitle);
            this.panel13.Location = new System.Drawing.Point(188, 32);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(702, 27);
            this.panel13.TabIndex = 4;
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Leelawadee UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(305, 3);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(49, 21);
            this.lblTitle.TabIndex = 18;
            this.lblTitle.Text = "Users";
            this.lblTitle.Visible = false;
            // 
            // gbAddNewUser
            // 
            this.gbAddNewUser.Controls.Add(this.btnSave);
            this.gbAddNewUser.Controls.Add(this.chkUserManage);
            this.gbAddNewUser.Controls.Add(this.chkAddClient);
            this.gbAddNewUser.Controls.Add(this.chkDeleteClient);
            this.gbAddNewUser.Controls.Add(this.chkUpdateClient);
            this.gbAddNewUser.Controls.Add(this.chkFindClient);
            this.gbAddNewUser.Controls.Add(this.chkTransactions);
            this.gbAddNewUser.Controls.Add(this.chkClientList);
            this.gbAddNewUser.Controls.Add(this.label22);
            this.gbAddNewUser.Controls.Add(this.label21);
            this.gbAddNewUser.Controls.Add(this.txtConfirmPassword);
            this.gbAddNewUser.Controls.Add(this.label20);
            this.gbAddNewUser.Controls.Add(this.label19);
            this.gbAddNewUser.Controls.Add(this.label18);
            this.gbAddNewUser.Controls.Add(this.txtpinCode);
            this.gbAddNewUser.Controls.Add(this.label17);
            this.gbAddNewUser.Controls.Add(this.txtPhoneNumber);
            this.gbAddNewUser.Controls.Add(this.label16);
            this.gbAddNewUser.Controls.Add(this.txtUsrName);
            this.gbAddNewUser.Controls.Add(this.label15);
            this.gbAddNewUser.Controls.Add(this.txtLastName);
            this.gbAddNewUser.Controls.Add(this.label14);
            this.gbAddNewUser.Controls.Add(this.txtFirstName);
            this.gbAddNewUser.Controls.Add(this.label12);
            this.gbAddNewUser.Controls.Add(this.txtSecondName);
            this.gbAddNewUser.Controls.Add(this.label13);
            this.gbAddNewUser.Controls.Add(this.label11);
            this.gbAddNewUser.Controls.Add(this.txtPassword);
            this.gbAddNewUser.Controls.Add(this.txtAccountBalance);
            this.gbAddNewUser.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.gbAddNewUser.Location = new System.Drawing.Point(279, 65);
            this.gbAddNewUser.Name = "gbAddNewUser";
            this.gbAddNewUser.Size = new System.Drawing.Size(533, 470);
            this.gbAddNewUser.TabIndex = 5;
            this.gbAddNewUser.TabStop = false;
            this.gbAddNewUser.Visible = false;
            // 
            // btnSave
            // 
            this.btnSave.Enabled = false;
            this.btnSave.Location = new System.Drawing.Point(454, 443);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 17;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // chkUserManage
            // 
            this.chkUserManage.AutoSize = true;
            this.chkUserManage.Font = new System.Drawing.Font("Leelawadee UI", 8.25F);
            this.chkUserManage.Location = new System.Drawing.Point(311, 408);
            this.chkUserManage.Name = "chkUserManage";
            this.chkUserManage.Size = new System.Drawing.Size(113, 17);
            this.chkUserManage.TabIndex = 15;
            this.chkUserManage.Tag = "32";
            this.chkUserManage.Text = "User managment";
            this.chkUserManage.UseVisualStyleBackColor = true;
            // 
            // chkAddClient
            // 
            this.chkAddClient.AutoSize = true;
            this.chkAddClient.Font = new System.Drawing.Font("Leelawadee UI", 8.25F);
            this.chkAddClient.Location = new System.Drawing.Point(206, 385);
            this.chkAddClient.Name = "chkAddClient";
            this.chkAddClient.Size = new System.Drawing.Size(80, 17);
            this.chkAddClient.TabIndex = 11;
            this.chkAddClient.Tag = "2";
            this.chkAddClient.Text = "Add Client";
            this.chkAddClient.UseVisualStyleBackColor = true;
            // 
            // chkDeleteClient
            // 
            this.chkDeleteClient.AutoSize = true;
            this.chkDeleteClient.Font = new System.Drawing.Font("Leelawadee UI", 8.25F);
            this.chkDeleteClient.Location = new System.Drawing.Point(311, 385);
            this.chkDeleteClient.Name = "chkDeleteClient";
            this.chkDeleteClient.Size = new System.Drawing.Size(92, 17);
            this.chkDeleteClient.TabIndex = 12;
            this.chkDeleteClient.Tag = "8";
            this.chkDeleteClient.Text = "Delete Client";
            this.chkDeleteClient.UseVisualStyleBackColor = true;
            // 
            // chkUpdateClient
            // 
            this.chkUpdateClient.AutoSize = true;
            this.chkUpdateClient.Font = new System.Drawing.Font("Leelawadee UI", 8.25F);
            this.chkUpdateClient.Location = new System.Drawing.Point(105, 408);
            this.chkUpdateClient.Name = "chkUpdateClient";
            this.chkUpdateClient.Size = new System.Drawing.Size(97, 17);
            this.chkUpdateClient.TabIndex = 13;
            this.chkUpdateClient.Tag = "4";
            this.chkUpdateClient.Text = "Update Client";
            this.chkUpdateClient.UseVisualStyleBackColor = true;
            // 
            // chkFindClient
            // 
            this.chkFindClient.AutoSize = true;
            this.chkFindClient.Font = new System.Drawing.Font("Leelawadee UI", 8.25F);
            this.chkFindClient.Location = new System.Drawing.Point(206, 408);
            this.chkFindClient.Name = "chkFindClient";
            this.chkFindClient.Size = new System.Drawing.Size(82, 17);
            this.chkFindClient.TabIndex = 14;
            this.chkFindClient.Tag = "16";
            this.chkFindClient.Text = "Find Client";
            this.chkFindClient.UseVisualStyleBackColor = true;
            // 
            // chkTransactions
            // 
            this.chkTransactions.AutoSize = true;
            this.chkTransactions.Font = new System.Drawing.Font("Leelawadee UI", 8.25F);
            this.chkTransactions.Location = new System.Drawing.Point(105, 434);
            this.chkTransactions.Name = "chkTransactions";
            this.chkTransactions.Size = new System.Drawing.Size(90, 17);
            this.chkTransactions.TabIndex = 16;
            this.chkTransactions.Tag = "64";
            this.chkTransactions.Text = "Transactions";
            this.chkTransactions.UseVisualStyleBackColor = true;
            // 
            // chkClientList
            // 
            this.chkClientList.AutoSize = true;
            this.chkClientList.Font = new System.Drawing.Font("Leelawadee UI", 8.25F);
            this.chkClientList.Location = new System.Drawing.Point(105, 385);
            this.chkClientList.Name = "chkClientList";
            this.chkClientList.Size = new System.Drawing.Size(76, 17);
            this.chkClientList.TabIndex = 10;
            this.chkClientList.Tag = "1";
            this.chkClientList.Text = "Client List";
            this.chkClientList.UseVisualStyleBackColor = true;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Leelawadee UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(27, 365);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(72, 13);
            this.label22.TabIndex = 22;
            this.label22.Text = "Permissions:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Leelawadee UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(27, 331);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(51, 13);
            this.label21.TabIndex = 21;
            this.label21.Text = "Confirm:";
            // 
            // txtConfirmPassword
            // 
            this.txtConfirmPassword.Location = new System.Drawing.Point(125, 328);
            this.txtConfirmPassword.Name = "txtConfirmPassword";
            this.txtConfirmPassword.PasswordChar = '*';
            this.txtConfirmPassword.Size = new System.Drawing.Size(380, 20);
            this.txtConfirmPassword.TabIndex = 9;
            this.txtConfirmPassword.Validating += new System.ComponentModel.CancelEventHandler(this.txtConfirmPassword_Validating);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Leelawadee UI", 6.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(30, 278);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(262, 12);
            this.label20.TabIndex = 19;
            this.label20.Text = "*Enter a password contain four digits make it simple to remember";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Leelawadee UI", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(32, 12);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(238, 15);
            this.label19.TabIndex = 18;
            this.label19.Text = "*Befor beeing User you must be a client first";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Leelawadee UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(29, 168);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(53, 13);
            this.label18.TabIndex = 17;
            this.label18.Text = "PinCode:";
            // 
            // txtpinCode
            // 
            this.txtpinCode.Location = new System.Drawing.Point(127, 165);
            this.txtpinCode.Name = "txtpinCode";
            this.txtpinCode.PasswordChar = '*';
            this.txtpinCode.Size = new System.Drawing.Size(380, 20);
            this.txtpinCode.TabIndex = 5;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Leelawadee UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(29, 137);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(87, 13);
            this.label17.TabIndex = 15;
            this.label17.Text = "Phone Number:";
            // 
            // txtPhoneNumber
            // 
            this.txtPhoneNumber.Location = new System.Drawing.Point(127, 134);
            this.txtPhoneNumber.Name = "txtPhoneNumber";
            this.txtPhoneNumber.Size = new System.Drawing.Size(380, 20);
            this.txtPhoneNumber.TabIndex = 4;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Leelawadee UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(29, 249);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(65, 13);
            this.label16.TabIndex = 13;
            this.label16.Text = "User Name:";
            // 
            // txtUsrName
            // 
            this.txtUsrName.Location = new System.Drawing.Point(127, 246);
            this.txtUsrName.Name = "txtUsrName";
            this.txtUsrName.Size = new System.Drawing.Size(380, 20);
            this.txtUsrName.TabIndex = 7;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Leelawadee UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(29, 106);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(62, 13);
            this.label15.TabIndex = 11;
            this.label15.Text = "Last Name:";
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(127, 103);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(380, 20);
            this.txtLastName.TabIndex = 3;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Leelawadee UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(29, 44);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(64, 13);
            this.label14.TabIndex = 9;
            this.label14.Text = "First Name:";
            // 
            // txtFirstName
            // 
            this.txtFirstName.Location = new System.Drawing.Point(127, 41);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(380, 20);
            this.txtFirstName.TabIndex = 1;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Leelawadee UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(29, 75);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(80, 13);
            this.label12.TabIndex = 7;
            this.label12.Text = "Second Name:";
            // 
            // txtSecondName
            // 
            this.txtSecondName.Location = new System.Drawing.Point(127, 72);
            this.txtSecondName.Name = "txtSecondName";
            this.txtSecondName.Size = new System.Drawing.Size(380, 20);
            this.txtSecondName.TabIndex = 2;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Leelawadee UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(29, 301);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(59, 13);
            this.label13.TabIndex = 5;
            this.label13.Text = "Password:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Leelawadee UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(29, 199);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(95, 13);
            this.label11.TabIndex = 3;
            this.label11.Text = "Account Balance:";
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(127, 298);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.Size = new System.Drawing.Size(380, 20);
            this.txtPassword.TabIndex = 8;
            // 
            // txtAccountBalance
            // 
            this.txtAccountBalance.Location = new System.Drawing.Point(127, 196);
            this.txtAccountBalance.Name = "txtAccountBalance";
            this.txtAccountBalance.Size = new System.Drawing.Size(380, 20);
            this.txtAccountBalance.TabIndex = 6;
            // 
            // gbUpdateUserInfo
            // 
            this.gbUpdateUserInfo.Controls.Add(this.btnSearchForUser);
            this.gbUpdateUserInfo.Controls.Add(this.label28);
            this.gbUpdateUserInfo.Controls.Add(this.txtSearchForUser);
            this.gbUpdateUserInfo.Controls.Add(this.label27);
            this.gbUpdateUserInfo.Controls.Add(this.label26);
            this.gbUpdateUserInfo.Controls.Add(this.txtOldPassword);
            this.gbUpdateUserInfo.Controls.Add(this.btnSaveUpdate);
            this.gbUpdateUserInfo.Controls.Add(this.chkUserManagmentt);
            this.gbUpdateUserInfo.Controls.Add(this.ckhAddClientt);
            this.gbUpdateUserInfo.Controls.Add(this.chkDeleteClientt);
            this.gbUpdateUserInfo.Controls.Add(this.chkUpdateClientt);
            this.gbUpdateUserInfo.Controls.Add(this.chkFindClientt);
            this.gbUpdateUserInfo.Controls.Add(this.chkTransactionss);
            this.gbUpdateUserInfo.Controls.Add(this.chkClientListt);
            this.gbUpdateUserInfo.Controls.Add(this.label23);
            this.gbUpdateUserInfo.Controls.Add(this.label24);
            this.gbUpdateUserInfo.Controls.Add(this.txtConfirmNewPassword);
            this.gbUpdateUserInfo.Controls.Add(this.label25);
            this.gbUpdateUserInfo.Controls.Add(this.label29);
            this.gbUpdateUserInfo.Controls.Add(this.txtUserNameUpdate);
            this.gbUpdateUserInfo.Controls.Add(this.label33);
            this.gbUpdateUserInfo.Controls.Add(this.txtNewPassword);
            this.gbUpdateUserInfo.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.gbUpdateUserInfo.Location = new System.Drawing.Point(241, 60);
            this.gbUpdateUserInfo.Name = "gbUpdateUserInfo";
            this.gbUpdateUserInfo.Size = new System.Drawing.Size(665, 475);
            this.gbUpdateUserInfo.TabIndex = 23;
            this.gbUpdateUserInfo.TabStop = false;
            this.gbUpdateUserInfo.Visible = false;
            // 
            // btnSearchForUser
            // 
            this.btnSearchForUser.Image = global::Bank.Properties.Resources.search__3_;
            this.btnSearchForUser.Location = new System.Drawing.Point(380, 17);
            this.btnSearchForUser.Name = "btnSearchForUser";
            this.btnSearchForUser.Size = new System.Drawing.Size(25, 25);
            this.btnSearchForUser.TabIndex = 28;
            this.btnSearchForUser.UseVisualStyleBackColor = true;
            this.btnSearchForUser.Click += new System.EventHandler(this.btnSearchForUser_Click);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Leelawadee UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(53, 22);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(135, 13);
            this.label28.TabIndex = 27;
            this.label28.Text = "Enter UserID For Update:";
            // 
            // txtSearchForUser
            // 
            this.txtSearchForUser.Location = new System.Drawing.Point(193, 19);
            this.txtSearchForUser.Name = "txtSearchForUser";
            this.txtSearchForUser.Size = new System.Drawing.Size(181, 20);
            this.txtSearchForUser.TabIndex = 26;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Leelawadee UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(27, 129);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(103, 13);
            this.label27.TabIndex = 25;
            this.label27.Text = "Change Password:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Leelawadee UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(27, 166);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(81, 13);
            this.label26.TabIndex = 23;
            this.label26.Text = "Old Password:";
            // 
            // txtOldPassword
            // 
            this.txtOldPassword.Location = new System.Drawing.Point(125, 162);
            this.txtOldPassword.Name = "txtOldPassword";
            this.txtOldPassword.PasswordChar = '*';
            this.txtOldPassword.Size = new System.Drawing.Size(380, 20);
            this.txtOldPassword.TabIndex = 24;
            this.txtOldPassword.Validating += new System.ComponentModel.CancelEventHandler(this.txtOldPassword_Validating);
            // 
            // btnSaveUpdate
            // 
            this.btnSaveUpdate.Location = new System.Drawing.Point(454, 422);
            this.btnSaveUpdate.Name = "btnSaveUpdate";
            this.btnSaveUpdate.Size = new System.Drawing.Size(75, 23);
            this.btnSaveUpdate.TabIndex = 17;
            this.btnSaveUpdate.Text = "Save";
            this.btnSaveUpdate.UseVisualStyleBackColor = true;
            this.btnSaveUpdate.Click += new System.EventHandler(this.btnSaveUpdate_Click);
            // 
            // chkUserManagmentt
            // 
            this.chkUserManagmentt.AutoSize = true;
            this.chkUserManagmentt.Font = new System.Drawing.Font("Leelawadee UI", 8.25F);
            this.chkUserManagmentt.Location = new System.Drawing.Point(311, 368);
            this.chkUserManagmentt.Name = "chkUserManagmentt";
            this.chkUserManagmentt.Size = new System.Drawing.Size(113, 17);
            this.chkUserManagmentt.TabIndex = 15;
            this.chkUserManagmentt.Tag = "32";
            this.chkUserManagmentt.Text = "User managment";
            this.chkUserManagmentt.UseVisualStyleBackColor = true;
            // 
            // ckhAddClientt
            // 
            this.ckhAddClientt.AutoSize = true;
            this.ckhAddClientt.Font = new System.Drawing.Font("Leelawadee UI", 8.25F);
            this.ckhAddClientt.Location = new System.Drawing.Point(206, 345);
            this.ckhAddClientt.Name = "ckhAddClientt";
            this.ckhAddClientt.Size = new System.Drawing.Size(80, 17);
            this.ckhAddClientt.TabIndex = 11;
            this.ckhAddClientt.Tag = "2";
            this.ckhAddClientt.Text = "Add Client";
            this.ckhAddClientt.UseVisualStyleBackColor = true;
            // 
            // chkDeleteClientt
            // 
            this.chkDeleteClientt.AutoSize = true;
            this.chkDeleteClientt.Font = new System.Drawing.Font("Leelawadee UI", 8.25F);
            this.chkDeleteClientt.Location = new System.Drawing.Point(311, 345);
            this.chkDeleteClientt.Name = "chkDeleteClientt";
            this.chkDeleteClientt.Size = new System.Drawing.Size(92, 17);
            this.chkDeleteClientt.TabIndex = 12;
            this.chkDeleteClientt.Tag = "8";
            this.chkDeleteClientt.Text = "Delete Client";
            this.chkDeleteClientt.UseVisualStyleBackColor = true;
            // 
            // chkUpdateClientt
            // 
            this.chkUpdateClientt.AutoSize = true;
            this.chkUpdateClientt.Font = new System.Drawing.Font("Leelawadee UI", 8.25F);
            this.chkUpdateClientt.Location = new System.Drawing.Point(105, 368);
            this.chkUpdateClientt.Name = "chkUpdateClientt";
            this.chkUpdateClientt.Size = new System.Drawing.Size(97, 17);
            this.chkUpdateClientt.TabIndex = 13;
            this.chkUpdateClientt.Tag = "4";
            this.chkUpdateClientt.Text = "Update Client";
            this.chkUpdateClientt.UseVisualStyleBackColor = true;
            // 
            // chkFindClientt
            // 
            this.chkFindClientt.AutoSize = true;
            this.chkFindClientt.Font = new System.Drawing.Font("Leelawadee UI", 8.25F);
            this.chkFindClientt.Location = new System.Drawing.Point(206, 368);
            this.chkFindClientt.Name = "chkFindClientt";
            this.chkFindClientt.Size = new System.Drawing.Size(82, 17);
            this.chkFindClientt.TabIndex = 14;
            this.chkFindClientt.Tag = "16";
            this.chkFindClientt.Text = "Find Client";
            this.chkFindClientt.UseVisualStyleBackColor = true;
            // 
            // chkTransactionss
            // 
            this.chkTransactionss.AutoSize = true;
            this.chkTransactionss.Font = new System.Drawing.Font("Leelawadee UI", 8.25F);
            this.chkTransactionss.Location = new System.Drawing.Point(105, 394);
            this.chkTransactionss.Name = "chkTransactionss";
            this.chkTransactionss.Size = new System.Drawing.Size(90, 17);
            this.chkTransactionss.TabIndex = 16;
            this.chkTransactionss.Tag = "64";
            this.chkTransactionss.Text = "Transactions";
            this.chkTransactionss.UseVisualStyleBackColor = true;
            // 
            // chkClientListt
            // 
            this.chkClientListt.AutoSize = true;
            this.chkClientListt.Font = new System.Drawing.Font("Leelawadee UI", 8.25F);
            this.chkClientListt.Location = new System.Drawing.Point(105, 345);
            this.chkClientListt.Name = "chkClientListt";
            this.chkClientListt.Size = new System.Drawing.Size(76, 17);
            this.chkClientListt.TabIndex = 10;
            this.chkClientListt.Tag = "1";
            this.chkClientListt.Text = "Client List";
            this.chkClientListt.UseVisualStyleBackColor = true;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Leelawadee UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(27, 325);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(72, 13);
            this.label23.TabIndex = 22;
            this.label23.Text = "Permissions:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Leelawadee UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(27, 269);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(51, 13);
            this.label24.TabIndex = 21;
            this.label24.Text = "Confirm:";
            // 
            // txtConfirmNewPassword
            // 
            this.txtConfirmNewPassword.Location = new System.Drawing.Point(125, 265);
            this.txtConfirmNewPassword.Name = "txtConfirmNewPassword";
            this.txtConfirmNewPassword.PasswordChar = '*';
            this.txtConfirmNewPassword.Size = new System.Drawing.Size(380, 20);
            this.txtConfirmNewPassword.TabIndex = 9;
            this.txtConfirmNewPassword.Validating += new System.ComponentModel.CancelEventHandler(this.txtConfirmNewPassword_Validating);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Leelawadee UI", 6.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(30, 211);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(262, 12);
            this.label25.TabIndex = 19;
            this.label25.Text = "*Enter a password contain four digits make it simple to remember";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Leelawadee UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(29, 79);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(65, 13);
            this.label29.TabIndex = 13;
            this.label29.Text = "User Name:";
            // 
            // txtUserNameUpdate
            // 
            this.txtUserNameUpdate.Location = new System.Drawing.Point(127, 76);
            this.txtUserNameUpdate.Name = "txtUserNameUpdate";
            this.txtUserNameUpdate.Size = new System.Drawing.Size(380, 20);
            this.txtUserNameUpdate.TabIndex = 7;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Leelawadee UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(27, 236);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(85, 13);
            this.label33.TabIndex = 5;
            this.label33.Text = "New Password:";
            // 
            // txtNewPassword
            // 
            this.txtNewPassword.Location = new System.Drawing.Point(125, 232);
            this.txtNewPassword.Name = "txtNewPassword";
            this.txtNewPassword.PasswordChar = '*';
            this.txtNewPassword.Size = new System.Drawing.Size(380, 20);
            this.txtNewPassword.TabIndex = 8;
            this.txtNewPassword.Validating += new System.ComponentModel.CancelEventHandler(this.txtNewPassword_Validating);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // gbFindUser
            // 
            this.gbFindUser.Controls.Add(this.label43);
            this.gbFindUser.Controls.Add(this.label42);
            this.gbFindUser.Controls.Add(this.label41);
            this.gbFindUser.Controls.Add(this.btnFindUser);
            this.gbFindUser.Controls.Add(this.label40);
            this.gbFindUser.Controls.Add(this.txtForFind);
            this.gbFindUser.Controls.Add(this.lblUserID);
            this.gbFindUser.Controls.Add(this.label39);
            this.gbFindUser.Controls.Add(this.lblPhoneNumber);
            this.gbFindUser.Controls.Add(this.label32);
            this.gbFindUser.Controls.Add(this.lblFirstName);
            this.gbFindUser.Controls.Add(this.lblSecondname);
            this.gbFindUser.Controls.Add(this.lblLastName);
            this.gbFindUser.Controls.Add(this.lblPermissions);
            this.gbFindUser.Controls.Add(this.lblUserNamee);
            this.gbFindUser.Controls.Add(this.label38);
            this.gbFindUser.Controls.Add(this.label37);
            this.gbFindUser.Controls.Add(this.label36);
            this.gbFindUser.Controls.Add(this.label35);
            this.gbFindUser.Controls.Add(this.label30);
            this.gbFindUser.Controls.Add(this.label31);
            this.gbFindUser.Controls.Add(this.label34);
            this.gbFindUser.Controls.Add(this.label44);
            this.gbFindUser.Location = new System.Drawing.Point(214, 65);
            this.gbFindUser.Name = "gbFindUser";
            this.gbFindUser.Size = new System.Drawing.Size(834, 451);
            this.gbFindUser.TabIndex = 0;
            this.gbFindUser.TabStop = false;
            this.gbFindUser.Visible = false;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Leelawadee UI", 6.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(6, 14);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(217, 12);
            this.label43.TabIndex = 34;
            this.label43.Text = "*This page for read only you can\'t modify any info here";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Liberation Sans", 9F, System.Drawing.FontStyle.Bold);
            this.label42.Location = new System.Drawing.Point(166, 286);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(75, 14);
            this.label42.TabIndex = 33;
            this.label42.Text = "Person Info:";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Liberation Sans", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(161, 125);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(61, 14);
            this.label41.TabIndex = 32;
            this.label41.Text = "User Info:";
            // 
            // btnFindUser
            // 
            this.btnFindUser.Image = global::Bank.Properties.Resources.search__3_;
            this.btnFindUser.Location = new System.Drawing.Point(414, 81);
            this.btnFindUser.Name = "btnFindUser";
            this.btnFindUser.Size = new System.Drawing.Size(25, 25);
            this.btnFindUser.TabIndex = 31;
            this.btnFindUser.UseVisualStyleBackColor = true;
            this.btnFindUser.Click += new System.EventHandler(this.btnFindUser_Click);
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Leelawadee UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(167, 60);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(143, 13);
            this.label40.TabIndex = 30;
            this.label40.Text = "Enter UserName of UserID:";
            // 
            // txtForFind
            // 
            this.txtForFind.Location = new System.Drawing.Point(219, 83);
            this.txtForFind.Name = "txtForFind";
            this.txtForFind.Size = new System.Drawing.Size(181, 20);
            this.txtForFind.TabIndex = 29;
            // 
            // lblUserID
            // 
            this.lblUserID.AutoSize = true;
            this.lblUserID.Font = new System.Drawing.Font("Leelawadee UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserID.Location = new System.Drawing.Point(309, 155);
            this.lblUserID.Name = "lblUserID";
            this.lblUserID.Size = new System.Drawing.Size(28, 13);
            this.lblUserID.TabIndex = 16;
            this.lblUserID.Text = "[???]";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Leelawadee UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(235, 155);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(47, 15);
            this.label39.TabIndex = 15;
            this.label39.Text = "User ID:";
            // 
            // lblPhoneNumber
            // 
            this.lblPhoneNumber.AutoSize = true;
            this.lblPhoneNumber.Font = new System.Drawing.Font("Leelawadee UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhoneNumber.Location = new System.Drawing.Point(302, 398);
            this.lblPhoneNumber.Name = "lblPhoneNumber";
            this.lblPhoneNumber.Size = new System.Drawing.Size(28, 13);
            this.lblPhoneNumber.TabIndex = 14;
            this.lblPhoneNumber.Text = "[???]";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Leelawadee UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(212, 398);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(91, 15);
            this.label32.TabIndex = 13;
            this.label32.Text = "Phone Number:";
            // 
            // lblFirstName
            // 
            this.lblFirstName.AutoSize = true;
            this.lblFirstName.Font = new System.Drawing.Font("Leelawadee UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFirstName.Location = new System.Drawing.Point(302, 314);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(28, 13);
            this.lblFirstName.TabIndex = 12;
            this.lblFirstName.Text = "[???]";
            // 
            // lblSecondname
            // 
            this.lblSecondname.AutoSize = true;
            this.lblSecondname.Font = new System.Drawing.Font("Leelawadee UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecondname.Location = new System.Drawing.Point(302, 342);
            this.lblSecondname.Name = "lblSecondname";
            this.lblSecondname.Size = new System.Drawing.Size(28, 13);
            this.lblSecondname.TabIndex = 11;
            this.lblSecondname.Text = "[???]";
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.Font = new System.Drawing.Font("Leelawadee UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLastName.Location = new System.Drawing.Point(302, 370);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(28, 13);
            this.lblLastName.TabIndex = 10;
            this.lblLastName.Text = "[???]";
            // 
            // lblPermissions
            // 
            this.lblPermissions.AllowDrop = true;
            this.lblPermissions.AutoEllipsis = true;
            this.lblPermissions.AutoSize = true;
            this.lblPermissions.Font = new System.Drawing.Font("Leelawadee UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPermissions.Location = new System.Drawing.Point(309, 203);
            this.lblPermissions.MaximumSize = new System.Drawing.Size(200, 0);
            this.lblPermissions.Name = "lblPermissions";
            this.lblPermissions.Size = new System.Drawing.Size(28, 13);
            this.lblPermissions.TabIndex = 9;
            this.lblPermissions.Text = "[???]";
            // 
            // lblUserNamee
            // 
            this.lblUserNamee.AutoSize = true;
            this.lblUserNamee.Font = new System.Drawing.Font("Leelawadee UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserNamee.Location = new System.Drawing.Point(309, 179);
            this.lblUserNamee.Name = "lblUserNamee";
            this.lblUserNamee.Size = new System.Drawing.Size(28, 13);
            this.lblUserNamee.TabIndex = 8;
            this.lblUserNamee.Text = "[???]";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Leelawadee UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(212, 314);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(67, 15);
            this.label38.TabIndex = 7;
            this.label38.Text = "First Name:";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Leelawadee UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(212, 342);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(84, 15);
            this.label37.TabIndex = 6;
            this.label37.Text = "Second Name:";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Leelawadee UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(212, 370);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(66, 15);
            this.label36.TabIndex = 5;
            this.label36.Text = "Last Name:";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Leelawadee UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(235, 203);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(73, 15);
            this.label35.TabIndex = 4;
            this.label35.Text = "Permissions:";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Leelawadee UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(235, 179);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(68, 15);
            this.label30.TabIndex = 0;
            this.label30.Text = "User Name:";
            // 
            // label31
            // 
            this.label31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label31.Location = new System.Drawing.Point(158, 128);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(368, 148);
            this.label31.TabIndex = 35;
            // 
            // label34
            // 
            this.label34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label34.Location = new System.Drawing.Point(157, 289);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(368, 133);
            this.label34.TabIndex = 36;
            // 
            // label44
            // 
            this.label44.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label44.Location = new System.Drawing.Point(158, 64);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(368, 55);
            this.label44.TabIndex = 37;
            // 
            // frmUserMainScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(890, 547);
            this.Controls.Add(this.gbFindUser);
            this.Controls.Add(this.gbUpdateUserInfo);
            this.Controls.Add(this.gbAddNewUser);
            this.Controls.Add(this.panel13);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmUserMainScreen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmUserMainScreen";
            this.Load += new System.EventHandler(this.frmUserMainScreen_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.frmUserMainScreen_Paint);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.gbAddNewUser.ResumeLayout(false);
            this.gbAddNewUser.PerformLayout();
            this.gbUpdateUserInfo.ResumeLayout(false);
            this.gbUpdateUserInfo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.gbFindUser.ResumeLayout(false);
            this.gbFindUser.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label lblUserName;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.GroupBox gbAddNewUser;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.TextBox txtAccountBalance;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtpinCode;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtPhoneNumber;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtUsrName;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtSecondName;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.CheckBox chkAddClient;
        private System.Windows.Forms.CheckBox chkDeleteClient;
        private System.Windows.Forms.CheckBox chkUpdateClient;
        private System.Windows.Forms.CheckBox chkFindClient;
        private System.Windows.Forms.CheckBox chkTransactions;
        private System.Windows.Forms.CheckBox chkClientList;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txtConfirmPassword;
        private System.Windows.Forms.CheckBox chkUserManage;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.GroupBox gbUpdateUserInfo;
        private System.Windows.Forms.Button btnSaveUpdate;
        private System.Windows.Forms.CheckBox chkUserManagmentt;
        private System.Windows.Forms.CheckBox ckhAddClientt;
        private System.Windows.Forms.CheckBox chkDeleteClientt;
        private System.Windows.Forms.CheckBox chkUpdateClientt;
        private System.Windows.Forms.CheckBox chkFindClientt;
        private System.Windows.Forms.CheckBox chkTransactionss;
        private System.Windows.Forms.CheckBox chkClientListt;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txtConfirmNewPassword;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox txtUserNameUpdate;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox txtNewPassword;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox txtOldPassword;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txtSearchForUser;
        private System.Windows.Forms.Button btnSearchForUser;
        private System.Windows.Forms.GroupBox gbFindUser;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label lblPhoneNumber;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.Label lblSecondname;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.Label lblPermissions;
        private System.Windows.Forms.Label lblUserNamee;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Button btnFindUser;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox txtForFind;
        private System.Windows.Forms.Label lblUserID;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label lblTitle;
    }
}