﻿using BankBusinessLayer;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace Bank.Users
{
    public partial class frmDashboardScreen : Form
    {
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn(
           int nLeftRect, int nTopRect, int nRightRect, int nBottomRect,
           int nWidthEllipse, int nHeightEllipse
       );
        //#d5eafe : Background

        public frmDashboardScreen()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.None;
            Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, 20, 20));
        }

        private SortedDictionary<int, int> _ManipulateActiveUser()
        {
            DataTable Activation = clsUsersBusinessLayer.GetUsersActive();
            HashSet<int> UsersID = new HashSet<int>();

            foreach(DataRow r in Activation.Rows)
            {
                //To get unique ID
                UsersID.Add(Convert.ToInt32(r["UserID"]));
            }

            Stack<int> stkUserID = new Stack<int>(UsersID);

            SortedDictionary<int, int> UsersAndActive = new SortedDictionary<int, int>();
            
            while(stkUserID.Count > 0 )
            {
                UsersAndActive.Add(Convert.ToInt32(Activation.Compute("SUM(Active)", $"UserID='{stkUserID.Peek()}'")), Convert.ToInt32(stkUserID.Peek()));
                stkUserID.Pop();
            }


            return UsersAndActive;
        }

        private void _FullChartBar()
        {
            //_ManipulateActiveUser() will return Dictionary order ACE by value
            SortedDictionary<int, int> UsesWithActivation = _ManipulateActiveUser();

            if (UsesWithActivation.Count > 0)
            {
                gpbMax.Value = (UsesWithActivation.Select(n => n.Key).Last());
                lblFirst.Text = clsUsersBusinessLayer.Find(UsesWithActivation.Select(n => n.Value).Last()).UserName;
                UsesWithActivation.Remove(UsesWithActivation.Last().Key);
                lblHiliestPerformance.Text = lblFirst.Text;
            }
            else
            {
                gpbMax.Value = 0;
                lblFirst.Text = "NoUser";
            }



            if (UsesWithActivation.Count > 0)
            {

                gpbLess1.Value = (UsesWithActivation.Select(n => n.Key).Last());
                lblSecond.Text = clsUsersBusinessLayer.Find(UsesWithActivation.Select(n => n.Value).Last()).UserName;
                UsesWithActivation.Remove(UsesWithActivation.Last().Key);
            }
            else
            {
                gpbLess1.Value = 0;
                lblSecond.Text = "NoUser";
            }

            if (UsesWithActivation.Count > 0)
            {

                gpbLess2.Value = (UsesWithActivation.Select(n => n.Key).Last());
                lblThird.Text = clsUsersBusinessLayer.Find(UsesWithActivation.Select(n => n.Value).Last()).UserName;
                UsesWithActivation.Remove(UsesWithActivation.Last().Key);
            }
            else
            {
                gpbLess2.Value = 0;
                lblThird.Text = "NoUser";
            }

            if (UsesWithActivation.Count > 0)
            {

                gpbLess3.Value = (UsesWithActivation.Select(n => n.Key).Last());
                lblFourth.Text = clsUsersBusinessLayer.Find(UsesWithActivation.Select(n => n.Value).Last()).UserName;
                UsesWithActivation.Remove(UsesWithActivation.Last().Key);
            }
            else
            {
                gpbLess3.Value = 0;
                lblFourth.Text = "NoUser";
            }

            if (UsesWithActivation.Count > 0)
            {

                gpbLess4.Value = (UsesWithActivation.Select(n => n.Key).Last());
                lblFifth.Text = clsUsersBusinessLayer.Find(UsesWithActivation.Select(n => n.Value).Last()).UserName;
                UsesWithActivation.Remove(UsesWithActivation.Last().Key);
            }
            else
            {
                gpbLess4.Value = 0;
                lblFifth.Text = "NoUser";
            }

            if (UsesWithActivation.Count > 0)
            {

                gpbMin.Value = (UsesWithActivation.Select(n => n.Key).Last());
                lblSixth.Text = clsUsersBusinessLayer.Find(UsesWithActivation.Select(n => n.Value).Last()).UserName;
            }
            else
            {
                gpbMin.Value = 0;
                lblSixth.Text = "NoUser";
            }
        }

        private void _FullDataGredViewWithUsers()
        {
            DataTable UserInfo = clsUsersBusinessLayer.GetAllUsers();

            foreach(DataRow User in UserInfo.Rows)
            {
                gdgvUserInfo.Rows.Add(User["UserID"], User["PersonID"], User["FullName"], User["UserName"], User["Password"]);
            }

            lblNumberOfUsers.Text = gdgvUserInfo.Rows.Count.ToString();
        
        }
        private void _CustomInterface()
        {
            this.BackColor = System.Drawing.ColorTranslator.FromHtml("#d5eafe");
            panel1.BackColor = System.Drawing.ColorTranslator.FromHtml("#e7edf2");
            gpbMax.ProgressColor = System.Drawing.ColorTranslator.FromHtml("#ff698a");
            gpbLess1.ProgressColor = System.Drawing.ColorTranslator.FromHtml("#ff698a");
            gpbLess2.ProgressColor = System.Drawing.ColorTranslator.FromHtml("#ff698a");
            gpbLess3.ProgressColor = System.Drawing.ColorTranslator.FromHtml("#ff698a");
            gpbLess4.ProgressColor = System.Drawing.ColorTranslator.FromHtml("#ff698a");
            gpbMin.ProgressColor = System.Drawing.ColorTranslator.FromHtml("#ff698a");
            gpbMax.ProgressColor2 = System.Drawing.ColorTranslator.FromHtml("#ff698a");
            gpbLess1.ProgressColor2 = System.Drawing.ColorTranslator.FromHtml("#ff698a");
            gpbLess2.ProgressColor2 = System.Drawing.ColorTranslator.FromHtml("#ff698a");
            gpbLess3.ProgressColor2 = System.Drawing.ColorTranslator.FromHtml("#ff698a");
            gpbLess4.ProgressColor2 = System.Drawing.ColorTranslator.FromHtml("#ff698a");
            gpbMin.ProgressColor2 = System.Drawing.ColorTranslator.FromHtml("#ff698a");
            //gdgvUserInfo.BackgroundColor = System.Drawing.ColorTranslator.FromHtml("#d5eafe");
            gdgvUserInfo.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.ColorTranslator.FromHtml("#d5eafe");
            guna2ShadowPanel4.FillColor = System.Drawing.ColorTranslator.FromHtml("#ff698a");
            guna2ShadowPanel5.FillColor = System.Drawing.ColorTranslator.FromHtml("#6458ff");
            guna2ShadowPanel6.FillColor = System.Drawing.ColorTranslator.FromHtml("#6df271");
            guna2ShadowPanel7.FillColor = System.Drawing.ColorTranslator.FromHtml("#ffdd6a");
            lblDate.Text = DateTime.Now.ToShortDateString();

        }
        private void frmDashboardScreen_Load(object sender, EventArgs e)
        {
            _CustomInterface();
            _FullChartBar();
            _FullDataGredViewWithUsers();
        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void pictureBox1_MouseHover(object sender, EventArgs e)
        {
            pictureBox1.BackColor = System.Drawing.ColorTranslator.FromHtml("#d3e1ed");

        }
        private void pictureBox1_MouseLeave(object sender, EventArgs e)
        {
            pictureBox1.BackColor = System.Drawing.ColorTranslator.FromHtml("#e7edf2");
        }
   }
}
